import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.file.*;
import java.time.*;
import java.time.temporal.TemporalAdjusters;
import java.util.*;
import java.util.List;
import javax.imageio.ImageIO;

/**
 * End-to-end GUI checks for OurDay: starts the real app and clicks through it with
 * java.awt.Robot (it moves the real mouse, so don't touch the computer while it runs).
 * Run it with gui-tests/run.sh, which uses a throwaway home folder so your own
 * calendar is never touched. Scenarios: flows, restart, features, image, corrupt.
 */
public class OurDayGuiTest {
    static Robot r;
    static final File OUT = new File("shots");
    static int fails;
    static final Path HOME = Paths.get(System.getProperty("user.home"), ".ourday");
    static final int MENU = Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx() == java.awt.event.InputEvent.META_DOWN_MASK
        ? KeyEvent.VK_META : KeyEvent.VK_CONTROL;

    // ---------- helpers ----------

    static void check(boolean ok, String what) {
        System.out.println((ok ? "  PASS " : "  FAIL ") + what);
        if (!ok) {
            fails++;
        }
    }

    static void shot(String name) throws Exception {
        Thread.sleep(600);
        ImageIO.write(r.createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize())), "png",
            new File(OUT, name + ".png"));
    }

    static List<Component> all(Container c) {
        List<Component> found = new ArrayList<>();
        walk(c, found);
        return found;
    }

    static void walk(Container c, List<Component> found) {
        for (Component k : c.getComponents()) {
            found.add(k);
            if (k instanceof Container) {
                walk((Container) k, found);
            }
        }
    }

    static Frame frame() {
        for (Frame f : Frame.getFrames()) {
            if (f.isVisible() && "OurDay".equals(f.getTitle())) {
                return f;
            }
        }
        return null;
    }

    static Dialog dialog(String titleStart) throws Exception {
        for (int i = 0; i < 30; i++) {
            for (Window w : Window.getWindows()) {
                if (w.isShowing() && w instanceof Dialog && ((Dialog) w).getTitle() != null
                        && ((Dialog) w).getTitle().startsWith(titleStart)) {
                    return (Dialog) w;
                }
            }
            Thread.sleep(200);
        }
        return null;
    }

    static AbstractButton button(Container root, String text) {
        for (Component c : all(root)) {
            if (c instanceof AbstractButton && text.equals(((AbstractButton) c).getText()) && c.isShowing()) {
                return (AbstractButton) c;
            }
        }
        return null;
    }

    static <T> T find(Container root, Class<T> type, java.util.function.Predicate<T> test) {
        if (root == null) {
            return null;
        }
        for (Component c : all(root)) {
            if (type.isInstance(c) && c.isShowing() && test.test(type.cast(c))) {
                return type.cast(c);
            }
        }
        return null;
    }

    /** A component in the main window whose tooltip mentions the text (event blocks and chips). */
    static JComponent eventNamed(String title) {
        return find(frame(), JComponent.class, c -> c.getClass().getName().contains("EventBlock")
            && c.getToolTipText() != null && c.getToolTipText().contains("<b>" + title + "</b>"));
    }

    static Point center(Component c) {
        Point p = c.getLocationOnScreen();
        return new Point(p.x + c.getWidth() / 2, p.y + c.getHeight() / 2);
    }

    static void click(Component c) throws Exception {
        Point p = c.getLocationOnScreen();
        clickAt(p.x + Math.min(c.getWidth() / 2, 40), p.y + c.getHeight() / 2);
    }

    static void clickAt(int x, int y) throws Exception {
        r.mouseMove(x, y);
        Thread.sleep(150);
        r.mousePress(16);
        r.mouseRelease(16);
        Thread.sleep(700);
    }

    /** Click in a background thread, for clicks that open a modal dialog. */
    static void clickLater(Component c) {
        new Thread(() -> {
            try {
                click(c);
            } catch (Exception ignored) {
            }
        }).start();
    }

    static void drag(Point from, Point to) throws Exception {
        r.mouseMove(from.x, from.y);
        Thread.sleep(200);
        r.mousePress(16);
        for (int i = 1; i <= 12; i++) {
            r.mouseMove(from.x + (to.x - from.x) * i / 12, from.y + (to.y - from.y) * i / 12);
            Thread.sleep(40);
        }
        Thread.sleep(200);
        new Thread(() -> r.mouseRelease(16)).start(); // releasing may open a modal dialog
        Thread.sleep(900);
    }

    /** Focus the window (as a user clicking it would), then press keys. */
    static void key(int... keys) throws Exception {
        JLabel l = find(frame(), JLabel.class, x -> "Personalize".equals(x.getText()));
        if (l != null) {
            click(l);
        }
        for (int k : keys) {
            r.keyPress(k);
        }
        for (int i = keys.length - 1; i >= 0; i--) {
            r.keyRelease(keys[i]);
        }
        Thread.sleep(800);
    }

    static void type(String text) throws Exception {
        for (char ch : text.toCharArray()) {
            int code = KeyEvent.getExtendedKeyCodeForChar(ch);
            r.keyPress(code);
            r.keyRelease(code);
            Thread.sleep(30);
        }
        Thread.sleep(400);
    }

    static void edt(Runnable x) throws Exception {
        SwingUtilities.invokeAndWait(x);
    }

    static String events() throws Exception {
        Path p = HOME.resolve("ourday-events.dat");
        return Files.exists(p) ? Files.readString(p) : "";
    }

    static String eventLine(String id) throws Exception {
        for (String line : events().split("\n")) {
            if (line.startsWith(id + "\t")) {
                return line;
            }
        }
        return "";
    }

    static String field(String id, int column) throws Exception {
        String[] f = eventLine(id).split("\t", -1);
        return f.length > column ? f[column] : "?";
    }

    static String settings() throws Exception {
        Path p = HOME.resolve("settings.properties");
        return Files.exists(p) ? Files.readString(p) : "";
    }

    static String headerTitle() {
        for (Component c : all(frame())) {
            if (c instanceof JLabel && ((JLabel) c).getFont().getSize() == 24) {
                return ((JLabel) c).getText();
            }
        }
        return "?";
    }

    /** Where on screen a time on a day is, in Day/Week view. */
    static Point gridPoint(LocalDate day, int hour, int minute) throws Exception {
        JPanel canvas = find(frame(), JPanel.class, c -> c.getClass().getName().contains("GridCanvas"));
        TimeGridView view = find(frame(), TimeGridView.class, x -> true);
        int index = view.days().indexOf(day);
        int col = (canvas.getWidth() - TimeGridView.GUTTER) / view.days().size();
        int y = (hour * 60 + minute) * TimeGridView.HOUR_HEIGHT / 60;
        edt(() -> canvas.scrollRectToVisible(new Rectangle(0, Math.max(0, y - 100), 10, 260)));
        Thread.sleep(300);
        Point p = canvas.getLocationOnScreen();
        return new Point(p.x + TimeGridView.GUTTER + index * col + col / 2, p.y + y + 4);
    }

    static void seed(String... lines) throws Exception {
        Files.createDirectories(HOME);
        Files.writeString(HOME.resolve("ourday-events.dat"), "# OurDay events v3\n" + String.join("\n", lines) + "\n");
    }

    static String line(String id, String title, LocalDate date, String start, String end, String repeat, String days,
                       String endDate, String location, String notes) {
        return String.join("\t", id, title, date.toString(), start, end, "WORK", repeat, days, "", "-1", "",
            endDate, "1", location, notes);
    }

    // ---------- scenarios ----------

    public static void main(String[] args) throws Exception {
        if (!System.getProperty("user.home").contains("ourday-gui-test")) {
            System.out.println("Refusing to run: use gui-tests/run.sh so a temporary home folder is used.");
            System.exit(2);
        }
        OUT.mkdirs();
        r = new Robot();
        r.setAutoDelay(20);
        String script = args[0];
        LocalDate today = LocalDate.now();
        if (script.equals("features")) {
            LocalDate weekStart = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.SUNDAY));
            seed(
                line("lunch", "Lunch", today, "12:00", "13:00", "NONE", "", "", "", ""),
                line("dentist", "Dentist", today, "15:00", "16:00", "NONE", "", "", "Downtown Dental", "Bring insurance card"),
                line("standup", "Team standup", weekStart, "10:00", "10:15", "DAILY", "", "", "", ""),
                line("piano", "Piano lesson", pianoDay(today), "17:00", "18:00", "NONE", "", "", "", ""),
                line("trip", "Ski trip", today.plusDays(3), "", "", "NONE", "", today.plusDays(5).toString(), "", ""));
        }
        if (script.equals("image")) {
            BufferedImage img = new BufferedImage(640, 400, BufferedImage.TYPE_INT_RGB);
            Graphics2D g = img.createGraphics();
            g.setPaint(new GradientPaint(0, 0, new Color(11, 110, 79), 0, 400, new Color(249, 200, 14)));
            g.fillRect(0, 0, 640, 400);
            g.dispose();
            File bg = HOME.resolve("bg.png").toFile();
            ImageIO.write(img, "png", bg);
            Files.writeString(HOME.resolve("settings.properties"), "background.palette=Gradient\nbackground.image="
                + bg.getAbsolutePath().replace("\\", "/") + "\nbackground.opacity=40\nview=MONTH\n");
        }

        new Thread(() -> OurDay.main(new String[0])).start();
        Thread.sleep(3500);
        Frame f = frame();

        try {
            runScenario(script, f, today);
        } catch (Throwable unexpected) {
            unexpected.printStackTrace();
            check(false, "scenario stopped by an unexpected error: " + unexpected);
        }
        System.out.println(fails == 0 ? "ALL PASSED" : fails + " FAILED");
        System.exit(fails == 0 ? 0 : 1);
    }

    static void runScenario(String script, Frame f, LocalDate today) throws Exception {
        switch (script) {
            case "flows":
                flows(f, today);
                break;
            case "restart":
                System.out.println("== Restart keeps settings and events");
                JComboBox<?> palette = find(f, JComboBox.class, c -> "Gradient".equals(c.getItemAt(0)));
                check("Mint".equals(palette.getSelectedItem()), "palette dropdown restored to Mint");
                check(headerTitle().matches("[A-Z][a-z]+ \\d{4}"), "last view (Month) restored: " + headerTitle());
                check(find(f, EventChip.class, c -> c.getText().contains("Algorithms")) != null, "event still there");
                click(button(f, "Reset"));
                check(settings().contains("background.palette=Gradient"), "Reset returns to Gradient");
                break;
            case "features":
                features(f, today);
                break;
            case "image":
                shot("image");
                JSlider s = find(f, JSlider.class, x -> true);
                check(s.getValue() == 40, "opacity restored to 40 (is " + s.getValue() + ")");
                break;
            case "corrupt":
                Dialog err = dialog("OurDay");
                check(err != null, "message shown for a damaged events file");
                if (err != null) {
                    shot("corrupt");
                    click(button(err, "OK"));
                }
                Thread.sleep(1500);
                boolean bak;
                try (var st = Files.list(HOME)) {
                    bak = st.anyMatch(p -> p.getFileName().toString().matches("ourday-events\\.dat\\.\\d{8}-\\d{6}\\.bak"));
                }
                check(bak, "original file kept as a .bak");
                break;
            default:
                System.out.println("Unknown scenario " + script);
                fails++;
        }
    }

    static void flows(Frame f, LocalDate today) throws Exception {
        System.out.println("== Add from Day view (click the grid at 2 PM)");
        key(MENU, KeyEvent.VK_1);
        Point twoPm = gridPoint(today, 14, 10);
        new Thread(() -> {
            try {
                clickAt(twoPm.x, twoPm.y);
            } catch (Exception ignored) {
            }
        }).start();
        Dialog ed = dialog("New event");
        check(ed != null, "clicking 2 PM opens the New event form");
        List<JSpinner> sp = new ArrayList<>();
        for (Component c : all(ed)) {
            if (c instanceof JSpinner && ((JSpinner) c).getModel() instanceof SpinnerDateModel) {
                sp.add((JSpinner) c);
            }
        }
        // date, end date, start, end, until
        String startShown = ((JSpinner.DefaultEditor) sp.get(2).getEditor()).getTextField().getText();
        check(startShown.equals("2:00 PM"), "form starts at 2:00 PM (shows '" + startShown + "')");
        edt(() -> {
            find(ed, JTextField.class, t -> t.getText().equals("New event")).setText("Algorithms study ünïcode 📚");
            List<JTextField> fields = new ArrayList<>();
            for (Component c : all(ed)) {
                if (c.getClass() == JTextField.class) {
                    fields.add((JTextField) c);
                }
            }
            fields.get(1).setText("Library, room 3");
            find(ed, JTextArea.class, x -> true).setText("Chapter 4 problems\nBring laptop");
            find(ed, JComboBox.class, c -> c.getItemAt(0) instanceof Recurrence).setSelectedItem(Recurrence.WEEKLY);
            find(ed, JComboBox.class, c -> "No reminder".equals(c.getItemAt(0))).setSelectedItem("15 minutes before");
        });
        Thread.sleep(400);
        String todayShort = today.getDayOfWeek().getDisplayName(java.time.format.TextStyle.SHORT, Locale.US);
        check(find(ed, JCheckBox.class, c -> c.getText().equals(todayShort)).isSelected(),
            "weekly defaults to today's weekday (" + todayShort + ")");
        JCheckBox fri = find(ed, JCheckBox.class, c -> c.getText().equals("Fri"));
        if (!fri.isSelected()) {
            click(fri);
        }
        shot("new-event-form");
        click(button(ed, "Add event"));
        String ev = events();
        check(ev.contains("Algorithms study ünïcode 📚"), "saved with a non-ASCII title");
        check(ev.contains("\t14:00\t15:00\t") && ev.contains("WEEKLY") && ev.contains("FRIDAY") && ev.contains("\t15\t"),
            "time, weekly days and reminder saved");
        check(ev.contains("Library, room 3") && ev.contains("Chapter 4 problems\\nBring laptop"), "location and notes saved");

        System.out.println("== Edit from Week view");
        key(MENU, KeyEvent.VK_2);
        JComponent block = eventNamed("Algorithms study ünïcode 📚");
        check(block != null, "event shows as a block in Week view");
        edt(() -> block.scrollRectToVisible(new Rectangle(0, 0, 10, block.getHeight())));
        Thread.sleep(300);
        clickLater(block);
        Dialog ed2 = dialog("Edit event");
        check(ed2 != null, "clicking the event opens the Edit form");
        edt(() -> find(ed2, JTextField.class, t -> t.getText().startsWith("Algorithms")).setText("Algorithms study group"));
        click(button(ed2, "Save"));
        check(events().contains("Algorithms study group") && !events().contains("ünïcode"), "edit saved");
        check(events().split("\n").length == 3, "still exactly one event");

        System.out.println("== Delete one repeat from Month view");
        key(MENU, KeyEvent.VK_3);
        LocalDate nextFri = today.with(TemporalAdjusters.next(DayOfWeek.FRIDAY));
        if (nextFri.getMonth() != today.getMonth()) {
            key(MENU, KeyEvent.VK_RIGHT);
        }
        CalendarDayPanel cell = find(frame(), CalendarDayPanel.class, c -> c.getDate().equals(nextFri));
        clickLater(cell);
        Dialog list = dialog("Events for");
        check(list != null, "clicking " + nextFri + " opens its events");
        JList<?> jl = find(list, JList.class, x -> true);
        check(jl.getModel().getSize() == 1, "the repeat appears on " + nextFri);
        edt(() -> jl.setSelectedIndex(0));
        clickLater(button(list, "Delete"));
        Dialog ask = dialog("Delete repeating event");
        check(ask != null, "asks this-day-or-all");
        click(button(ask, "Only this day"));
        check(jl.getModel().getSize() == 0, "list is empty after deleting that day");
        check(events().contains(nextFri.toString()), "skipped date stored");
        click(button(list, "Done"));
        CalendarDayPanel after = find(frame(), CalendarDayPanel.class, c -> c.getDate().equals(nextFri));
        check(find(after, EventChip.class, x -> true) == null, "month cell no longer shows it");

        System.out.println("== Personalize");
        JComboBox<?> palette = find(frame(), JComboBox.class, c -> "Gradient".equals(c.getItemAt(0)));
        edt(() -> palette.setSelectedItem("Mint"));
        check(settings().contains("background.palette=Mint"), "palette saved");
    }

    static void features(Frame f, LocalDate today) throws Exception {
        LocalDate other = today.getDayOfWeek() == DayOfWeek.SATURDAY ? today.minusDays(1) : today.plusDays(1);

        System.out.println("== Drag and drop in Week view");
        key(MENU, KeyEvent.VK_2);
        shot("week");
        JComponent lunch = eventNamed("Lunch");
        check(lunch != null, "Lunch shows in the week grid");
        gridPoint(today, 12, 0); // scroll it into view
        // Grab the middle of the 12:00-1:00 block (12:30) and drop it at 1:30 on the other day: one hour later.
        drag(center(lunch), gridPoint(other, 13, 30));
        check(field("lunch", 2).equals(other.toString()) && field("lunch", 3).equals("13:00")
            && field("lunch", 4).equals("14:00"), "dragging Lunch moved it to " + other + " 1:00-2:00 PM: "
            + field("lunch", 2) + " " + field("lunch", 3) + "-" + field("lunch", 4));

        JComponent dentist = eventNamed("Dentist");
        gridPoint(today, 15, 0);
        Point bottom = dentist.getLocationOnScreen();
        bottom.translate(dentist.getWidth() / 2, dentist.getHeight() - 2);
        drag(bottom, new Point(bottom.x, bottom.y + TimeGridView.HOUR_HEIGHT / 2));
        check(field("dentist", 4).equals("16:30"), "dragging Dentist's bottom edge made it end at 4:30 (" + field("dentist", 4) + ")");

        int todayX = gridPoint(today, 10, 0).x;
        JComponent standup = find(frame(), JComponent.class, c -> c.getClass().getName().contains("EventBlock")
            && c.getToolTipText() != null && c.getToolTipText().contains("Team standup")
            && Math.abs(center(c).x - todayX) < 40);
        check(standup != null, "today's standup is in the grid");
        drag(center(standup), new Point(center(standup).x, center(standup).y + TimeGridView.HOUR_HEIGHT));
        Dialog confirm = dialog("Move repeating event");
        check(confirm != null, "moving a repeating event asks first");
        click(button(confirm, "OK"));
        check(field("standup", 3).equals("11:00") && field("standup", 4).equals("11:15"),
            "every repeat moved to 11:00-11:15");

        System.out.println("== Undo / redo");
        key(MENU, KeyEvent.VK_Z);
        check(field("standup", 3).equals("10:00"), "Undo puts the standup back at 10:00");
        key(MENU, KeyEvent.VK_Z);
        check(field("dentist", 4).equals("16:00"), "Undo again restores Dentist's end time");
        key(MENU, KeyEvent.VK_SHIFT, KeyEvent.VK_Z);
        check(field("dentist", 4).equals("16:30"), "Redo re-applies it");

        System.out.println("== Drag in Month view");
        key(MENU, KeyEvent.VK_3);
        LocalDate pianoDay = pianoDay(today);
        LocalDate target = pianoDay.getDayOfMonth() > 20 ? pianoDay.minusDays(3) : pianoDay.plusDays(3);
        EventChip piano = find(frame(), EventChip.class, c -> c.getText().contains("Piano"));
        CalendarDayPanel targetCell = find(frame(), CalendarDayPanel.class, c -> c.getDate().equals(target));
        if (piano == null) {
            check(false, "Piano lesson chip visible in month view");
        } else {
            drag(center(piano), center(targetCell));
            check(field("piano", 2).equals(target.toString()), "dragged Piano lesson to " + target + " (" + field("piano", 2) + ")");
        }
        CalendarDayPanel cellToday = find(frame(), CalendarDayPanel.class, c -> c.getDate().equals(today));
        EventChip standupChip = find(cellToday, EventChip.class, c -> c.getText().contains("standup"));
        if (standupChip != null) {
            CalendarDayPanel dropOn = find(frame(), CalendarDayPanel.class, c -> c.getDate().equals(target));
            drag(center(standupChip), center(dropOn));
            Dialog info = dialog("Move repeating event");
            check(info != null, "dragging a repeating event to another day explains why it can't");
            if (info != null) {
                click(button(info, "OK"));
            }
            check(field("standup", 2).equals(today.with(TemporalAdjusters.previousOrSame(DayOfWeek.SUNDAY)).toString()),
                "repeating event unchanged");
        }

        System.out.println("== Multi-day event");
        CalendarDayPanel tripEnd = find(frame(), CalendarDayPanel.class, c -> c.getDate().equals(today.plusDays(5)));
        if (tripEnd != null) {
            check(find(tripEnd, EventChip.class, c -> c.getText().equals("→ Ski trip")) != null,
                "a 3-day trip shows on its last day as '→ Ski trip'");
        }

        System.out.println("== Keyboard navigation");
        key(KeyEvent.VK_RIGHT);
        key(KeyEvent.VK_RIGHT);
        key(KeyEvent.VK_DOWN);
        new Thread(() -> {
            try {
                key(KeyEvent.VK_ENTER);
            } catch (Exception ignored) {
            }
        }).start();
        Dialog dayDialog = dialog("Events for");
        check(dayDialog != null && dayDialog.getTitle().contains(Formats.fullDay(today.plusDays(9))),
            "Right, Right, Down, Enter opens " + Formats.fullDay(today.plusDays(9))
                + (dayDialog == null ? "" : " (got " + dayDialog.getTitle() + ")"));
        if (dayDialog != null) {
            click(button(dayDialog, "Done"));
        }

        System.out.println("== Search");
        new Thread(() -> {
            try {
                key(MENU, KeyEvent.VK_F);
            } catch (Exception ignored) {
            }
        }).start();
        Dialog search = dialog("Search events");
        check(search != null, "Find opens the search window");
        type("dental");
        JList<?> results = find(search, JList.class, x -> true);
        check(results.getModel().getSize() == 1, "searching 'dental' finds the Dentist (by its location)");
        shot("search");
        r.keyPress(KeyEvent.VK_ENTER);
        r.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(900);
        check(headerTitle().equals(Formats.fullDay(today)), "Enter opens that day: " + headerTitle());

        System.out.println("== Export and import through the File menu");
        File exported = HOME.resolve("export-test.ics").toFile();
        new Thread(() -> {
            try {
                key(MENU, KeyEvent.VK_E);
            } catch (Exception ignored) {
            }
        }).start();
        chooseFile("Export your calendar", exported);
        Dialog saved = dialog("Export");
        check(saved != null && exported.isFile() && Files.readString(exported.toPath()).contains("SUMMARY:Dentist"),
            "export wrote an .ics file with the events");
        if (saved != null) {
            click(button(saved, "OK"));
        }
        File incoming = HOME.resolve("incoming.ics").toFile();
        Files.writeString(incoming.toPath(), "BEGIN:VCALENDAR\r\nBEGIN:VEVENT\r\nUID:incoming-1\r\nDTSTART:"
            + today.plusDays(1).toString().replace("-", "") + "T090000\r\nDTEND:"
            + today.plusDays(1).toString().replace("-", "") + "T100000\r\nSUMMARY:Imported meeting\r\n"
            + "LOCATION:Room 9\r\nEND:VEVENT\r\nEND:VCALENDAR\r\n");
        new Thread(() -> {
            try {
                key(MENU, KeyEvent.VK_I);
            } catch (Exception ignored) {
            }
        }).start();
        chooseFile("Import a calendar file", incoming);
        Dialog imported = dialog("Import");
        check(imported != null, "import shows a summary");
        if (imported != null) {
            JLabel msg = find(imported, JLabel.class, l -> l.getText() != null && l.getText().startsWith("Added"));
            check(msg != null && msg.getText().startsWith("Added 1 event"), "summary says 1 event was added");
            click(button(imported, "OK"));
        }
        check(eventLine("incoming-1").contains("Imported meeting") && eventLine("incoming-1").contains("Room 9"),
            "imported event saved");

        System.out.println("== Dark theme");
        click(button(frame(), "Dark"));
        Thread.sleep(800);
        check(ThemeManager.isDark() && settings().contains("theme.dark=true"), "dark theme on and saved");
        key(MENU, KeyEvent.VK_2);
        shot("week-dark");
        click(button(frame(), "Light"));
        check(!ThemeManager.isDark() && settings().contains("theme.dark=false"), "back to light");
    }

    /** A quiet day this month for the month-view drag test (only the daily standup is on it). */
    static LocalDate pianoDay(LocalDate today) {
        return today.getDayOfMonth() > 20 ? today.minusDays(2) : today.plusDays(2);
    }

    /** Fills in an open file chooser and presses its main button. */
    static void chooseFile(String dialogTitle, File file) throws Exception {
        Dialog d = dialog(dialogTitle);
        check(d != null, "file chooser '" + dialogTitle + "' opened");
        if (d == null) {
            return;
        }
        JFileChooser chooser = find(d, JFileChooser.class, x -> true);
        edt(() -> {
            chooser.setCurrentDirectory(file.getParentFile());
            chooser.setSelectedFile(file);
            chooser.approveSelection();
        });
        Thread.sleep(800);
    }
}

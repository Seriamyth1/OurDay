#!/usr/bin/env bash
# Runs the OurDay GUI checks against a temporary home folder (your real calendar is never used).
# Usage (from the project folder):  bash gui-tests/run.sh
# On Linux without a screen, prefix with: xvfb-run -a
# On macOS, allow your terminal under System Settings > Privacy & Security > Accessibility
# (Robot needs it to move the mouse), and don't use the mouse/keyboard while it runs.
set -e
cd "$(dirname "$0")/.."
BUILD=gui-tests/build
rm -rf "$BUILD" && mkdir -p "$BUILD/classes"
javac --release 17 -encoding UTF-8 -d "$BUILD/classes" src/main/java/*.java gui-tests/OurDayGuiTest.java

HOME_DIR="$(mktemp -d)/ourday-gui-test"
mkdir -p "$HOME_DIR/.ourday"
cd "$BUILD"
run() { java -Duser.home="$HOME_DIR" -cp classes OurDayGuiTest "$@"; }

run flows
run restart
run features
# saved background image at 40% opacity (the test creates the image)
run image
# a damaged line in the events file
echo "a line typed by hand" >> "$HOME_DIR/.ourday/ourday-events.dat"
run corrupt
echo "Screenshots are in $BUILD/shots"

import org.junit.jupiter.api.Test;

import java.time.*;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

class ICalendarTest {
    private static final ZoneId NEW_YORK = ZoneId.of("America/New_York");

    private static Map<String, CalendarEvent> byTitle(List<CalendarEvent> events) {
        return events.stream().collect(Collectors.toMap(CalendarEvent::getTitle, Function.identity()));
    }

    @Test
    void exportThenImportKeepsEverything() {
        CalendarEvent lecture = new CalendarEvent("CS 350; Software, Engineering", LocalDate.of(2026, 9, 1));
        lecture.setTimes(LocalTime.of(9, 30), LocalTime.of(10, 45));
        lecture.setRecurrence(Recurrence.WEEKLY);
        lecture.setRepeatDays(EnumSet.of(DayOfWeek.TUESDAY, DayOfWeek.THURSDAY));
        lecture.setInterval(1);
        lecture.setRepeatUntil(LocalDate.of(2026, 12, 10));
        lecture.skipDate(LocalDate.of(2026, 11, 26));
        lecture.setCategory(Category.SCHOOL);
        lecture.setLocation("Room 204, Science Hall");
        lecture.setNotes("Bring laptop\nQuiz on chapter 4 — see notes \\ slides");
        lecture.setReminderMinutes(15);

        CalendarEvent trip = new CalendarEvent("Thanksgiving trip 🦃", LocalDate.of(2026, 11, 25));
        trip.setEndDate(LocalDate.of(2026, 11, 29));
        trip.setCategory(Category.FAMILY);
        trip.setReminderMinutes(1440);

        CalendarEvent payday = new CalendarEvent("Payday", LocalDate.of(2026, 11, 6));
        payday.setRecurrence(Recurrence.WEEKLY);
        payday.setInterval(2);

        String ics = ICalendar.export(List.of(lecture, trip, payday), Instant.parse("2026-11-18T14:00:00Z"));
        for (String line : ics.split("\r\n")) {
            assertTrue(line.getBytes(java.nio.charset.StandardCharsets.UTF_8).length <= 75, "folded: " + line);
        }

        ICalendar.Result result = ICalendar.parse(ics, NEW_YORK);
        assertTrue(result.warnings.isEmpty(), result.warnings.toString());
        Map<String, CalendarEvent> got = byTitle(result.events);

        CalendarEvent l = got.get(lecture.getTitle());
        assertEquals(lecture.getId(), l.getId(), "the same event keeps its id, so re-importing updates it");
        assertEquals(LocalTime.of(9, 30), l.getStartTime());
        assertEquals(LocalTime.of(10, 45), l.getEndTime());
        assertEquals(EnumSet.of(DayOfWeek.TUESDAY, DayOfWeek.THURSDAY), l.getRepeatDays());
        assertEquals(LocalDate.of(2026, 12, 10), l.getRepeatUntil());
        assertEquals(lecture.getSkippedDates(), l.getSkippedDates());
        assertEquals(Category.SCHOOL, l.getCategory());
        assertEquals(lecture.getLocation(), l.getLocation());
        assertEquals(lecture.getNotes(), l.getNotes());
        assertEquals(15, l.getReminderMinutes());

        CalendarEvent t = got.get(trip.getTitle());
        assertTrue(t.isAllDay());
        assertEquals(LocalDate.of(2026, 11, 29), t.getEndDate());
        assertEquals(1440, t.getReminderMinutes(), "all-day reminder (9 AM the day before) survives");

        CalendarEvent p = got.get("Payday");
        assertEquals(2, p.getInterval());
        assertTrue(p.occursOn(LocalDate.of(2026, 11, 20)));
        assertFalse(p.occursOn(LocalDate.of(2026, 11, 13)));
    }

    @Test
    void readsATypicalGoogleCalendarExport() {
        String ics = String.join("\r\n",
            "BEGIN:VCALENDAR",
            "PRODID:-//Google Inc//Google Calendar 70.9054//EN",
            "VERSION:2.0",
            "BEGIN:VTIMEZONE",
            "TZID:America/Los_Angeles",
            "BEGIN:STANDARD",
            "DTSTART:19701101T020000",
            "END:STANDARD",
            "END:VTIMEZONE",
            // weekly team call in Los Angeles time, 10 times, one week skipped, one week moved
            "BEGIN:VEVENT",
            "DTSTART;TZID=America/Los_Angeles:20261103T090000",
            "DTEND;TZID=America/Los_Angeles:20261103T093000",
            "RRULE:FREQ=WEEKLY;WKST=SU;COUNT=10;BYDAY=TU",
            "EXDATE;TZID=America/Los_Angeles:20261124T090000",
            "UID:team-call@google.com",
            "SUMMARY:Team call",
            "LOCATION:https://meet.google.com/abc-defg-hij",
            "DESCRIPTION:Agenda:\\n1. Status\\n2. Demo",
            "BEGIN:VALARM",
            "ACTION:DISPLAY",
            "TRIGGER:-P0DT0H10M0S",
            "END:VALARM",
            "END:VEVENT",
            "BEGIN:VEVENT",
            "DTSTART;TZID=America/Los_Angeles:20261111T090000",
            "DTEND;TZID=America/Los_Angeles:20261111T093000",
            "RECURRENCE-ID;TZID=America/Los_Angeles:20261110T090000",
            "UID:team-call@google.com",
            "SUMMARY:Team call (moved)",
            "END:VEVENT",
            // UTC time, long description folded across lines
            "BEGIN:VEVENT",
            "DTSTART:20261120T190000Z",
            "DTEND:20261120T200000Z",
            "UID:dentist@google.com",
            "SUMMARY:Dentist",
            "DESCRIPTION:Please arrive 10 minutes early to fill out the new patient for",
            " ms and bring your insurance card.",
            "END:VEVENT",
            // all-day, 3 days
            "BEGIN:VEVENT",
            "DTSTART;VALUE=DATE:20261225",
            "DTEND;VALUE=DATE:20261228",
            "UID:holiday@google.com",
            "SUMMARY:Holiday break",
            "END:VEVENT",
            // monthly on the 2nd Monday: not something OurDay can repeat
            "BEGIN:VEVENT",
            "DTSTART:20261109T180000",
            "DURATION:PT2H",
            "RRULE:FREQ=MONTHLY;BYDAY=2MO",
            "UID:club@google.com",
            "SUMMARY:Book club",
            "END:VEVENT",
            "BEGIN:VEVENT",
            "DTSTART:20261201T100000",
            "STATUS:CANCELLED",
            "UID:gone@google.com",
            "SUMMARY:Cancelled thing",
            "END:VEVENT",
            "END:VCALENDAR", "");

        ICalendar.Result result = ICalendar.parse(ics, NEW_YORK);
        Map<String, CalendarEvent> got = byTitle(result.events);
        assertEquals(1, result.cancelled);
        assertFalse(got.containsKey("Cancelled thing"));

        CalendarEvent call = got.get("Team call");
        assertEquals(LocalTime.of(12, 0), call.getStartTime(), "9 AM in Los Angeles is noon in New York");
        assertEquals(LocalTime.of(12, 30), call.getEndTime());
        assertEquals(EnumSet.of(DayOfWeek.TUESDAY), call.getRepeatDays());
        assertEquals(LocalDate.of(2027, 1, 5), call.getRepeatUntil(), "COUNT=10 -> 10th Tuesday");
        assertFalse(call.occursOn(LocalDate.of(2026, 11, 24)), "excluded date");
        assertFalse(call.occursOn(LocalDate.of(2026, 11, 10)), "moved copy is hidden from the series");
        assertTrue(call.occursOn(LocalDate.of(2026, 11, 17)));
        assertEquals(10, call.getReminderMinutes());
        assertEquals("Agenda:\n1. Status\n2. Demo", call.getNotes());

        CalendarEvent moved = got.get("Team call (moved)");
        assertEquals(LocalDate.of(2026, 11, 11), moved.getDate());
        assertFalse(moved.isRepeating());

        CalendarEvent dentist = got.get("Dentist");
        assertEquals(LocalTime.of(14, 0), dentist.getStartTime(), "19:00 UTC = 2 PM in New York");
        assertTrue(dentist.getNotes().contains("patient forms and bring"), "folded lines are joined");

        CalendarEvent holiday = got.get("Holiday break");
        assertTrue(holiday.isAllDay());
        assertEquals(LocalDate.of(2026, 12, 27), holiday.getEndDate(), "DTEND is the day after");

        CalendarEvent club = got.get("Book club");
        assertFalse(club.isRepeating());
        assertEquals(LocalTime.of(20, 0), club.getEndTime(), "DURATION is used for the end");
        assertEquals(1, result.warnings.size());
        assertTrue(result.warnings.get(0).contains("Book club"));
    }

    @Test
    void reimportingUpdatesInsteadOfDuplicating() throws Exception {
        java.nio.file.Path dir = java.nio.file.Files.createTempDirectory("ics");
        EventManager manager = new EventManager(dir.resolve("e.dat").toFile(), m -> fail(m));
        manager.load();
        String v1 = "BEGIN:VCALENDAR\r\nBEGIN:VEVENT\r\nUID:x1\r\nDTSTART;VALUE=DATE:20261201\r\nSUMMARY:Party\r\nEND:VEVENT\r\nEND:VCALENDAR\r\n";
        EventManager.ImportCounts first = manager.importEvents(ICalendar.parse(v1, NEW_YORK).events, "Import");
        assertEquals(1, first.added);
        EventManager.ImportCounts second = manager.importEvents(
            ICalendar.parse(v1.replace("Party", "Holiday party"), NEW_YORK).events, "Import");
        assertEquals(0, second.added);
        assertEquals(1, second.updated);
        assertEquals("Holiday party", manager.getEvent("x1").getTitle());
        assertEquals(1, manager.getEvents().size());
        manager.undo();
        assertEquals("Party", manager.getEvent("x1").getTitle(), "an import is one undoable step");
    }

    @Test
    void durationsReadAndWrite() {
        assertEquals(-15, ICalendar.parseDurationMinutes("-PT15M"));
        assertEquals(-1440, ICalendar.parseDurationMinutes("-P1D"));
        assertEquals(1590, ICalendar.parseDurationMinutes("P1DT2H30M"));
        assertEquals(-10080, ICalendar.parseDurationMinutes("-P1W"));
        assertEquals("-PT15M", ICalendar.duration(-15));
        assertEquals("PT8H45M", ICalendar.duration(525));
        assertEquals("-P1D", ICalendar.duration(-1440));
        assertEquals("PT0S", ICalendar.duration(0));
    }

    @Test
    void notACalendarFileIsReported() {
        ICalendar.Result result = ICalendar.parse("hello", NEW_YORK);
        assertTrue(result.events.isEmpty());
        assertEquals(1, result.warnings.size());
    }
}

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

class InstanceLockTest {
    @TempDir
    Path dir;

    /** Run in a separate Java process: prints whether that process could take the lock. */
    public static void main(String[] args) {
        System.out.print(InstanceLock.acquire(new File(args[0])) ? "acquired" : "refused");
    }

    private String secondProgramTries() throws Exception {
        String java = Paths.get(System.getProperty("java.home"), "bin", "java").toString();
        Process process = new ProcessBuilder(java, "-cp", System.getProperty("java.class.path"),
            "InstanceLockTest", dir.toString()).redirectErrorStream(false).start();
        assertTrue(process.waitFor(30, TimeUnit.SECONDS), "second program finished");
        return new String(process.getInputStream().readAllBytes(), StandardCharsets.UTF_8).trim();
    }

    @Test
    void secondCopyOfOurDayIsRefusedUntilTheFirstCloses() throws Exception {
        try {
            assertTrue(InstanceLock.acquire(dir.toFile()));
            assertEquals("refused", secondProgramTries());
        } finally {
            InstanceLock.release();
        }
        assertEquals("acquired", secondProgramTries(), "after the first closes, OurDay can start again");
    }
}

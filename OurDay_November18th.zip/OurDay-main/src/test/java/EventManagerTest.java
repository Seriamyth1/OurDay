import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.io.ObjectOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

class EventManagerTest {
    private static final LocalDate DAY = LocalDate.of(2026, 11, 13);

    @TempDir
    Path dir;

    private final List<String> errors = new ArrayList<>();

    private EventManager manager(File file) {
        EventManager manager = new EventManager(file, errors::add);
        manager.load();
        return manager;
    }

    @Test
    void eventsSurviveARestartWithAllFields() {
        File file = dir.resolve("events.dat").toFile();
        EventManager first = manager(file);
        CalendarEvent event = new CalendarEvent("Grade\tfinals \\ \"exam 3\"\nsection 2", DAY);
        event.setTimes(LocalTime.of(14, 30), LocalTime.of(16, 0));
        event.setCategory(Category.WORK);
        event.setRecurrence(Recurrence.WEEKLY);
        event.setRepeatDays(EnumSet.of(DayOfWeek.MONDAY, DayOfWeek.FRIDAY));
        event.setRepeatUntil(DAY.plusMonths(1));
        event.setReminderMinutes(15);
        event.skipDate(DAY.plusDays(3));
        first.add(event);

        CalendarEvent loaded = manager(file).getEvent(event.getId());
        assertNotNull(loaded);
        assertEquals(event.getTitle(), loaded.getTitle());
        assertEquals(LocalTime.of(14, 30), loaded.getStartTime());
        assertEquals(LocalTime.of(16, 0), loaded.getEndTime());
        assertEquals(Category.WORK, loaded.getCategory());
        assertEquals(Recurrence.WEEKLY, loaded.getRecurrence());
        assertEquals(EnumSet.of(DayOfWeek.MONDAY, DayOfWeek.FRIDAY), loaded.getRepeatDays());
        assertEquals(DAY.plusMonths(1), loaded.getRepeatUntil());
        assertEquals(15, loaded.getReminderMinutes());
        assertEquals(Set.of(DAY.plusDays(3)), new HashSet<>(loaded.getSkippedDates()));
        assertTrue(errors.isEmpty());
    }

    @Test
    void occurrencesAreSortedAllDayFirstThenByTime() {
        EventManager manager = manager(dir.resolve("events.dat").toFile());
        CalendarEvent late = new CalendarEvent("Late", DAY);
        late.setTimes(LocalTime.of(18, 0), null);
        CalendarEvent early = new CalendarEvent("Early", DAY);
        early.setTimes(LocalTime.of(8, 0), null);
        CalendarEvent allDay = new CalendarEvent("Due date", DAY);
        manager.add(late);
        manager.add(early);
        manager.add(allDay);

        List<String> titles = manager.getOccurrences(DAY).stream()
            .map(o -> o.event().getTitle()).collect(Collectors.toList());
        assertEquals(List.of("Due date", "Early", "Late"), titles);
    }

    @Test
    void deletingOneRepeatKeepsTheOthers() {
        File file = dir.resolve("events.dat").toFile();
        EventManager manager = manager(file);
        CalendarEvent daily = new CalendarEvent("Walk", DAY);
        daily.setRecurrence(Recurrence.DAILY);
        manager.add(daily);

        manager.removeOccurrence(daily.getId(), DAY.plusDays(1));
        EventManager reloaded = manager(file);
        assertTrue(reloaded.hasEventsOn(DAY));
        assertFalse(reloaded.hasEventsOn(DAY.plusDays(1)));
        assertTrue(reloaded.hasEventsOn(DAY.plusDays(2)));

        reloaded.remove(daily.getId());
        assertFalse(manager(file).hasEventsOn(DAY.plusDays(2)));
    }

    @Test
    void updateReplacesTheStoredEvent() {
        File file = dir.resolve("events.dat").toFile();
        EventManager manager = manager(file);
        CalendarEvent event = new CalendarEvent("Draft", DAY);
        manager.add(event);
        CalendarEvent edited = event.copy();
        edited.setTitle("Final");
        manager.update(edited);
        assertEquals("Final", manager(file).getEvent(event.getId()).getTitle());
        assertEquals(1, manager.getEvents().size());
    }

    @Test
    void unreadableFileIsBackedUpAndNotOverwritten() throws Exception {
        Path file = dir.resolve("events.dat");
        Files.writeString(file, "this is not an events file");

        EventManager manager = manager(file.toFile());
        assertEquals(1, errors.size());
        assertTrue(manager.getEvents().isEmpty());

        List<Path> backups = list(dir, ".bak");
        assertEquals(1, backups.size());
        assertEquals("this is not an events file", Files.readString(backups.get(0)));

        manager.add(new CalendarEvent("New", DAY));
        assertEquals("this is not an events file", Files.readString(backups.get(0)));
        assertTrue(manager(file.toFile()).hasEventsOn(DAY));
    }

    @Test
    void oldVersionOneFilesAreMigrated() throws Exception {
        Path file = dir.resolve("events.dat");
        HashMap<LocalDate, List<String>> legacy = new HashMap<>();
        legacy.put(DAY, new ArrayList<>(List.of("Soccer practice", "Pick up Jane")));
        try (ObjectOutputStream out = new ObjectOutputStream(Files.newOutputStream(file))) {
            out.writeObject(legacy);
        }

        EventManager manager = manager(file.toFile());
        assertTrue(errors.isEmpty());
        assertEquals(2, manager.getOccurrences(DAY).size());
        assertTrue(manager.getOccurrences(DAY).get(0).event().isAllDay());
        assertTrue(Files.exists(dir.resolve("events.dat.v1.bak")), "old file is kept");
        assertFalse(EventFileFormat.isLegacyFile(file), "file is rewritten in the new format");
        assertTrue(Files.readString(file, StandardCharsets.UTF_8).startsWith(EventFileFormat.HEADER));
    }

    @Test
    void savingLeavesNoTemporaryFiles() throws Exception {
        EventManager manager = manager(dir.resolve("events.dat").toFile());
        manager.add(new CalendarEvent("One", DAY));
        manager.add(new CalendarEvent("Two", DAY));
        assertTrue(list(dir, ".tmp").isEmpty());
    }

    private static List<Path> list(Path dir, String suffix) throws Exception {
        try (Stream<Path> files = Files.list(dir)) {
            return files.filter(p -> p.toString().endsWith(suffix)).collect(Collectors.toList());
        }
    }

    @Test
    void deletingTheLastRemainingDayOfASeriesDeletesTheEvent() {
        EventManager manager = new EventManager(dir.resolve("last-day.dat").toFile(), message -> fail(message));
        manager.load();
        CalendarEvent series = new CalendarEvent("Exam week", LocalDate.of(2026, 12, 7));
        series.setRecurrence(Recurrence.DAILY);
        series.setRepeatUntil(LocalDate.of(2026, 12, 9));
        manager.add(series);

        manager.removeOccurrence(series.getId(), LocalDate.of(2026, 12, 7));
        manager.removeOccurrence(series.getId(), LocalDate.of(2026, 12, 9));
        assertNotNull(manager.getEvent(series.getId()), "Dec 8 is still left");

        manager.removeOccurrence(series.getId(), LocalDate.of(2026, 12, 8));
        assertNull(manager.getEvent(series.getId()), "nothing left, so the event is gone");
        assertTrue(manager.getEvents().isEmpty());
    }

    @Test
    void endlessSeriesSurvivesSkippingDays() {
        EventManager manager = new EventManager(dir.resolve("endless.dat").toFile(), message -> fail(message));
        manager.load();
        CalendarEvent series = new CalendarEvent("Standup", LocalDate.of(2026, 12, 7));
        series.setRecurrence(Recurrence.DAILY);
        manager.add(series);
        manager.removeOccurrence(series.getId(), LocalDate.of(2026, 12, 7));
        assertNotNull(manager.getEvent(series.getId()));
    }

    @Test
    void oneBadLineDoesNotCostTheOtherEvents() throws Exception {
        Path file = dir.resolve("partly-broken.dat");
        CalendarEvent good = new CalendarEvent("Dentist", DAY);
        String text = EventFileFormat.HEADER + "\n"
            + EventFileFormat.formatLine(good) + "\n"
            + "a line someone typed by hand\n"
            + EventFileFormat.formatLine(good) + "\n"; // same id twice
        Files.writeString(file, text);

        EventManager manager = manager(file.toFile());
        assertEquals(1, manager.getEvents().size(), "the good event is kept");
        assertEquals(1, errors.size(), "the user is told once");
        assertTrue(errors.get(0).contains("skipped 2 lines"), errors.get(0));

        List<Path> backups = list(dir, ".bak");
        assertEquals(1, backups.size());
        assertEquals(text, Files.readString(backups.get(0)), "original kept unchanged");

        errors.clear();
        assertEquals(1, manager(file.toFile()).getEvents().size());
        assertTrue(errors.isEmpty(), "file was cleaned up, so no warning next time");
    }

    @Test
    void newFieldsSurviveARestart() {
        File file = dir.resolve("v3.dat").toFile();
        CalendarEvent trip = new CalendarEvent("Ski trip", DAY);
        trip.setEndDate(DAY.plusDays(2));
        trip.setTimes(LocalTime.of(18, 0), LocalTime.of(12, 0)); // ends earlier in the day, on a later day
        trip.setRecurrence(Recurrence.YEARLY);
        trip.setInterval(2);
        trip.setLocation("Stowe, VT");
        trip.setNotes("Bring chains\tand the \\ big cooler\nCall ahead");
        manager(file).add(trip);

        CalendarEvent loaded = manager(file).getEvent(trip.getId());
        assertEquals(DAY.plusDays(2), loaded.getEndDate());
        assertEquals(LocalTime.of(12, 0), loaded.getEndTime());
        assertEquals(2, loaded.getInterval());
        assertEquals("Stowe, VT", loaded.getLocation());
        assertEquals(trip.getNotes(), loaded.getNotes());
        assertTrue(errors.isEmpty());
    }

    @Test
    void versionTwoFilesStillLoad() throws Exception {
        Path file = dir.resolve("v2.dat");
        Files.writeString(file, "# OurDay events v2\n"
            + "abc\tPiano\t2026-11-02\t16:00\t17:00\tHOBBIES\tWEEKLY\tMONDAY\t\t10\t2026-11-09\n");
        EventManager manager = manager(file.toFile());
        CalendarEvent piano = manager.getEvent("abc");
        assertNotNull(piano);
        assertEquals(1, piano.getInterval());
        assertEquals("", piano.getLocation());
        assertFalse(piano.isMultiDay());
        assertTrue(piano.occursOn(LocalDate.of(2026, 11, 16)));
        assertTrue(errors.isEmpty());
    }

    @Test
    void undoAndRedoEveryKindOfChange() {
        EventManager manager = manager(dir.resolve("undo.dat").toFile());
        assertFalse(manager.canUndo());
        CalendarEvent lunch = new CalendarEvent("Lunch", DAY);
        manager.add(lunch);
        CalendarEvent renamed = lunch.copy();
        renamed.setTitle("Lunch with Sam");
        manager.update(renamed);
        manager.remove(lunch.getId());
        assertNull(manager.getEvent(lunch.getId()));
        assertEquals("Delete \u201CLunch with Sam\u201D", manager.undoDescription());

        assertTrue(manager.undo());
        assertEquals("Lunch with Sam", manager.getEvent(lunch.getId()).getTitle());
        assertTrue(manager.undo());
        assertEquals("Lunch", manager.getEvent(lunch.getId()).getTitle());
        assertTrue(manager.redo());
        assertEquals("Lunch with Sam", manager.getEvent(lunch.getId()).getTitle());
        assertEquals("Lunch with Sam", manager(dir.resolve("undo.dat").toFile()).getEvent(lunch.getId()).getTitle(),
            "undo and redo are saved too");

        manager.add(new CalendarEvent("Gym", DAY));
        assertFalse(manager.canRedo(), "a new change clears redo");
        assertTrue(manager.undo());
        assertTrue(manager.undo());
        assertTrue(manager.undo());
        assertTrue(manager.getEvents().isEmpty());
        assertFalse(manager.undo());
    }

    @Test
    void undoBringsBackOneDeletedRepeat() {
        EventManager manager = manager(dir.resolve("undo-repeat.dat").toFile());
        CalendarEvent standup = new CalendarEvent("Standup", DAY);
        standup.setRecurrence(Recurrence.DAILY);
        manager.add(standup);
        manager.removeOccurrence(standup.getId(), DAY.plusDays(1));
        assertFalse(manager.hasEventsOn(DAY.plusDays(1)));
        manager.undo();
        assertTrue(manager.hasEventsOn(DAY.plusDays(1)));
    }

    @Test
    void searchFindsTitleLocationAndNotesSoonestFirst() {
        EventManager manager = manager(dir.resolve("search.dat").toFile());
        CalendarEvent past = new CalendarEvent("Dentist checkup", DAY.minusDays(30));
        CalendarEvent soon = new CalendarEvent("Cleaning", DAY.plusDays(2));
        soon.setLocation("Downtown DENTIST office");
        CalendarEvent later = new CalendarEvent("Follow-up", DAY.plusDays(20));
        later.setNotes("ask the dentist about x-rays");
        CalendarEvent other = new CalendarEvent("Groceries", DAY);
        for (CalendarEvent e : List.of(past, later, other, soon)) {
            manager.add(e);
        }
        assertEquals(List.of(soon, later, past), manager.search("dentist", DAY));
        assertTrue(manager.search("   ", DAY).isEmpty());
    }

    @Test
    void deletingOneDayOfAMultiDayRepeatRemovesThatWholeCopy() {
        EventManager manager = manager(dir.resolve("multi.dat").toFile());
        CalendarEvent weekend = new CalendarEvent("Cabin weekend", LocalDate.of(2026, 11, 6)); // a Friday
        weekend.setEndDate(LocalDate.of(2026, 11, 8));
        weekend.setRecurrence(Recurrence.WEEKLY);
        manager.add(weekend);
        manager.removeOccurrence(weekend.getId(), LocalDate.of(2026, 11, 14)); // the Saturday of the 2nd weekend
        assertFalse(manager.hasEventsOn(LocalDate.of(2026, 11, 13)));
        assertFalse(manager.hasEventsOn(LocalDate.of(2026, 11, 15)));
        assertTrue(manager.hasEventsOn(LocalDate.of(2026, 11, 21)));
    }
}

import org.junit.jupiter.api.Test;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.EnumSet;

import static org.junit.jupiter.api.Assertions.*;

class CalendarEventTest {
    private static final LocalDate FRI_NOV_13 = LocalDate.of(2026, 11, 13);

    @Test
    void oneTimeEventOnlyOccursOnItsDate() {
        CalendarEvent event = new CalendarEvent("Dentist", FRI_NOV_13);
        assertTrue(event.occursOn(FRI_NOV_13));
        assertFalse(event.occursOn(FRI_NOV_13.plusDays(1)));
        assertFalse(event.occursOn(FRI_NOV_13.minusDays(1)));
    }

    @Test
    void dailyEventRepeatsUntilEndDate() {
        CalendarEvent event = new CalendarEvent("Clean the house", FRI_NOV_13);
        event.setRecurrence(Recurrence.DAILY);
        event.setRepeatUntil(FRI_NOV_13.plusDays(3));
        assertFalse(event.occursOn(FRI_NOV_13.minusDays(1)));
        assertTrue(event.occursOn(FRI_NOV_13));
        assertTrue(event.occursOn(FRI_NOV_13.plusDays(3)));
        assertFalse(event.occursOn(FRI_NOV_13.plusDays(4)));
    }

    @Test
    void weeklyEventOnChosenDays() {
        // Joe picks the kids up Monday, Wednesday and Friday.
        CalendarEvent pickup = new CalendarEvent("School pickup", LocalDate.of(2026, 11, 9)); // a Monday
        pickup.setRecurrence(Recurrence.WEEKLY);
        pickup.setRepeatDays(EnumSet.of(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY));
        assertTrue(pickup.occursOn(LocalDate.of(2026, 11, 9)));
        assertFalse(pickup.occursOn(LocalDate.of(2026, 11, 10)));
        assertTrue(pickup.occursOn(LocalDate.of(2026, 11, 11)));
        assertTrue(pickup.occursOn(LocalDate.of(2026, 11, 13)));
        assertTrue(pickup.occursOn(LocalDate.of(2026, 12, 2)));
        assertFalse(pickup.occursOn(LocalDate.of(2026, 11, 14)));
    }

    @Test
    void weeklyEventWithoutChosenDaysUsesItsStartWeekday() {
        CalendarEvent event = new CalendarEvent("Groceries", LocalDate.of(2026, 11, 10)); // Tuesday
        event.setRecurrence(Recurrence.WEEKLY);
        assertEquals(EnumSet.of(DayOfWeek.TUESDAY), event.effectiveRepeatDays());
        assertTrue(event.occursOn(LocalDate.of(2026, 11, 17)));
        assertFalse(event.occursOn(LocalDate.of(2026, 11, 18)));
    }

    @Test
    void monthlyEventOnThe31stSkipsShortMonths() {
        CalendarEvent rent = new CalendarEvent("Rent", LocalDate.of(2026, 1, 31));
        rent.setRecurrence(Recurrence.MONTHLY);
        assertTrue(rent.occursOn(LocalDate.of(2026, 3, 31)));
        assertFalse(rent.occursOn(LocalDate.of(2026, 2, 28)));
        assertFalse(rent.occursOn(LocalDate.of(2026, 4, 30)));
    }

    @Test
    void yearlyEventOnLeapDayOnlyInLeapYears() {
        CalendarEvent birthday = new CalendarEvent("Birthday", LocalDate.of(2028, 2, 29));
        birthday.setRecurrence(Recurrence.YEARLY);
        assertFalse(birthday.occursOn(LocalDate.of(2029, 2, 28)));
        assertTrue(birthday.occursOn(LocalDate.of(2032, 2, 29)));
    }

    @Test
    void skippedDateHidesOneRepeat() {
        CalendarEvent event = new CalendarEvent("Office hours", FRI_NOV_13);
        event.setRecurrence(Recurrence.WEEKLY);
        event.skipDate(FRI_NOV_13.plusWeeks(1));
        assertTrue(event.occursOn(FRI_NOV_13));
        assertFalse(event.occursOn(FRI_NOV_13.plusWeeks(1)));
        assertTrue(event.occursOn(FRI_NOV_13.plusWeeks(2)));
    }

    @Test
    void invalidValuesAreRejected() {
        assertThrows(IllegalArgumentException.class, () -> new CalendarEvent("   ", FRI_NOV_13));
        CalendarEvent event = new CalendarEvent("Meeting", FRI_NOV_13);
        assertThrows(IllegalArgumentException.class,
            () -> event.setTimes(LocalTime.of(10, 0), LocalTime.of(9, 0)));
        assertThrows(IllegalArgumentException.class, () -> event.setTimes(null, LocalTime.of(9, 0)));
        assertThrows(IllegalArgumentException.class, () -> event.setRepeatUntil(FRI_NOV_13.minusDays(1)));
    }

    @Test
    void copyIsIndependentButKeepsId() {
        CalendarEvent event = new CalendarEvent("Meeting", FRI_NOV_13);
        event.setTimes(LocalTime.of(9, 0), LocalTime.of(10, 0));
        CalendarEvent copy = event.copy();
        copy.setTitle("Renamed");
        copy.skipDate(FRI_NOV_13);
        assertEquals("Meeting", event.getTitle());
        assertTrue(event.getSkippedDates().isEmpty());
        assertEquals(event.getId(), copy.getId());
        assertEquals(event, copy);
    }

    @Test
    void multiDayEventsCoverEveryDayAndKnowWhereTheyStarted() {
        CalendarEvent trip = new CalendarEvent("Trip", LocalDate.of(2026, 11, 26));
        trip.setEndDate(LocalDate.of(2026, 11, 29));
        assertEquals(3, trip.spanDays());
        assertFalse(trip.occursOn(LocalDate.of(2026, 11, 25)));
        for (int d = 26; d <= 29; d++) {
            LocalDate day = LocalDate.of(2026, 11, d);
            assertTrue(trip.occursOn(day));
            Occurrence o = new Occurrence(trip, day);
            assertEquals(LocalDate.of(2026, 11, 26), o.start());
            assertEquals(d == 26, o.isFirstDay());
            assertEquals(d == 29, o.isLastDay());
        }
        assertFalse(trip.occursOn(LocalDate.of(2026, 11, 30)));

        trip.setDate(LocalDate.of(2026, 12, 1));
        assertEquals(LocalDate.of(2026, 12, 4), trip.getEndDate(), "moving the start keeps the length");
        assertThrows(IllegalArgumentException.class, () -> trip.setEndDate(LocalDate.of(2026, 11, 30)));
    }

    @Test
    void timedMultiDayEventsMayEndEarlierInTheDay() {
        CalendarEvent flight = new CalendarEvent("Red-eye", LocalDate.of(2026, 11, 20));
        flight.setEndDate(LocalDate.of(2026, 11, 21));
        flight.setTimes(LocalTime.of(22, 0), LocalTime.of(6, 30));
        assertEquals("Nov 20, 10:00 PM \u2013 Nov 21, 6:30 AM", Formats.timeRange(flight));
        flight.setEndDate(null);
        assertThrows(IllegalArgumentException.class, () -> flight.setTimes(LocalTime.of(22, 0), LocalTime.of(6, 30)));
    }

    @Test
    void repeatIntervals() {
        CalendarEvent biweekly = new CalendarEvent("Payday", LocalDate.of(2026, 11, 6)); // Friday
        biweekly.setRecurrence(Recurrence.WEEKLY);
        biweekly.setInterval(2);
        assertTrue(biweekly.occursOn(LocalDate.of(2026, 11, 6)));
        assertFalse(biweekly.occursOn(LocalDate.of(2026, 11, 13)));
        assertTrue(biweekly.occursOn(LocalDate.of(2026, 11, 20)));
        assertEquals("Every 2 weeks on Fri", Formats.repeatSummary(biweekly));

        CalendarEvent everyThirdDay = new CalendarEvent("Water plants", LocalDate.of(2026, 11, 1));
        everyThirdDay.setRecurrence(Recurrence.DAILY);
        everyThirdDay.setInterval(3);
        assertTrue(everyThirdDay.occursOn(LocalDate.of(2026, 11, 4)));
        assertFalse(everyThirdDay.occursOn(LocalDate.of(2026, 11, 5)));

        CalendarEvent quarterly = new CalendarEvent("Taxes", LocalDate.of(2026, 1, 15));
        quarterly.setRecurrence(Recurrence.MONTHLY);
        quarterly.setInterval(3);
        assertTrue(quarterly.occursOn(LocalDate.of(2026, 4, 15)));
        assertFalse(quarterly.occursOn(LocalDate.of(2026, 5, 15)));
        assertEquals("Every 3 months on day 15", Formats.repeatSummary(quarterly));

        CalendarEvent election = new CalendarEvent("Election", LocalDate.of(2024, 11, 5));
        election.setRecurrence(Recurrence.YEARLY);
        election.setInterval(4);
        assertTrue(election.occursOn(LocalDate.of(2028, 11, 5)));
        assertFalse(election.occursOn(LocalDate.of(2026, 11, 5)));

        assertThrows(IllegalArgumentException.class, () -> election.setInterval(0));
    }

    @Test
    void nextStartFindsTheNextCopy() {
        CalendarEvent weekly = new CalendarEvent("Club", LocalDate.of(2026, 11, 2)); // Monday
        weekly.setRecurrence(Recurrence.WEEKLY);
        assertEquals(LocalDate.of(2026, 11, 23), weekly.nextStartOnOrAfter(LocalDate.of(2026, 11, 18)));
        CalendarEvent once = new CalendarEvent("Once", LocalDate.of(2026, 11, 2));
        assertNull(once.nextStartOnOrAfter(LocalDate.of(2026, 11, 3)));
    }
}

import java.time.LocalDate;
import java.time.YearMonth;

/** The three ways to look at the calendar, and how far the arrows move in each. */
public enum ViewMode {
    DAY("Day"),
    WEEK("Week"),
    MONTH("Month");

    private final String label;

    ViewMode(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }

    /** The date one step forward (+1) or back (-1) from {@code date} in this view. */
    public LocalDate step(LocalDate date, int direction) {
        return step(date, direction, date.getDayOfMonth());
    }

    /**
     * Like {@link #step(LocalDate, int)}, but month steps aim for {@code preferredDayOfMonth}
     * (clamped to the month's length). This way Jan 31 -> Feb 28 -> Mar 31, instead of
     * drifting to Mar 28 because February was short.
     */
    public LocalDate step(LocalDate date, int direction, int preferredDayOfMonth) {
        if (this == MONTH) {
            YearMonth month = YearMonth.from(date).plusMonths(direction);
            return month.atDay(Math.min(Math.max(1, preferredDayOfMonth), month.lengthOfMonth()));
        }
        switch (this) {
            case DAY:
                return date.plusDays(direction);
            case WEEK:
                return date.plusWeeks(direction);
            default:
                return date.plusMonths(direction);
        }
    }
}

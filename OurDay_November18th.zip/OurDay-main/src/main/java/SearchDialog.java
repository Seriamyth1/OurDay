import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.util.List;
import java.util.function.Consumer;

/**
 * Finds events by title, location or notes. Results update as you type; opening
 * one (double-click or Enter) shows its next date in Day view.
 */
public final class SearchDialog {
    private SearchDialog() {
    }

    /** A result: the event and the day to open for it. */
    private static final class Hit {
        final CalendarEvent event;
        final LocalDate day;
        final boolean upcoming;

        Hit(CalendarEvent event, LocalDate today) {
            this.event = event;
            LocalDate next = event.nextStartOnOrAfter(today);
            this.upcoming = next != null;
            this.day = next != null ? next : lastStart(event, today);
        }

        private static LocalDate lastStart(CalendarEvent event, LocalDate today) {
            if (!event.isRepeating()) {
                return event.getDate();
            }
            for (LocalDate day = today; !day.isBefore(event.getDate()); day = day.minusDays(1)) {
                if (event.startsOn(day)) {
                    return day;
                }
            }
            return event.getDate();
        }
    }

    public static void show(Component owner, EventManager manager, String initialQuery, Consumer<LocalDate> openDay) {
        Window parent = owner instanceof Window ? (Window) owner : SwingUtilities.getWindowAncestor(owner);
        JDialog dialog = new JDialog(parent, "Search events", Dialog.ModalityType.APPLICATION_MODAL);
        JTextField query = new JTextField(initialQuery, 28);
        DefaultListModel<Hit> model = new DefaultListModel<>();
        JList<Hit> results = new JList<>(model);
        results.setCellRenderer(new HitRenderer());
        results.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JLabel status = new JLabel(" ");
        status.setForeground(ThemeManager.MUTED_TEXT);

        Runnable search = () -> {
            LocalDate today = LocalDate.now();
            model.clear();
            List<CalendarEvent> found = manager.search(query.getText(), today);
            for (CalendarEvent event : found) {
                model.addElement(new Hit(event, today));
            }
            if (!model.isEmpty()) {
                results.setSelectedIndex(0);
            }
            status.setText(query.getText().isBlank() ? "Type to search titles, locations and notes."
                : found.isEmpty() ? "No events match “" + query.getText().trim() + "”."
                : found.size() + (found.size() == 1 ? " event" : " events") + " · double-click or press Enter to open");
        };
        Runnable open = () -> {
            Hit hit = results.getSelectedValue();
            if (hit != null) {
                dialog.dispose();
                openDay.accept(hit.day);
            }
        };
        query.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                search.run();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                search.run();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                search.run();
            }
        });
        query.addActionListener(e -> open.run());
        // Up/Down in the search box move through the results.
        query.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, 0), "nextResult");
        query.getActionMap().put("nextResult", new AbstractAction() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                results.setSelectedIndex(Math.min(model.size() - 1, results.getSelectedIndex() + 1));
                results.ensureIndexIsVisible(results.getSelectedIndex());
            }
        });
        query.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_UP, 0), "previousResult");
        query.getActionMap().put("previousResult", new AbstractAction() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                results.setSelectedIndex(Math.max(0, results.getSelectedIndex() - 1));
                results.ensureIndexIsVisible(results.getSelectedIndex());
            }
        });
        results.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    open.run();
                }
            }
        });

        JButton openButton = new JButton("Open");
        openButton.addActionListener(e -> open.run());
        JButton close = new JButton("Close");
        close.addActionListener(e -> dialog.dispose());
        dialog.getRootPane().registerKeyboardAction(e -> dialog.dispose(),
            KeyStroke.getKeyStroke("ESCAPE"), JComponent.WHEN_IN_FOCUSED_WINDOW);

        JPanel top = new JPanel(new BorderLayout(8, 0));
        top.add(new JLabel("Find"), BorderLayout.WEST);
        top.add(query, BorderLayout.CENTER);
        JScrollPane scroll = new JScrollPane(results);
        scroll.setPreferredSize(new Dimension(480, 320));
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttons.add(close);
        buttons.add(openButton);
        JPanel bottom = new JPanel(new BorderLayout());
        bottom.add(status, BorderLayout.WEST);
        bottom.add(buttons, BorderLayout.EAST);

        JPanel content = new JPanel(new BorderLayout(0, 10));
        content.setBorder(BorderFactory.createEmptyBorder(14, 14, 10, 14));
        content.add(top, BorderLayout.NORTH);
        content.add(scroll, BorderLayout.CENTER);
        content.add(bottom, BorderLayout.SOUTH);
        dialog.setContentPane(content);
        search.run();
        dialog.pack();
        dialog.setLocationRelativeTo(parent);
        SwingUtilities.invokeLater(query::requestFocusInWindow);
        dialog.setVisible(true);
    }

    private static final class HitRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                      boolean isSelected, boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            Hit hit = (Hit) value;
            CalendarEvent event = hit.event;
            StringBuilder details = new StringBuilder(hit.upcoming ? "Next: " : "Last: ")
                .append(Formats.shortDay(hit.day));
            if (hit.day.getYear() != LocalDate.now().getYear()) {
                details.append(", ").append(hit.day.getYear());
            }
            if (!event.isAllDay()) {
                details.append(" · ").append(Formats.time(event.getStartTime()));
            }
            if (!event.getLocation().isEmpty()) {
                details.append(" · ").append(event.getLocation());
            }
            if (event.isRepeating()) {
                details.append(" · ").append(Formats.repeatSummary(event));
            }
            Color muted = isSelected ? list.getSelectionForeground() : ThemeManager.MUTED_TEXT;
            String hex = String.format("#%02x%02x%02x", muted.getRed(), muted.getGreen(), muted.getBlue());
            setText("<html><b>" + EventChip.escape(event.getTitle()) + "</b>" + (hit.upcoming ? "" : " <i>(past)</i>")
                + "<br><font color='" + hex + "'>" + EventChip.escape(details.toString()) + "</font></html>");
            setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 4, 1, 0, event.getCategory().color()),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)));
            return this;
        }
    }
}

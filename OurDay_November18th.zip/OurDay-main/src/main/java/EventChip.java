import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.function.Consumer;

/** A small colored label for one event, used in the month view and the all-day strips. */
public class EventChip extends JLabel {
    /** COMPACT: one line (month, all-day strip). MEDIUM: start time + title. NORMAL: full time range + title. */
    public enum Size { COMPACT, MEDIUM, NORMAL }

    private final Occurrence occurrence;

    public EventChip(Occurrence occurrence, Size size, Consumer<Occurrence> onClick) {
        this.occurrence = occurrence;
        CalendarEvent event = occurrence.event();
        Color color = event.getCategory().color();
        boolean compact = size == Size.COMPACT;

        if (compact) {
            putClientProperty("html.disable", Boolean.TRUE);
            setText(compactText(occurrence));
        } else if (size == Size.MEDIUM) {
            String when = occurrence.isAllDayOnThisDay() ? (event.isMultiDay() ? Formats.timeRange(occurrence) : "All day")
                : Formats.time(event.getStartTime());
            setText("<html><b>" + escape(when) + "</b><br>" + escape(event.getTitle()) + "</html>");
        } else {
            setText("<html><b>" + escape(Formats.timeRange(occurrence)) + "</b><br>" + escape(event.getTitle()) + "</html>");
        }
        setFont(new Font("SansSerif", Font.PLAIN, compact ? 11 : 12));
        setForeground(ThemeManager.TEXT);
        setBackground(new Color(color.getRed(), color.getGreen(), color.getBlue(), ThemeManager.isDark() ? 90 : 42));
        setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 3, 0, 0, color),
            BorderFactory.createEmptyBorder(compact ? 3 : 5, 5, compact ? 3 : 5, 4)));
        setAlignmentX(LEFT_ALIGNMENT);
        setMaximumSize(new Dimension(Integer.MAX_VALUE, compact ? 24 : 60));
        setToolTipText(tooltip(occurrence));

        if (onClick != null) {
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    e.consume();
                    onClick.accept(occurrence);
                }
            });
        }
    }

    public Occurrence occurrence() {
        return occurrence;
    }

    /** "9 AM Standup", "Ski trip", or "→ Ski trip" on the later days of a multi-day event. */
    static String compactText(Occurrence occurrence) {
        CalendarEvent event = occurrence.event();
        if (event.isMultiDay()) {
            return occurrence.isFirstDay()
                ? (event.isAllDay() ? "" : Formats.time(event.getStartTime()).replace(":00", "") + " ") + event.getTitle()
                : "→ " + event.getTitle();
        }
        String time = event.isAllDay() ? "" : Formats.time(event.getStartTime());
        return time.isEmpty() ? event.getTitle() : time.replace(":00", "") + " " + event.getTitle();
    }

    /** Hover text: title, when, category, location, repeat, reminder and the start of the notes. */
    static String tooltip(Occurrence occurrence) {
        CalendarEvent event = occurrence.event();
        StringBuilder tip = new StringBuilder("<html><b>" + escape(event.getTitle()) + "</b><br>"
            + escape(Formats.timeRange(occurrence)) + " · " + event.getCategory().label());
        if (!event.getLocation().isEmpty()) {
            tip.append("<br>").append(escape(event.getLocation()));
        }
        if (event.isRepeating()) {
            tip.append("<br>").append(escape(Formats.repeatSummary(event)));
        }
        if (event.hasReminder()) {
            tip.append("<br>Reminder: ").append(Formats.reminder(event.getReminderMinutes()).toLowerCase());
        }
        if (!event.getNotes().isEmpty()) {
            String notes = event.getNotes().length() > 160 ? event.getNotes().substring(0, 157) + "..." : event.getNotes();
            tip.append("<br><i>").append(escape(notes).replace("\n", "<br>")).append("</i>");
        }
        return tip.append("</html>").toString();
    }

    // A translucent background on an opaque label needs the parent painted first.
    @Override
    protected void paintComponent(Graphics g) {
        g.setColor(getBackground());
        g.fillRect(0, 0, getWidth(), getHeight());
        super.paintComponent(g);
    }

    @Override
    public boolean isOpaque() {
        return false;
    }

    static String escape(String text) {
        return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}

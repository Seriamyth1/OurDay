import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.TextStyle;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.List;

/**
 * Day and Week view: one column per day with an hour-by-hour grid. Timed events are
 * drawn as blocks whose height matches their length; events that overlap sit side
 * by side. All-day and multi-day events are listed in a strip above the grid.
 *
 * Click empty space to add an event at that time, click an event to edit it, drag
 * an event to move it, or drag its bottom edge to change when it ends.
 */
public class TimeGridView extends JPanel {
    static final int HOUR_HEIGHT = 48;
    static final int GUTTER = 64;
    /** Dragging snaps to this many minutes. */
    static final int SNAP_MINUTES = 15;
    /** Clicking empty space starts the new event at the half hour clicked. */
    static final int CLICK_MINUTES = 30;
    /** Events shorter than this (or with no end time) are drawn this tall so their title fits. */
    static final int MIN_VISUAL_MINUTES = 30;
    private static final int DEFAULT_MINUTES = 60;
    private static final int RESIZE_HANDLE = 6;
    private static final int MAX_ALL_DAY_ROWS = 3;

    /** What the view asks its owner to do. */
    public interface Actions {
        /** Add an event on {@code day} at {@code time} (null: an all-day event). */
        void add(LocalDate day, LocalTime time);

        void edit(Occurrence occurrence);

        /** Show this day on its own (week view day headings). */
        void openDay(LocalDate day);

        /**
         * Move or resize an event: its copy should start on {@code newStartDay} at
         * {@code start} and end at {@code end} (null: no end time).
         * Returns true if the event was changed (the owner then redraws the view).
         */
        boolean move(Occurrence occurrence, LocalDate newStartDay, LocalTime start, LocalTime end);
    }

    private final List<LocalDate> days;
    private final Actions actions;
    private final LocalDate selected;
    private final GridCanvas canvas;
    private final JScrollPane scroll;

    public TimeGridView(List<LocalDate> days, EventManager manager, LocalDate selected, Actions actions) {
        super(new BorderLayout());
        this.days = List.copyOf(days);
        this.actions = actions;
        this.selected = selected;
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(8, 0, 8, 0));

        Map<LocalDate, List<Occurrence>> allDay = new LinkedHashMap<>();
        Map<LocalDate, List<Occurrence>> timed = new LinkedHashMap<>();
        for (LocalDate day : this.days) {
            List<Occurrence> top = new ArrayList<>();
            List<Occurrence> grid = new ArrayList<>();
            for (Occurrence occurrence : manager.getOccurrences(day)) {
                (occurrence.isAllDayOnThisDay() ? top : grid).add(occurrence);
            }
            allDay.put(day, top);
            timed.put(day, grid);
        }

        canvas = new GridCanvas(timed);
        scroll = new JScrollPane(canvas, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
            ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setBorder(null);

        JPanel top = new JPanel();
        top.setOpaque(false);
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
        if (this.days.size() > 1) {
            top.add(columnRow(headings()));
        }
        top.add(allDayStrip(allDay));
        add(top, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);

        scrollToInterestingTime(timed);
    }

    // --- top area: day headings and the all-day strip ---

    /** Lays components out in the same columns as the grid below (after the hour gutter). */
    private JPanel columnRow(List<? extends JComponent> cells) {
        JPanel row = new JPanel(new GridLayout(1, cells.size(), 0, 0)) {
            @Override
            public Insets getInsets() {
                return new Insets(0, GUTTER, 0, scroll.getVerticalScrollBar().getPreferredSize().width);
            }
        };
        row.setOpaque(false);
        cells.forEach(row::add);
        row.setAlignmentX(LEFT_ALIGNMENT);
        return row;
    }

    private List<JComponent> headings() {
        List<JComponent> headings = new ArrayList<>();
        LocalDate today = LocalDate.now();
        for (LocalDate day : days) {
            JLabel heading = new JLabel("<html><center>" + day.getDayOfWeek().getDisplayName(TextStyle.SHORT, Locale.US)
                + "<br><font size='+1'>" + day.getDayOfMonth() + "</font></center></html>", SwingConstants.CENTER);
            heading.setFont(ThemeManager.SUBTITLE_FONT);
            heading.setForeground(day.equals(today) ? ThemeManager.ACCENT : ThemeManager.TEXT);
            heading.setBorder(day.equals(selected)
                ? BorderFactory.createMatteBorder(0, 0, 2, 0, ThemeManager.ACCENT)
                : BorderFactory.createEmptyBorder(0, 0, 2, 0));
            heading.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            heading.setToolTipText("Open " + Formats.fullDay(day));
            heading.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    actions.openDay(day);
                }
            });
            headings.add(heading);
        }
        return headings;
    }

    private JComponent allDayStrip(Map<LocalDate, List<Occurrence>> allDay) {
        boolean single = days.size() == 1;
        List<JComponent> cells = new ArrayList<>();
        int tallest = 0;
        for (LocalDate day : days) {
            List<Occurrence> list = allDay.get(day);
            JPanel cell = new JPanel(single && !list.isEmpty()
                ? new GridLayout(0, 3, 4, 3)
                : new GridLayout(0, 1, 0, 3));
            cell.setOpaque(false);
            cell.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
            for (Occurrence occurrence : list) {
                EventChip chip = new EventChip(occurrence, EventChip.Size.COMPACT, actions::edit);
                chip.setPreferredSize(new Dimension(40, chip.getPreferredSize().height));
                cell.add(chip);
            }
            String tip = "Click to add an all-day event on " + Formats.shortDay(day);
            MouseAdapter addAllDay = new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    actions.add(day, null);
                }
            };
            cell.setToolTipText(tip);
            cell.addMouseListener(addAllDay);
            int rows = single ? (list.size() + 2) / 3 : list.size();
            tallest = Math.max(tallest, rows);
            JPanel holder = new JPanel(new BorderLayout());
            holder.setOpaque(false);
            holder.add(cell, BorderLayout.NORTH);
            holder.addMouseListener(addAllDay);
            holder.setToolTipText(tip);
            cells.add(holder);
        }
        JPanel row = columnRow(cells);
        JLabel label = new JLabel("All day");
        label.setFont(new Font("SansSerif", Font.PLAIN, 11));
        label.setForeground(ThemeManager.MUTED_TEXT);

        JPanel strip = new JPanel(new BorderLayout()) {
            @Override
            public Dimension getPreferredSize() {
                // Always tall enough to click, even with no all-day events.
                Dimension size = super.getPreferredSize();
                return new Dimension(size.width, Math.max(size.height, 26));
            }

            @Override
            protected void paintComponent(Graphics g) {
                g.setColor(ThemeManager.BORDER);
                g.drawLine(0, getHeight() - 1, getWidth(), getHeight() - 1);
            }
        };
        strip.setOpaque(false);
        strip.add(row, BorderLayout.CENTER);
        JPanel labelHolder = new JPanel(null);
        labelHolder.setOpaque(false);
        label.setBounds(10, 5, GUTTER - 12, 16);
        labelHolder.add(label);
        // The label sits over the gutter part of the row.
        JLayeredPane layers = new JLayeredPane() {
            @Override
            public void doLayout() {
                strip.setBounds(0, 0, getWidth(), getHeight());
                labelHolder.setBounds(0, 0, GUTTER, getHeight());
            }

            @Override
            public Dimension getPreferredSize() {
                return strip.getPreferredSize();
            }
        };
        layers.add(strip, JLayeredPane.DEFAULT_LAYER);
        layers.add(labelHolder, JLayeredPane.PALETTE_LAYER);
        layers.setAlignmentX(LEFT_ALIGNMENT);

        if (tallest <= MAX_ALL_DAY_ROWS) {
            return layers;
        }
        // Lots of all-day events: keep the strip a sensible height and let it scroll.
        JScrollPane stripScroll = new JScrollPane(layers, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
            ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER) {
            @Override
            public Dimension getPreferredSize() {
                int chipHeight = 24;
                return new Dimension(super.getPreferredSize().width, MAX_ALL_DAY_ROWS * chipHeight + 12);
            }
        };
        stripScroll.setOpaque(false);
        stripScroll.getViewport().setOpaque(false);
        stripScroll.setBorder(null);
        stripScroll.setAlignmentX(LEFT_ALIGNMENT);
        return stripScroll;
    }

    private void scrollToInterestingTime(Map<LocalDate, List<Occurrence>> timed) {
        int targetHour = 7;
        boolean showsToday = days.contains(LocalDate.now());
        if (showsToday) {
            targetHour = Math.max(0, LocalTime.now().getHour() - 1);
        } else {
            for (List<Occurrence> list : timed.values()) {
                for (Occurrence o : list) {
                    targetHour = Math.min(targetHour, o.event().getStartTime().getHour());
                }
            }
        }
        int y = targetHour * HOUR_HEIGHT;
        // Scrolling must wait until the viewport has its real size.
        scroll.getViewport().addComponentListener(new java.awt.event.ComponentAdapter() {
            private boolean done;

            @Override
            public void componentResized(java.awt.event.ComponentEvent e) {
                JViewport viewport = scroll.getViewport();
                if (done || viewport.getHeight() == 0) {
                    return;
                }
                done = true;
                int max = Math.max(0, canvas.getPreferredSize().height - viewport.getHeight());
                viewport.setViewPosition(new Point(0, Math.min(y, max)));
            }
        });
    }

    // --- the hour grid ---

    /** Start and (drawn) end of an event in minutes after midnight, plus its place among overlapping events. */
    private static final class Slot {
        final Occurrence occurrence;
        final int start;
        final int end;
        int column;
        int columns = 1;

        Slot(Occurrence occurrence) {
            this.occurrence = occurrence;
            CalendarEvent event = occurrence.event();
            this.start = minutes(event.getStartTime());
            int realEnd = event.getEndTime() == null ? start + DEFAULT_MINUTES : minutes(event.getEndTime());
            this.end = Math.min(24 * 60, Math.max(realEnd, start + MIN_VISUAL_MINUTES));
        }
    }

    static int minutes(LocalTime time) {
        return time.getHour() * 60 + time.getMinute();
    }

    /**
     * Gives overlapping events side-by-side columns: events are grouped into runs that
     * overlap each other, and within a run each takes the first free column.
     */
    static void arrange(List<Slot> slots) {
        slots.sort(Comparator.<Slot>comparingInt(s -> s.start).thenComparingInt(s -> -s.end));
        List<Slot> group = new ArrayList<>();
        List<Integer> columnEnds = new ArrayList<>();
        int groupEnd = -1;
        for (Slot slot : slots) {
            if (slot.start >= groupEnd && !group.isEmpty()) {
                finishGroup(group, columnEnds.size());
                group.clear();
                columnEnds.clear();
            }
            int column = 0;
            while (column < columnEnds.size() && columnEnds.get(column) > slot.start) {
                column++;
            }
            if (column == columnEnds.size()) {
                columnEnds.add(slot.end);
            } else {
                columnEnds.set(column, slot.end);
            }
            slot.column = column;
            group.add(slot);
            groupEnd = Math.max(groupEnd, slot.end);
        }
        finishGroup(group, columnEnds.size());
    }

    private static void finishGroup(List<Slot> group, int columns) {
        for (Slot slot : group) {
            slot.columns = columns;
        }
    }

    private final class GridCanvas extends JPanel implements Scrollable {
        private final Map<LocalDate, List<Slot>> slots = new LinkedHashMap<>();
        private final Map<EventBlock, Slot> blocks = new LinkedHashMap<>();
        private javax.swing.Timer clock;

        GridCanvas(Map<LocalDate, List<Occurrence>> timed) {
            super(null);
            setOpaque(false);
            for (LocalDate day : days) {
                List<Slot> daySlots = new ArrayList<>();
                for (Occurrence occurrence : timed.get(day)) {
                    daySlots.add(new Slot(occurrence));
                }
                arrange(daySlots);
                slots.put(day, daySlots);
                for (Slot slot : daySlots) {
                    EventBlock block = new EventBlock(slot, day);
                    blocks.put(block, slot);
                    add(block);
                }
            }
            setToolTipText(""); // enables getToolTipText(MouseEvent)
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    LocalDate day = dayAt(e.getX());
                    if (day != null) {
                        int minute = Math.max(0, Math.min(24 * 60 - CLICK_MINUTES,
                            e.getY() * 60 / HOUR_HEIGHT / CLICK_MINUTES * CLICK_MINUTES));
                        actions.add(day, LocalTime.of(minute / 60, minute % 60));
                    }
                }
            });
        }

        @Override
        public String getToolTipText(MouseEvent e) {
            LocalDate day = dayAt(e.getX());
            if (day == null) {
                return null;
            }
            int minute = Math.max(0, Math.min(24 * 60 - CLICK_MINUTES, e.getY() * 60 / HOUR_HEIGHT / CLICK_MINUTES * CLICK_MINUTES));
            return "Click to add an event on " + Formats.shortDay(day) + " at "
                + Formats.time(LocalTime.of(minute / 60, minute % 60));
        }

        int columnWidth() {
            return Math.max(1, (getWidth() - GUTTER) / days.size());
        }

        int columnX(int index) {
            return GUTTER + index * columnWidth();
        }

        LocalDate dayAt(int x) {
            if (x < GUTTER) {
                return null;
            }
            int index = Math.min(days.size() - 1, (x - GUTTER) / columnWidth());
            return days.get(index);
        }

        @Override
        public void doLayout() {
            int width = columnWidth();
            for (Map.Entry<EventBlock, Slot> entry : blocks.entrySet()) {
                EventBlock block = entry.getKey();
                if (block.dragging) {
                    continue;
                }
                Slot slot = entry.getValue();
                int dayIndex = days.indexOf(block.day);
                int slotWidth = (width - 6) / slot.columns;
                int x = columnX(dayIndex) + 2 + slot.column * slotWidth;
                int y = slot.start * HOUR_HEIGHT / 60;
                int height = (slot.end - slot.start) * HOUR_HEIGHT / 60;
                block.setBounds(x, y + 1, Math.max(8, slotWidth - 2), Math.max(14, height - 2));
            }
        }

        @Override
        public Dimension getPreferredSize() {
            return new Dimension(GUTTER + days.size() * 100, 24 * HOUR_HEIGHT + 1);
        }

        @Override
        protected void paintComponent(Graphics graphics) {
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            int width = getWidth();
            LocalDate today = LocalDate.now();
            int todayIndex = days.indexOf(today);
            if (todayIndex >= 0 && days.size() > 1) {
                g.setColor(new Color(ThemeManager.ACCENT.getRed(), ThemeManager.ACCENT.getGreen(),
                    ThemeManager.ACCENT.getBlue(), 18));
                g.fillRect(columnX(todayIndex), 0, columnWidth(), getHeight());
            }
            g.setFont(new Font("SansSerif", Font.PLAIN, 11));
            FontMetrics fm = g.getFontMetrics();
            Stroke dashed = new BasicStroke(1f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 1f, new float[]{2f, 3f}, 0f);
            for (int hour = 0; hour < 24; hour++) {
                int y = hour * HOUR_HEIGHT;
                g.setColor(ThemeManager.BORDER);
                g.setStroke(new BasicStroke(1f));
                g.drawLine(GUTTER - 6, y, width, y);
                g.setStroke(dashed);
                g.drawLine(GUTTER, y + HOUR_HEIGHT / 2, width, y + HOUR_HEIGHT / 2);
                if (hour > 0) {
                    String label = Formats.hour(hour);
                    g.setColor(ThemeManager.MUTED_TEXT);
                    g.drawString(label, GUTTER - 10 - fm.stringWidth(label), y + fm.getAscent() / 2 - 1);
                }
            }
            g.setStroke(new BasicStroke(1f));
            g.setColor(ThemeManager.BORDER);
            for (int i = 0; i <= days.size(); i++) {
                g.drawLine(columnX(i), 0, columnX(i), getHeight());
            }
            if (todayIndex >= 0) {
                int y = minutes(LocalTime.now()) * HOUR_HEIGHT / 60;
                int x = columnX(todayIndex);
                g.setColor(ThemeManager.NOW_LINE);
                g.setStroke(new BasicStroke(2f));
                g.drawLine(x, y, x + columnWidth(), y);
                g.fillOval(x - 4, y - 4, 8, 8);
            }
            g.dispose();
        }

        // Keep the red "now" line moving while the view is on screen.
        @Override
        public void addNotify() {
            super.addNotify();
            clock = new javax.swing.Timer(60_000, e -> repaint());
            clock.start();
        }

        @Override
        public void removeNotify() {
            if (clock != null) {
                clock.stop();
            }
            super.removeNotify();
        }

        // Scrollable: always as wide as the window, only scroll up and down.
        @Override
        public Dimension getPreferredScrollableViewportSize() {
            return getPreferredSize();
        }

        @Override
        public int getScrollableUnitIncrement(Rectangle visible, int orientation, int direction) {
            return HOUR_HEIGHT / 2;
        }

        @Override
        public int getScrollableBlockIncrement(Rectangle visible, int orientation, int direction) {
            return Math.max(HOUR_HEIGHT, visible.height - HOUR_HEIGHT);
        }

        @Override
        public boolean getScrollableTracksViewportWidth() {
            return true;
        }

        @Override
        public boolean getScrollableTracksViewportHeight() {
            return false;
        }
    }

    // --- one event in the grid ---

    private final class EventBlock extends JComponent {
        private final Slot slot;
        private final LocalDate day;
        private final Color color;
        boolean dragging;
        private boolean resizing;
        private Point pressedAt;
        private Rectangle startBounds;

        EventBlock(Slot slot, LocalDate day) {
            this.slot = slot;
            this.day = day;
            CalendarEvent event = slot.occurrence.event();
            this.color = event.getCategory().color();
            setToolTipText(EventChip.tooltip(slot.occurrence));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            MouseAdapter mouse = new MouseAdapter() {
                @Override
                public void mouseMoved(MouseEvent e) {
                    setCursor(Cursor.getPredefinedCursor(e.getY() >= getHeight() - RESIZE_HANDLE
                        ? Cursor.S_RESIZE_CURSOR : Cursor.HAND_CURSOR));
                }

                @Override
                public void mousePressed(MouseEvent e) {
                    if (!SwingUtilities.isLeftMouseButton(e)) {
                        return;
                    }
                    pressedAt = SwingUtilities.convertPoint(EventBlock.this, e.getPoint(), canvas);
                    startBounds = getBounds();
                    resizing = e.getY() >= getHeight() - RESIZE_HANDLE;
                }

                @Override
                public void mouseDragged(MouseEvent e) {
                    if (pressedAt == null) {
                        return;
                    }
                    Point now = SwingUtilities.convertPoint(EventBlock.this, e.getPoint(), canvas);
                    int dx = now.x - pressedAt.x;
                    int dy = now.y - pressedAt.y;
                    if (!dragging && Math.abs(dx) + Math.abs(dy) < 5) {
                        return;
                    }
                    dragging = true;
                    if (resizing) {
                        int minutes = snap((slot.end - slot.start) + dy * 60 / HOUR_HEIGHT);
                        minutes = Math.max(SNAP_MINUTES, Math.min(minutes, 24 * 60 - slot.start));
                        setBounds(startBounds.x, startBounds.y, startBounds.width, minutes * HOUR_HEIGHT / 60 - 2);
                    } else {
                        setCursor(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));
                        int newStart = clampStart(slot.start + snap(dy * 60 / HOUR_HEIGHT));
                        LocalDate target = canvas.dayAt(Math.max(GUTTER, now.x));
                        int x = canvas.columnX(days.indexOf(target)) + 2;
                        setBounds(x, newStart * HOUR_HEIGHT / 60 + 1, canvas.columnWidth() - 6, startBounds.height);
                        canvas.setComponentZOrder(EventBlock.this, 0);
                    }
                    canvas.repaint();
                }

                @Override
                public void mouseReleased(MouseEvent e) {
                    if (pressedAt == null) {
                        return;
                    }
                    Point now = SwingUtilities.convertPoint(EventBlock.this, e.getPoint(), canvas);
                    boolean wasDragging = dragging;
                    dragging = false;
                    pressedAt = null;
                    if (!wasDragging) {
                        actions.edit(slot.occurrence);
                        return;
                    }
                    int dy = getBounds().y - startBounds.y;
                    CalendarEvent event = slot.occurrence.event();
                    LocalTime oldStart = event.getStartTime();
                    boolean changed;
                    if (resizing) {
                        int newEnd = Math.min(24 * 60 - 1, slot.start + (getHeight() + 2) * 60 / HOUR_HEIGHT);
                        newEnd = Math.max(slot.start + SNAP_MINUTES, snap(newEnd));
                        LocalTime end = newEnd >= 24 * 60 ? LocalTime.of(23, 59) : LocalTime.of(newEnd / 60, newEnd % 60);
                        changed = actions.move(slot.occurrence, slot.occurrence.start(), oldStart, end);
                    } else {
                        int shift = snap(dy * 60 / HOUR_HEIGHT);
                        int newStart = clampStart(slot.start + shift);
                        LocalDate target = canvas.dayAt(Math.max(GUTTER, now.x));
                        long dayShift = ChronoUnit.DAYS.between(day, target);
                        LocalTime start = LocalTime.of(newStart / 60, newStart % 60);
                        LocalTime end = null;
                        if (event.getEndTime() != null) {
                            long length = Duration.between(oldStart, event.getEndTime()).toMinutes();
                            int endMinute = (int) Math.min(24 * 60 - 1, newStart + length);
                            end = LocalTime.of(endMinute / 60, endMinute % 60);
                        }
                        boolean moved = dayShift != 0 || !start.equals(oldStart);
                        changed = moved && actions.move(slot.occurrence,
                            slot.occurrence.start().plusDays(dayShift), start, end);
                    }
                    if (!changed) {
                        canvas.revalidate(); // put the block back where it was
                        canvas.doLayout();
                        canvas.repaint();
                    }
                }
            };
            addMouseListener(mouse);
            addMouseMotionListener(mouse);
        }

        private int snap(int minutes) {
            return Math.round(minutes / (float) SNAP_MINUTES) * SNAP_MINUTES;
        }

        private int clampStart(int minute) {
            return Math.max(0, Math.min(24 * 60 - SNAP_MINUTES, minute));
        }

        @Override
        protected void paintComponent(Graphics graphics) {
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            Color fill = ThemeManager.isDark()
                ? new Color(color.getRed() / 2 + 20, color.getGreen() / 2 + 20, color.getBlue() / 2 + 25, dragging ? 200 : 235)
                : new Color(
                    255 - (255 - color.getRed()) * 30 / 100,
                    255 - (255 - color.getGreen()) * 30 / 100,
                    255 - (255 - color.getBlue()) * 30 / 100, dragging ? 200 : 250);
            g.setColor(fill);
            g.fillRoundRect(0, 0, w, h, 8, 8);
            g.setColor(color);
            g.fillRoundRect(0, 0, 4, h, 4, 4);
            if (dragging) {
                g.setColor(ThemeManager.ACCENT);
                g.drawRoundRect(0, 0, w - 1, h - 1, 8, 8);
            }

            CalendarEvent event = slot.occurrence.event();
            g.clipRect(6, 0, w - 8, h); // narrow the existing clip (setClip would draw outside the scroll area)
            g.setColor(ThemeManager.TEXT);
            Font bold = new Font("SansSerif", Font.BOLD, 11);
            Font plain = new Font("SansSerif", Font.PLAIN, 11);
            String time = Formats.timeRange(event);
            int y = 13;
            if (h < 30) {
                // Short block: title and start time on one line.
                g.setFont(bold);
                g.drawString(event.getTitle(), 8, y);
                int tw = g.getFontMetrics().stringWidth(event.getTitle() + "  ");
                g.setFont(plain);
                g.setColor(ThemeManager.MUTED_TEXT);
                g.drawString(Formats.time(event.getStartTime()), 8 + tw, y);
            } else {
                g.setFont(bold);
                y = drawWrapped(g, event.getTitle(), 8, y, w - 12, Math.max(1, (h - 16) / 13 - 1));
                g.setFont(plain);
                g.setColor(ThemeManager.MUTED_TEXT);
                if (y + 2 < h) {
                    g.drawString(time, 8, y);
                    y += 13;
                }
                if (!event.getLocation().isEmpty() && y + 2 < h) {
                    g.drawString(event.getLocation(), 8, y);
                }
            }
            g.dispose();
        }

        /** Draws text over up to {@code maxLines} lines; returns the baseline for the next line. */
        private int drawWrapped(Graphics2D g, String text, int x, int y, int width, int maxLines) {
            FontMetrics fm = g.getFontMetrics();
            String[] words = text.split(" ");
            StringBuilder line = new StringBuilder();
            int lines = 0;
            for (int i = 0; i < words.length; i++) {
                String attempt = line.length() == 0 ? words[i] : line + " " + words[i];
                if (fm.stringWidth(attempt) > width && line.length() > 0) {
                    lines++;
                    if (lines == maxLines) {
                        g.drawString(line + "…", x, y);
                        return y + 13;
                    }
                    g.drawString(line.toString(), x, y);
                    y += 13;
                    line = new StringBuilder(words[i]);
                } else {
                    line = new StringBuilder(attempt);
                }
            }
            g.drawString(line.toString(), x, y);
            return y + 13;
        }
    }

    /** The days shown, in order. */
    public List<LocalDate> days() {
        return days;
    }
}

import java.io.File;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.channels.OverlappingFileLockException;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;

/**
 * Makes sure only one OurDay window uses the events file at a time. Each window
 * keeps its own copy of the events in memory and saves the whole list, so two
 * windows open at once would quietly erase each other's changes.
 *
 * The operating system releases the lock automatically when OurDay exits, even
 * after a crash, so a stale lock never keeps OurDay from starting.
 */
public final class InstanceLock {
    static final String FILE_NAME = "ourday.lock";

    // Held for the life of the program; if these were garbage collected the lock could be released.
    private static FileChannel channel;
    private static FileLock lock;

    private InstanceLock() {
    }

    /**
     * Tries to become the running OurDay.
     *
     * @return true if this is the only OurDay using {@code dataDirectory}, false if another is already open
     */
    public static synchronized boolean acquire(File dataDirectory) {
        if (lock != null && lock.isValid()) {
            return true; // this program already holds it
        }
        try {
            Files.createDirectories(dataDirectory.toPath());
            FileChannel opened = FileChannel.open(new File(dataDirectory, FILE_NAME).toPath(),
                StandardOpenOption.CREATE, StandardOpenOption.WRITE);
            FileLock acquired;
            try {
                acquired = opened.tryLock();
            } catch (OverlappingFileLockException alreadyHeldHere) {
                acquired = null;
            }
            if (acquired == null) {
                opened.close();
                return false;
            }
            channel = opened;
            lock = acquired;
            return true;
        } catch (IOException ex) {
            // If locking isn't possible (e.g. an unusual file system), don't stop the user from working.
            System.err.println("OurDay: could not check for another open window: " + ex.getMessage());
            return true;
        }
    }

    /** Releases the lock (used by tests; the program itself just exits). */
    static synchronized void release() {
        try {
            if (lock != null) {
                lock.release();
            }
            if (channel != null) {
                channel.close();
            }
        } catch (IOException ignored) {
            // nothing useful to do
        } finally {
            lock = null;
            channel = null;
        }
    }
}

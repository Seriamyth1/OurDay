import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.Temporal;
import java.util.*;

/**
 * Reads and writes iCalendar (.ics) files, the standard format used by Google
 * Calendar, Apple Calendar and Outlook (RFC 5545). Only the parts OurDay can show
 * are used; anything else is skipped, and the import result says so.
 */
public final class ICalendar {
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("yyyyMMdd");
    private static final DateTimeFormatter DATE_TIME = DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss");
    private static final String[] WEEKDAY_CODES = {"MO", "TU", "WE", "TH", "FR", "SA", "SU"};
    /** All-day reminders in OurDay count back from 9:00 AM; iCal counts from midnight. */
    private static final int ALL_DAY_REMINDER_MINUTE = CalendarEvent.ALL_DAY_REMINDER_TIME.toSecondOfDay() / 60;

    private ICalendar() {
    }

    // =====================================================================
    // Export
    // =====================================================================

    /** The events as the text of a .ics file. Times are written as local ("floating") times. */
    public static String export(Collection<CalendarEvent> events, Instant now) {
        StringBuilder out = new StringBuilder();
        line(out, "BEGIN:VCALENDAR");
        line(out, "VERSION:2.0");
        line(out, "PRODID:-//OurDay//OurDay Calendar//EN");
        line(out, "CALSCALE:GREGORIAN");
        line(out, "X-WR-CALNAME:OurDay");
        String stamp = DATE_TIME.format(LocalDateTime.ofInstant(now, ZoneOffset.UTC)) + "Z";
        for (CalendarEvent e : events) {
            line(out, "BEGIN:VEVENT");
            line(out, "UID:" + e.getId());
            line(out, "DTSTAMP:" + stamp);
            line(out, "SUMMARY:" + escape(e.getTitle()));
            if (e.isAllDay()) {
                line(out, "DTSTART;VALUE=DATE:" + DATE.format(e.getDate()));
                line(out, "DTEND;VALUE=DATE:" + DATE.format(e.getEndDate().plusDays(1)));
            } else {
                line(out, "DTSTART:" + DATE_TIME.format(e.getDate().atTime(e.getStartTime())));
                if (e.getEndTime() != null) {
                    line(out, "DTEND:" + DATE_TIME.format(e.getEndDate().atTime(e.getEndTime())));
                } else if (e.isMultiDay()) {
                    line(out, "DTEND:" + DATE_TIME.format(e.getEndDate().plusDays(1).atStartOfDay()));
                }
            }
            if (!e.getLocation().isEmpty()) {
                line(out, "LOCATION:" + escape(e.getLocation()));
            }
            if (!e.getNotes().isEmpty()) {
                line(out, "DESCRIPTION:" + escape(e.getNotes()));
            }
            line(out, "CATEGORIES:" + escape(e.getCategory().label()));
            if (e.isRepeating()) {
                line(out, "RRULE:" + rrule(e));
                for (LocalDate skipped : e.getSkippedDates()) {
                    line(out, e.isAllDay()
                        ? "EXDATE;VALUE=DATE:" + DATE.format(skipped)
                        : "EXDATE:" + DATE_TIME.format(skipped.atTime(e.getStartTime())));
                }
            }
            if (e.hasReminder()) {
                int minutesBeforeStart = e.isAllDay()
                    ? e.getReminderMinutes() - ALL_DAY_REMINDER_MINUTE
                    : e.getReminderMinutes();
                line(out, "BEGIN:VALARM");
                line(out, "ACTION:DISPLAY");
                line(out, "DESCRIPTION:" + escape(e.getTitle()));
                line(out, "TRIGGER:" + duration(-minutesBeforeStart));
                line(out, "END:VALARM");
            }
            line(out, "END:VEVENT");
        }
        line(out, "END:VCALENDAR");
        return out.toString();
    }

    private static String rrule(CalendarEvent e) {
        StringBuilder rule = new StringBuilder("FREQ=").append(e.getRecurrence().name());
        if (e.getInterval() > 1) {
            rule.append(";INTERVAL=").append(e.getInterval());
        }
        if (e.getRecurrence() == Recurrence.WEEKLY) {
            StringJoiner days = new StringJoiner(",");
            for (DayOfWeek day : e.effectiveRepeatDays()) {
                days.add(WEEKDAY_CODES[day.getValue() - 1]);
            }
            rule.append(";BYDAY=").append(days);
        }
        if (e.getRepeatUntil() != null) {
            rule.append(";UNTIL=").append(e.isAllDay()
                ? DATE.format(e.getRepeatUntil())
                : DATE_TIME.format(e.getRepeatUntil().atTime(23, 59, 59)));
        }
        return rule.toString();
    }

    /** An iCal duration such as "-PT15M", "PT8H45M" or "-P1D". */
    static String duration(int minutes) {
        String sign = minutes < 0 ? "-" : "";
        int m = Math.abs(minutes);
        if (m == 0) {
            return "PT0S";
        }
        if (m % 1440 == 0) {
            return sign + "P" + (m / 1440) + "D";
        }
        StringBuilder d = new StringBuilder(sign).append("P");
        if (m >= 1440) {
            d.append(m / 1440).append("D");
            m %= 1440;
        }
        d.append("T");
        if (m >= 60) {
            d.append(m / 60).append("H");
        }
        if (m % 60 != 0) {
            d.append(m % 60).append("M");
        }
        return d.toString();
    }

    static String escape(String text) {
        return text.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,")
            .replace("\r\n", "\\n").replace("\n", "\\n").replace("\r", "\\n");
    }

    /** Adds one content line, folded so no physical line is longer than 75 bytes (as the standard requires). */
    private static void line(StringBuilder out, String text) {
        int bytes = 0;
        int limit = 75;
        for (int i = 0; i < text.length(); ) {
            int codePoint = text.codePointAt(i);
            int size = new String(Character.toChars(codePoint)).getBytes(StandardCharsets.UTF_8).length;
            if (bytes + size > limit) {
                out.append("\r\n ");
                bytes = 1;
            }
            out.appendCodePoint(codePoint);
            bytes += size;
            i += Character.charCount(codePoint);
        }
        out.append("\r\n");
    }

    // =====================================================================
    // Import
    // =====================================================================

    /** The events found in a file, plus a note for everything that couldn't be brought over exactly. */
    public static final class Result {
        public final List<CalendarEvent> events = new ArrayList<>();
        public final List<String> warnings = new ArrayList<>();
        /** Cancelled events, which are left out. */
        public int cancelled;
    }

    /** A property line: NAME;PARAM=value:VALUE */
    private static final class Property {
        final String name;
        final Map<String, String> params;
        final String value;

        Property(String name, Map<String, String> params, String value) {
            this.name = name;
            this.params = params;
            this.value = value;
        }

        String param(String key) {
            return params.get(key);
        }
    }

    /** One VEVENT: its properties and those of its first alarm. */
    private static final class Component {
        final List<Property> properties = new ArrayList<>();
        final List<Property> alarm = new ArrayList<>();
        boolean hasAlarm;

        Property first(String name) {
            for (Property p : properties) {
                if (p.name.equals(name)) {
                    return p;
                }
            }
            return null;
        }

        List<Property> all(String name) {
            List<Property> found = new ArrayList<>();
            for (Property p : properties) {
                if (p.name.equals(name)) {
                    found.add(p);
                }
            }
            return found;
        }
    }

    /**
     * Reads the events in .ics text. Times with a time zone are converted to
     * {@code localZone}; times without one are taken as they are.
     */
    public static Result parse(String text, ZoneId localZone) {
        Result result = new Result();
        if (!text.contains("BEGIN:VCALENDAR")) {
            result.warnings.add("This isn't an iCalendar (.ics) file.");
            return result;
        }
        List<Component> components = new ArrayList<>();
        Component current = null;
        boolean inAlarm = false;
        int depth = 0; // nesting inside the current VEVENT (alarms, etc.)
        String unfolded = text.replace("\r\n", "\n").replace("\r", "\n").replace("\n ", "").replace("\n\t", "");
        for (String raw : unfolded.split("\n")) {
            if (raw.isBlank()) {
                continue;
            }
            Property p = parseProperty(raw);
            if (p == null) {
                continue;
            }
            if (p.name.equals("BEGIN")) {
                if (current == null && p.value.equalsIgnoreCase("VEVENT")) {
                    current = new Component();
                } else if (current != null) {
                    depth++;
                    if (p.value.equalsIgnoreCase("VALARM") && !current.hasAlarm) {
                        inAlarm = true;
                        current.hasAlarm = true;
                    }
                }
            } else if (p.name.equals("END")) {
                if (current != null && depth == 0 && p.value.equalsIgnoreCase("VEVENT")) {
                    components.add(current);
                    current = null;
                } else if (current != null) {
                    depth--;
                    inAlarm = false;
                }
            } else if (current != null) {
                if (inAlarm) {
                    current.alarm.add(p);
                } else if (depth == 0) {
                    current.properties.add(p);
                }
            }
        }

        // Changed single copies of repeating events (RECURRENCE-ID) are imported as
        // their own events; the original day is then hidden in the series.
        Map<String, List<LocalDate>> movedCopies = new HashMap<>();
        Map<String, CalendarEvent> byId = new LinkedHashMap<>();
        for (Component component : components) {
            String title = "(no title)";
            try {
                Property summary = component.first("SUMMARY");
                if (summary != null && !unescape(summary.value).isBlank()) {
                    title = unescape(summary.value).replace('\t', ' ');
                }
                Property status = component.first("STATUS");
                if (status != null && status.value.equalsIgnoreCase("CANCELLED")) {
                    result.cancelled++;
                    continue;
                }
                CalendarEvent event = toEvent(component, title, localZone, result.warnings, movedCopies);
                if (event != null) {
                    byId.put(event.getId(), event);
                }
            } catch (RuntimeException ex) {
                result.warnings.add("\u201C" + title + "\u201D was skipped: " + ex.getMessage());
            }
        }
        movedCopies.forEach((uid, days) -> {
            CalendarEvent series = byId.get(uid);
            if (series != null) {
                days.forEach(series::skipDate);
            }
        });
        result.events.addAll(byId.values());
        return result;
    }

    private static CalendarEvent toEvent(Component c, String title, ZoneId zone, List<String> warnings,
                                         Map<String, List<LocalDate>> movedCopies) {
        Property startProp = c.first("DTSTART");
        if (startProp == null) {
            throw new IllegalArgumentException("it has no start date");
        }
        Property uidProp = c.first("UID");
        String uid = uidProp == null || uidProp.value.isBlank()
            ? UUID.randomUUID().toString()
            : uidProp.value.replaceAll("[\\t\\r\\n]", " ").trim();
        String id = uid;
        Property recurrenceId = c.first("RECURRENCE-ID");
        if (recurrenceId != null) {
            LocalDate originalDay = dateOf(parseTime(recurrenceId, zone));
            movedCopies.computeIfAbsent(uid, k -> new ArrayList<>()).add(originalDay);
            id = uid + "#" + originalDay;
        }

        Temporal start = parseTime(startProp, zone);
        Property endProp = c.first("DTEND");
        Property durationProp = c.first("DURATION");
        CalendarEvent event;
        if (start instanceof LocalDate) {
            LocalDate first = (LocalDate) start;
            event = new CalendarEvent(id, title, first);
            LocalDate endExclusive = null;
            if (endProp != null) {
                endExclusive = dateOf(parseTime(endProp, zone));
            } else if (durationProp != null) {
                endExclusive = first.plusDays(Math.max(1, parseDurationMinutes(durationProp.value) / 1440));
            }
            if (endExclusive != null && endExclusive.isAfter(first.plusDays(1))) {
                event.setEndDate(endExclusive.minusDays(1));
            }
        } else {
            LocalDateTime from = (LocalDateTime) start;
            event = new CalendarEvent(id, title, from.toLocalDate());
            LocalDateTime to = null;
            if (endProp != null) {
                Temporal end = parseTime(endProp, zone);
                to = end instanceof LocalDate ? ((LocalDate) end).atStartOfDay() : (LocalDateTime) end;
            } else if (durationProp != null) {
                to = from.plusMinutes(parseDurationMinutes(durationProp.value));
            }
            LocalTime endTime = null;
            if (to != null && to.isAfter(from)) {
                if (to.toLocalTime().equals(LocalTime.MIDNIGHT)) {
                    to = to.minusMinutes(1); // ends at midnight: show it as ending at 11:59 PM that day
                }
                if (to.toLocalDate().isAfter(from.toLocalDate())) {
                    event.setEndDate(to.toLocalDate());
                }
                endTime = to.toLocalTime().withSecond(0).withNano(0);
                if (!event.isMultiDay() && !endTime.isAfter(from.toLocalTime())) {
                    endTime = null;
                }
            }
            event.setTimes(from.toLocalTime().withSecond(0).withNano(0), endTime);
        }

        Property location = c.first("LOCATION");
        if (location != null) {
            event.setLocation(unescape(location.value));
        }
        Property description = c.first("DESCRIPTION");
        if (description != null) {
            event.setNotes(unescape(description.value));
        }
        for (Property categories : c.all("CATEGORIES")) {
            for (String name : splitUnescaped(categories.value)) {
                for (Category category : Category.values()) {
                    if (category.label().equalsIgnoreCase(name.trim()) && event.getCategory() == Category.OTHER) {
                        event.setCategory(category);
                    }
                }
            }
        }

        Property rrule = c.first("RRULE");
        if (rrule != null && recurrenceId == null) {
            String problem = applyRule(event, rrule.value, zone);
            if (problem != null) {
                warnings.add("\u201C" + title + "\u201D repeats in a way OurDay can't show (" + problem
                    + "), so only its first date was imported.");
                event.setRecurrence(Recurrence.NONE);
                event.setRepeatDays(null);
                event.setRepeatUntil(null);
                event.setInterval(1);
            } else {
                for (Property exdate : c.all("EXDATE")) {
                    for (String value : exdate.value.split(",")) {
                        event.skipDate(dateOf(parseTime(new Property("EXDATE", exdate.params, value.trim()), zone)));
                    }
                }
            }
        }

        applyAlarm(event, c.alarm);
        return event;
    }

    /** Sets the repeat from an RRULE value; returns a description of what isn't supported, or null. */
    private static String applyRule(CalendarEvent event, String value, ZoneId zone) {
        Map<String, String> parts = new LinkedHashMap<>();
        for (String part : value.split(";")) {
            int eq = part.indexOf('=');
            if (eq > 0) {
                parts.put(part.substring(0, eq).trim().toUpperCase(Locale.ROOT), part.substring(eq + 1).trim());
            }
        }
        Recurrence frequency;
        try {
            frequency = Recurrence.valueOf(parts.getOrDefault("FREQ", ""));
        } catch (IllegalArgumentException ex) {
            return "repeats " + parts.getOrDefault("FREQ", "in an unknown way").toLowerCase(Locale.ROOT);
        }
        if (frequency == Recurrence.NONE) {
            return "unknown frequency";
        }
        event.setRecurrence(frequency);
        if (parts.containsKey("INTERVAL")) {
            event.setInterval(Integer.parseInt(parts.get("INTERVAL")));
        }
        for (String key : parts.keySet()) {
            switch (key) {
                case "FREQ":
                case "INTERVAL":
                case "UNTIL":
                case "COUNT":
                case "WKST":
                    break;
                case "BYDAY":
                    if (frequency != Recurrence.WEEKLY) {
                        return "on a weekday of the month, e.g. \"2nd Monday\"";
                    }
                    List<DayOfWeek> days = new ArrayList<>();
                    for (String code : parts.get("BYDAY").split(",")) {
                        int index = Arrays.asList(WEEKDAY_CODES).indexOf(code.trim().toUpperCase(Locale.ROOT));
                        if (index < 0) {
                            return "on " + code;
                        }
                        days.add(DayOfWeek.of(index + 1));
                    }
                    event.setRepeatDays(days);
                    break;
                case "BYMONTHDAY":
                    if (!parts.get(key).equals(Integer.toString(event.getDate().getDayOfMonth()))) {
                        return "on several days of the month";
                    }
                    break;
                case "BYMONTH":
                    if (!parts.get(key).equals(Integer.toString(event.getDate().getMonthValue()))) {
                        return "in several months";
                    }
                    break;
                default:
                    return key.toLowerCase(Locale.ROOT) + " rules";
            }
        }
        if (parts.containsKey("UNTIL")) {
            Temporal until = parseTime(new Property("UNTIL", Map.of(), parts.get("UNTIL")), zone);
            LocalDate last = dateOf(until);
            event.setRepeatUntil(last.isBefore(event.getDate()) ? event.getDate() : last);
        } else if (parts.containsKey("COUNT")) {
            int count = Integer.parseInt(parts.get("COUNT"));
            LocalDate day = event.getDate();
            LocalDate last = day;
            for (int found = 0; found < count && day.isBefore(event.getDate().plusYears(100)); day = day.plusDays(1)) {
                if (event.startsOn(day)) {
                    found++;
                    last = day;
                }
            }
            event.setRepeatUntil(last);
        }
        return null;
    }

    private static void applyAlarm(CalendarEvent event, List<Property> alarm) {
        for (Property p : alarm) {
            if (!p.name.equals("TRIGGER") || "DATE-TIME".equalsIgnoreCase(p.param("VALUE"))
                    || "END".equalsIgnoreCase(p.param("RELATED"))) {
                continue;
            }
            int offset = parseDurationMinutes(p.value); // negative = before the start
            int minutesBefore = event.isAllDay() ? ALL_DAY_REMINDER_MINUTE - offset : -offset;
            if (minutesBefore >= 0) {
                event.setReminderMinutes(minutesBefore);
            }
            return;
        }
    }

    /** Minutes in an iCal duration such as "-PT15M", "P1D" or "P1DT2H30M" (negative for "-"). */
    static int parseDurationMinutes(String value) {
        String v = value.trim().toUpperCase(Locale.ROOT);
        int sign = 1;
        if (v.startsWith("-")) {
            sign = -1;
            v = v.substring(1);
        } else if (v.startsWith("+")) {
            v = v.substring(1);
        }
        if (!v.startsWith("P")) {
            throw new IllegalArgumentException("bad duration " + value);
        }
        long minutes = 0;
        long number = 0;
        boolean inTime = false;
        for (char ch : v.substring(1).toCharArray()) {
            if (Character.isDigit(ch)) {
                number = number * 10 + (ch - '0');
                continue;
            }
            switch (ch) {
                case 'T': inTime = true; break;
                case 'W': minutes += number * 7 * 1440; break;
                case 'D': minutes += number * 1440; break;
                case 'H': minutes += number * 60; break;
                case 'M': minutes += inTime ? number : number * 30 * 1440; break;
                case 'S': minutes += number / 60; break;
                default: throw new IllegalArgumentException("bad duration " + value);
            }
            number = 0;
        }
        return (int) (sign * minutes);
    }

    /** A LocalDate (all-day values) or a LocalDateTime in the local time zone. */
    private static Temporal parseTime(Property p, ZoneId localZone) {
        String v = p.value.trim();
        try {
            if ("DATE".equalsIgnoreCase(p.param("VALUE")) || v.length() == 8) {
                return LocalDate.parse(v.substring(0, 8), DATE);
            }
            if (v.endsWith("Z") || v.endsWith("z")) {
                LocalDateTime utc = LocalDateTime.parse(v.substring(0, 15), DATE_TIME);
                return utc.atZone(ZoneOffset.UTC).withZoneSameInstant(localZone).toLocalDateTime();
            }
            LocalDateTime time = LocalDateTime.parse(v.substring(0, 15), DATE_TIME);
            String tzid = p.param("TZID");
            if (tzid != null) {
                ZoneId zone = zoneFor(tzid);
                if (zone != null) {
                    return time.atZone(zone).withZoneSameInstant(localZone).toLocalDateTime();
                }
            }
            return time; // "floating" time: same clock time everywhere
        } catch (DateTimeParseException | StringIndexOutOfBoundsException ex) {
            throw new IllegalArgumentException("its date \"" + v + "\" couldn't be read");
        }
    }

    private static ZoneId zoneFor(String tzid) {
        String name = tzid.replace("\"", "").trim();
        int slash = name.indexOf("/mozilla.org/");
        if (slash >= 0) {
            name = name.substring(name.lastIndexOf("/mozilla.org/") + 13);
            name = name.substring(name.indexOf('/') + 1); // drop the version folder
        }
        try {
            return ZoneId.of(name);
        } catch (DateTimeException ex) {
            return null; // e.g. Windows names like "Eastern Standard Time": treat as local time
        }
    }

    private static LocalDate dateOf(Temporal t) {
        return t instanceof LocalDate ? (LocalDate) t : ((LocalDateTime) t).toLocalDate();
    }

    private static Property parseProperty(String line) {
        boolean quoted = false;
        int colon = -1;
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '"') {
                quoted = !quoted;
            } else if (ch == ':' && !quoted) {
                colon = i;
                break;
            }
        }
        if (colon < 0) {
            return null;
        }
        String head = line.substring(0, colon);
        String value = line.substring(colon + 1);
        List<String> pieces = new ArrayList<>();
        StringBuilder piece = new StringBuilder();
        quoted = false;
        for (char ch : head.toCharArray()) {
            if (ch == '"') {
                quoted = !quoted;
            }
            if (ch == ';' && !quoted) {
                pieces.add(piece.toString());
                piece.setLength(0);
            } else {
                piece.append(ch);
            }
        }
        pieces.add(piece.toString());
        Map<String, String> params = new HashMap<>();
        for (String param : pieces.subList(1, pieces.size())) {
            int eq = param.indexOf('=');
            if (eq > 0) {
                params.put(param.substring(0, eq).toUpperCase(Locale.ROOT), param.substring(eq + 1).replace("\"", ""));
            }
        }
        return new Property(pieces.get(0).trim().toUpperCase(Locale.ROOT), params, value);
    }

    static String unescape(String text) {
        StringBuilder out = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            if (ch == '\\' && i + 1 < text.length()) {
                char next = text.charAt(++i);
                out.append(next == 'n' || next == 'N' ? '\n' : next);
            } else {
                out.append(ch);
            }
        }
        return out.toString();
    }

    /** Splits a comma-separated list, ignoring escaped commas. */
    private static List<String> splitUnescaped(String text) {
        List<String> items = new ArrayList<>();
        StringBuilder item = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            if (ch == '\\' && i + 1 < text.length()) {
                item.append(text.charAt(++i));
            } else if (ch == ',') {
                items.add(item.toString());
                item.setLength(0);
            } else {
                item.append(ch);
            }
        }
        items.add(item.toString());
        return items;
    }

    // =====================================================================
    // Downloading
    // =====================================================================

    /**
     * Downloads a calendar from a web address, e.g. the "secret address in iCal
     * format" in Google Calendar's settings. webcal:// addresses are fetched over https.
     */
    public static String download(String address) throws IOException {
        String url = address.trim();
        if (url.regionMatches(true, 0, "webcal://", 0, 9)) {
            url = "https://" + url.substring(9);
        }
        if (!url.regionMatches(true, 0, "https://", 0, 8) && !url.regionMatches(true, 0, "http://", 0, 7)) {
            throw new IOException("Enter a web address starting with https:// or webcal://");
        }
        HttpClient client = HttpClient.newBuilder()
            .followRedirects(HttpClient.Redirect.NORMAL)
            .connectTimeout(Duration.ofSeconds(15))
            .build();
        HttpRequest request = HttpRequest.newBuilder(URI.create(url))
            .timeout(Duration.ofSeconds(30))
            .header("Accept", "text/calendar, */*")
            .GET()
            .build();
        HttpResponse<String> response;
        try {
            response = client.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new IOException("The download was interrupted.", ex);
        } catch (IllegalArgumentException ex) {
            throw new IOException("That isn't a valid web address.", ex);
        }
        if (response.statusCode() != 200) {
            throw new IOException("The server answered with error " + response.statusCode()
                + (response.statusCode() == 404 ? " (not found). Check the address." : "."));
        }
        if (!response.body().contains("BEGIN:VCALENDAR")) {
            throw new IOException("That address didn't return a calendar (.ics) file.");
        }
        return response.body();
    }
}

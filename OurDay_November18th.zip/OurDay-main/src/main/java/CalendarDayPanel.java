import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.List;
import java.util.Locale;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

/**
 * One day cell in the month view. Clicking anywhere in it opens that day's events;
 * an event can be dragged onto another day to move it there.
 */
public class CalendarDayPanel extends JPanel {
    private static final int CHIP_GAP = 4;
    private final Color borderColor;
    private final LocalDate date;
    private final boolean selected;

    /**
     * @param selected  draws a dashed outline: the day the arrow keys have moved to
     * @param onDropped called when an event chip is dragged and released; gets the point on screen
     */
    public CalendarDayPanel(LocalDate date, List<Occurrence> events, boolean today, boolean selected,
                            Consumer<LocalDate> onClick, BiConsumer<Occurrence, Point> onDropped) {
        super(new BorderLayout(0, 7));
        this.date = date;
        this.selected = selected;
        borderColor = today ? ThemeManager.ACCENT : ThemeManager.BORDER;
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(10, 10, 8, 10));
        setToolTipText(date + " \u2014 click to manage events");

        JLabel dayLabel = new JLabel(
            date.getDayOfWeek().getDisplayName(TextStyle.SHORT, Locale.US) + "  " + date.getDayOfMonth());
        dayLabel.setFont(today ? ThemeManager.SUBTITLE_FONT : ThemeManager.BODY_FONT);
        dayLabel.setForeground(today ? ThemeManager.ACCENT : ThemeManager.TEXT);
        add(dayLabel, BorderLayout.NORTH);

        JLabel more = new JLabel();
        more.setFont(new Font("SansSerif", Font.PLAIN, 11));
        more.setForeground(ThemeManager.MUTED_TEXT);
        JPanel eventList = new JPanel(new ChipListLayout(more));
        eventList.setOpaque(false);
        for (Occurrence occurrence : events) {
            EventChip chip = new EventChip(occurrence, EventChip.Size.COMPACT, null);
            if (onDropped != null) {
                makeDraggable(chip, onDropped);
            }
            eventList.add(chip);
        }
        eventList.add(more);
        add(eventList, BorderLayout.CENTER);

        MouseAdapter clickHandler = new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent event) {
                onClick.accept(date);
            }
        };
        installClickHandler(this, clickHandler);
    }

    private void installClickHandler(Component component, MouseAdapter handler) {
        component.addMouseListener(handler);
        if (component instanceof Container) {
            for (Component child : ((Container) component).getComponents()) {
                installClickHandler(child, handler);
            }
        }
    }

    public LocalDate getDate() {
        return date;
    }

    private void makeDraggable(EventChip chip, BiConsumer<Occurrence, Point> onDropped) {
        MouseAdapter drag = new MouseAdapter() {
            private Point pressed;
            private boolean dragging;

            @Override
            public void mousePressed(MouseEvent e) {
                pressed = e.getLocationOnScreen();
                dragging = false;
            }

            @Override
            public void mouseDragged(MouseEvent e) {
                if (pressed != null && !dragging && pressed.distance(e.getLocationOnScreen()) > 5) {
                    dragging = true;
                    chip.setCursor(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                chip.setCursor(Cursor.getDefaultCursor());
                if (dragging) {
                    onDropped.accept(chip.occurrence(), e.getLocationOnScreen());
                }
                pressed = null;
                dragging = false;
            }
        };
        chip.addMouseListener(drag);
        chip.addMouseMotionListener(drag);
        chip.setToolTipText(chip.getToolTipText().replace("</html>", "<br><font color='#888888'>Drag to another day to move it</font></html>"));
    }

    @Override
    protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D g2 = (Graphics2D) graphics.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(ThemeManager.CELL);
        g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 18, 18);
        g2.setColor(borderColor);
        g2.setStroke(new BasicStroke(borderColor.equals(ThemeManager.ACCENT) ? 2f : 1f));
        g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 18, 18);
        if (selected) {
            g2.setColor(ThemeManager.ACCENT);
            g2.setStroke(new BasicStroke(1.5f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_ROUND, 1f, new float[]{4f, 3f}, 0f));
            g2.drawRoundRect(3, 3, getWidth() - 7, getHeight() - 7, 14, 14);
        }
        g2.dispose();
    }

    /**
     * Stacks the event chips and shows as many as fit in the cell (which depends on
     * the window size). If some don't fit, the last line becomes "+N more" so it's
     * always clear that the day has more events. The "more" label is the last child.
     */
    private static final class ChipListLayout implements LayoutManager {
        private final JLabel more;

        ChipListLayout(JLabel more) {
            this.more = more;
        }

        @Override
        public void layoutContainer(Container parent) {
            Insets in = parent.getInsets();
            int x = in.left;
            int width = parent.getWidth() - in.left - in.right;
            int bottom = parent.getHeight() - in.bottom;
            int chipCount = parent.getComponentCount() - 1;
            // Measured from the font: the label's text (and so its preferred size) is only set below.
            int moreHeight = more.getFontMetrics(more.getFont()).getHeight();

            int y = in.top;
            int shown = 0;
            for (int i = 0; i < chipCount; i++) {
                Component chip = parent.getComponent(i);
                int h = chip.getPreferredSize().height;
                boolean last = i == chipCount - 1;
                // Leave room for the "+N more" line unless this is the final chip.
                int needed = h + (last ? 0 : CHIP_GAP + moreHeight);
                if (y + needed > bottom) {
                    break;
                }
                chip.setBounds(x, y, width, h);
                chip.setVisible(true);
                y += h + CHIP_GAP;
                shown++;
            }
            for (int i = shown; i < chipCount; i++) {
                parent.getComponent(i).setVisible(false);
            }
            int hidden = chipCount - shown;
            more.setText(hidden + (shown == 0 ? (hidden == 1 ? " event" : " events") : " more"));
            if (shown > 0) {
                more.setText("+" + more.getText());
            }
            more.setVisible(hidden > 0);
            more.setBounds(x, y, width, moreHeight);
        }

        @Override
        public Dimension preferredLayoutSize(Container parent) {
            // Grid cells are sized by the month grid, so ask for very little.
            return new Dimension(0, 0);
        }

        @Override
        public Dimension minimumLayoutSize(Container parent) {
            return new Dimension(0, 0);
        }

        @Override
        public void addLayoutComponent(String name, Component comp) {
        }

        @Override
        public void removeLayoutComponent(Component comp) {
        }
    }
}

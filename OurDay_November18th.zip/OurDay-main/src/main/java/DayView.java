import java.time.LocalDate;
import java.util.List;

/** One day as an hour-by-hour grid (see {@link TimeGridView}). */
public class DayView extends TimeGridView {
    public DayView(LocalDate date, EventManager manager, Actions actions) {
        super(List.of(date), manager, date, actions);
    }
}

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Comparator;

/**
 * A single appearance of an event on a specific day. A one-time event has one
 * occurrence; a weekly event has one per matching week; a three-day trip has one
 * for each of its days (all sharing the same {@link #start()}).
 */
public final class Occurrence {
    /** All-day and multi-day events first, then by start time, then by title. */
    public static final Comparator<Occurrence> CHRONOLOGICAL = Comparator
        .comparing(Occurrence::date)
        .thenComparing(o -> !o.isAllDayOnThisDay())
        .thenComparing(o -> o.isAllDayOnThisDay() ? LocalTime.MIDNIGHT : o.event().getStartTime())
        .thenComparing(o -> o.event().getTitle(), String.CASE_INSENSITIVE_ORDER);

    private final CalendarEvent event;
    private final LocalDate date;
    private final LocalDate start;

    /** @param date the day being shown; must be a day the event is happening */
    public Occurrence(CalendarEvent event, LocalDate date) {
        this.event = event;
        this.date = date;
        LocalDate instanceStart = event.instanceStartFor(date);
        this.start = instanceStart != null ? instanceStart : date;
    }

    public CalendarEvent event() {
        return event;
    }

    /** The day this occurrence is shown on. */
    public LocalDate date() {
        return date;
    }

    /** The day this copy of the event began (earlier than {@link #date()} on later days of a multi-day event). */
    public LocalDate start() {
        return start;
    }

    /** The day this copy of the event ends. */
    public LocalDate end() {
        return start.plusDays(event.spanDays());
    }

    public boolean isFirstDay() {
        return date.equals(start);
    }

    public boolean isLastDay() {
        return date.equals(end());
    }

    /** True for all-day events and every day of multi-day events (shown in the "All day" area). */
    public boolean isAllDayOnThisDay() {
        return event.isAllDay() || event.isMultiDay();
    }

    /** The moment reminders count back from: the start time, or 9:00 AM for all-day events. */
    public LocalDateTime referenceTime() {
        LocalTime time = event.isAllDay() ? CalendarEvent.ALL_DAY_REMINDER_TIME : event.getStartTime();
        return start.atTime(time);
    }

    /** Uniquely identifies this copy of the event, e.g. for tracking which reminders were shown. */
    public String key() {
        return event.getId() + "@" + start;
    }

    @Override
    public boolean equals(Object other) {
        return other instanceof Occurrence
            && ((Occurrence) other).event.equals(event)
            && ((Occurrence) other).date.equals(date);
    }

    @Override
    public int hashCode() {
        return event.getId().hashCode() * 31 + date.hashCode();
    }

    @Override
    public String toString() {
        return event.getTitle() + " on " + date;
    }
}

import javax.swing.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Consumer;

/** Holds all events in memory and keeps them saved to disk. */
public class EventManager {
    private static final String FILE_NAME = "ourday-events.dat";

    private final File eventFile;
    private final Consumer<String> errorReporter;
    private final Map<String, CalendarEvent> events = new LinkedHashMap<>();
    /** How many changes can be undone. */
    static final int UNDO_LIMIT = 100;
    private final Deque<Snapshot> undoStack = new ArrayDeque<>();
    private final Deque<Snapshot> redoStack = new ArrayDeque<>();

    /** Uses pop-up dialogs to report load/save problems. */
    public EventManager(File eventFile) {
        this(eventFile, EventManager::showErrorDialog);
    }

    /** @param errorReporter receives a user-readable message whenever loading or saving fails. */
    public EventManager(File eventFile, Consumer<String> errorReporter) {
        this.eventFile = eventFile;
        this.errorReporter = errorReporter;
    }

    /**
     * The standard place to keep events: ~/.ourday/ourday-events.dat. Using the
     * home folder means events are found no matter which folder the app is
     * launched from. If an older copy exists in the launch folder (where earlier
     * versions saved it) and there is no file in the new location yet, it is
     * copied over so nobody loses their events.
     */
    public static File defaultEventFile() {
        File dir = AppSettings.dataDirectory();
        File file = new File(dir, FILE_NAME);
        File legacy = new File(FILE_NAME);
        try {
            Files.createDirectories(dir.toPath());
            if (!file.exists() && legacy.isFile()) {
                Files.copy(legacy.toPath(), file.toPath());
            }
        } catch (IOException ex) {
            System.err.println("OurDay: could not prepare " + dir + ": " + ex.getMessage());
        }
        return file;
    }

    public File getEventFile() {
        return eventFile;
    }

    // --- queries ---

    public List<CalendarEvent> getEvents() {
        return Collections.unmodifiableList(new ArrayList<>(events.values()));
    }

    public CalendarEvent getEvent(String id) {
        return events.get(id);
    }

    /** Everything happening on one day, in display order. */
    public List<Occurrence> getOccurrences(LocalDate date) {
        return getOccurrences(date, date);
    }

    /** Everything happening from {@code first} to {@code last} (inclusive), in display order. */
    public List<Occurrence> getOccurrences(LocalDate first, LocalDate last) {
        List<Occurrence> result = new ArrayList<>();
        for (LocalDate day = first; !day.isAfter(last); day = day.plusDays(1)) {
            for (CalendarEvent event : events.values()) {
                if (event.occursOn(day)) {
                    result.add(new Occurrence(event, day));
                }
            }
        }
        result.sort(Occurrence.CHRONOLOGICAL);
        return result;
    }

    public boolean hasEventsOn(LocalDate date) {
        for (CalendarEvent event : events.values()) {
            if (event.occursOn(date)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Events whose title, location or notes contain {@code query} (ignoring case),
     * soonest first: upcoming events by their next date, then past ones, most recent first.
     */
    public List<CalendarEvent> search(String query, LocalDate today) {
        String needle = query.trim().toLowerCase(Locale.ROOT);
        List<CalendarEvent> matches = new ArrayList<>();
        if (needle.isEmpty()) {
            return matches;
        }
        for (CalendarEvent event : events.values()) {
            if ((event.getTitle() + "\n" + event.getLocation() + "\n" + event.getNotes())
                    .toLowerCase(Locale.ROOT).contains(needle)) {
                matches.add(event);
            }
        }
        Map<CalendarEvent, LocalDate> next = new HashMap<>();
        for (CalendarEvent event : matches) {
            next.put(event, event.nextStartOnOrAfter(today));
        }
        matches.sort((a, b) -> {
            LocalDate na = next.get(a);
            LocalDate nb = next.get(b);
            if (na != null && nb != null) {
                return na.compareTo(nb);
            }
            if (na != null || nb != null) {
                return na != null ? -1 : 1; // upcoming before past
            }
            return b.getDate().compareTo(a.getDate());
        });
        return matches;
    }

    // --- changes (each one is saved immediately, and can be undone) ---

    public void add(CalendarEvent event) {
        if (events.containsKey(event.getId())) {
            throw new IllegalArgumentException("An event with this id already exists.");
        }
        remember("Add \u201C" + event.getTitle() + "\u201D");
        events.put(event.getId(), event);
        save();
    }

    /** Replaces the stored event that has the same id (e.g. an edited copy). */
    public void update(CalendarEvent event) {
        update(event, "Edit \u201C" + event.getTitle() + "\u201D");
    }

    /** Like {@link #update(CalendarEvent)}, with the wording shown in the Undo menu (e.g. "Move \u201CLunch\u201D"). */
    public void update(CalendarEvent event, String description) {
        requireEvent(event.getId());
        remember(description);
        events.put(event.getId(), event);
        save();
    }

    /** Deletes an event, including every repeat of it. */
    public void remove(String id) {
        CalendarEvent event = requireEvent(id);
        remember("Delete \u201C" + event.getTitle() + "\u201D");
        events.remove(id);
        save();
    }

    /**
     * Removes one copy of a repeating event (the one happening on {@code date}),
     * leaving the other repeats alone.
     */
    public void removeOccurrence(String id, LocalDate date) {
        CalendarEvent event = requireEvent(id);
        if (!event.isRepeating()) {
            remove(id);
            return;
        }
        LocalDate start = event.instanceStartFor(date);
        if (start == null) {
            return; // not happening that day anyway
        }
        remember("Delete \u201C" + event.getTitle() + "\u201D on " + Formats.shortDay(start));
        event.skipDate(start);
        if (!event.hasOccurrenceOnOrAfter(event.getDate())) {
            // Every day of the series has now been removed; keeping it would leave an
            // event that can't be seen (or deleted) anywhere in the calendar.
            events.remove(id);
        }
        save();
    }

    /** What an import changed. */
    public static final class ImportCounts {
        public final int added;
        public final int updated;

        ImportCounts(int added, int updated) {
            this.added = added;
            this.updated = updated;
        }
    }

    /**
     * Adds imported events in one undoable step. An event whose id is already in the
     * calendar (the same event imported before) is replaced by the new version, so
     * importing an updated copy of a calendar refreshes it instead of duplicating it.
     */
    public ImportCounts importEvents(Collection<CalendarEvent> imported, String description) {
        if (imported.isEmpty()) {
            return new ImportCounts(0, 0);
        }
        remember(description);
        int added = 0;
        int updated = 0;
        for (CalendarEvent event : imported) {
            if (events.put(event.getId(), event) == null) {
                added++;
            } else {
                updated++;
            }
        }
        save();
        return new ImportCounts(added, updated);
    }

    // --- undo / redo ---

    private static final class Snapshot {
        final String description;
        final List<CalendarEvent> events;

        Snapshot(String description, List<CalendarEvent> events) {
            this.description = description;
            this.events = events;
        }
    }

    private List<CalendarEvent> copyOfEvents() {
        List<CalendarEvent> copy = new ArrayList<>(events.size());
        for (CalendarEvent event : events.values()) {
            copy.add(event.copy());
        }
        return copy;
    }

    /** Called before every change: keeps the current state so the change can be undone. */
    private void remember(String description) {
        undoStack.push(new Snapshot(description, copyOfEvents()));
        while (undoStack.size() > UNDO_LIMIT) {
            undoStack.removeLast();
        }
        redoStack.clear();
    }

    private void restore(List<CalendarEvent> state) {
        events.clear();
        for (CalendarEvent event : state) {
            events.put(event.getId(), event);
        }
        save();
    }

    public boolean canUndo() {
        return !undoStack.isEmpty();
    }

    public boolean canRedo() {
        return !redoStack.isEmpty();
    }

    /** e.g. "Delete \u201CLunch\u201D", or null if there is nothing to undo. */
    public String undoDescription() {
        return undoStack.isEmpty() ? null : undoStack.peek().description;
    }

    public String redoDescription() {
        return redoStack.isEmpty() ? null : redoStack.peek().description;
    }

    /** Reverses the most recent change. Returns false if there was nothing to undo. */
    public boolean undo() {
        if (undoStack.isEmpty()) {
            return false;
        }
        Snapshot previous = undoStack.pop();
        redoStack.push(new Snapshot(previous.description, copyOfEvents()));
        restore(previous.events);
        return true;
    }

    /** Re-applies the most recently undone change. Returns false if there was nothing to redo. */
    public boolean redo() {
        if (redoStack.isEmpty()) {
            return false;
        }
        Snapshot next = redoStack.pop();
        undoStack.push(new Snapshot(next.description, copyOfEvents()));
        restore(next.events);
        return true;
    }

    private CalendarEvent requireEvent(String id) {
        CalendarEvent event = events.get(id);
        if (event == null) {
            throw new IllegalArgumentException("No event with id " + id);
        }
        return event;
    }

    // --- loading and saving ---

    public void load() {
        events.clear();
        undoStack.clear();
        redoStack.clear();
        if (!eventFile.exists()) {
            return;
        }
        Path path = eventFile.toPath();
        try {
            boolean legacy = EventFileFormat.isLegacyFile(path);
            List<String> problems = new ArrayList<>();
            List<CalendarEvent> loaded = EventFileFormat.read(path, problems);
            if (!problems.isEmpty() && loaded.isEmpty()) {
                // Nothing usable at all: treat the whole file as unreadable (handled below).
                throw new IOException(problems.get(0));
            }
            for (CalendarEvent event : loaded) {
                events.put(event.getId(), event);
            }
            if (!problems.isEmpty()) {
                // Keep the good events, but save a copy of the original so the skipped lines aren't lost.
                File backup = siblingFile("." + timestamp() + ".bak");
                Files.copy(path, backup.toPath(), StandardCopyOption.REPLACE_EXISTING);
                save();
                errorReporter.accept("OurDay loaded " + loaded.size() + " event" + (loaded.size() == 1 ? "" : "s")
                    + ", but skipped " + problems.size() + " line" + (problems.size() == 1 ? "" : "s")
                    + " it couldn't read:\n" + String.join("\n", problems.subList(0, Math.min(5, problems.size())))
                    + (problems.size() > 5 ? "\n..." : "")
                    + "\n\nThe original file was kept as:\n" + backup.getAbsolutePath());
            }
            if (legacy) {
                // Keep the old file around, then rewrite it in the new format.
                Files.copy(path, siblingFile(".v1.bak").toPath(), StandardCopyOption.REPLACE_EXISTING);
                save();
            }
        } catch (IOException | RuntimeException ex) {
            events.clear(); // never keep half-loaded data
            // Move the unreadable file aside so the next save can't destroy it.
            String backupNote;
            try {
                File backup = siblingFile("." + timestamp() + ".bak");
                Files.move(path, backup.toPath(), StandardCopyOption.REPLACE_EXISTING);
                backupNote = "\n\nThe unreadable file was kept as:\n" + backup.getAbsolutePath();
            } catch (IOException backupError) {
                backupNote = "\n\nThe file could not be backed up (" + backupError.getMessage()
                    + "). Copy it somewhere safe before adding events:\n" + eventFile.getAbsolutePath();
            }
            errorReporter.accept("Could not load saved OurDay events: " + ex.getMessage() + backupNote);
        }
    }

    private static String timestamp() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
    }

    private File siblingFile(String suffix) {
        return new File(eventFile.getAbsoluteFile().getParentFile(), eventFile.getName() + suffix);
    }

    /**
     * Writes to a temporary file first, then swaps it into place, so a crash
     * mid-save leaves the previous file intact instead of a half-written one.
     */
    private void save() {
        Path target = eventFile.getAbsoluteFile().toPath();
        Path temp = null;
        try {
            Files.createDirectories(target.getParent());
            temp = Files.createTempFile(target.getParent(), FILE_NAME, ".tmp");
            try (Writer writer = Files.newBufferedWriter(temp, StandardCharsets.UTF_8)) {
                EventFileFormat.write(events.values(), writer);
            }
            try {
                Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            if (temp != null) {
                try {
                    Files.deleteIfExists(temp);
                } catch (IOException ignored) {
                    // best-effort cleanup
                }
            }
            errorReporter.accept("Could not save events: " + ex.getMessage());
        }
    }

    private static void showErrorDialog(String message) {
        JOptionPane.showMessageDialog(null, message, "OurDay", JOptionPane.ERROR_MESSAGE);
    }
}

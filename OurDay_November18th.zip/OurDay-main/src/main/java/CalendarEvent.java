import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.temporal.ChronoUnit;
import java.util.*;

/**
 * One calendar entry. An event can be all-day or have a start (and optional end)
 * time, can last several days, belongs to a {@link Category}, can repeat (every
 * N days, weeks, months or years), can have a location, notes and a reminder.
 *
 * Named CalendarEvent (not Event) to avoid clashing with java.awt.Event.
 */
public final class CalendarEvent {
    /** Value of {@link #getReminderMinutes()} when no reminder is set. */
    public static final int NO_REMINDER = -1;
    /** All-day events have no start time, so their reminders are measured from this time of day. */
    public static final LocalTime ALL_DAY_REMINDER_TIME = LocalTime.of(9, 0);
    /** Largest "repeat every N" allowed. */
    public static final int MAX_INTERVAL = 99;

    private final String id;
    private String title;
    private LocalDate date;
    private LocalDate endDate; // null: ends on the day it starts
    private LocalTime startTime;
    private LocalTime endTime;
    private Category category = Category.OTHER;
    private Recurrence recurrence = Recurrence.NONE;
    private int interval = 1;
    private final EnumSet<DayOfWeek> repeatDays = EnumSet.noneOf(DayOfWeek.class);
    private LocalDate repeatUntil;
    private int reminderMinutes = NO_REMINDER;
    private final TreeSet<LocalDate> skippedDates = new TreeSet<>();
    private String location = "";
    private String notes = "";

    public CalendarEvent(String title, LocalDate date) {
        this(UUID.randomUUID().toString(), title, date);
    }

    public CalendarEvent(String id, String title, LocalDate date) {
        this.id = Objects.requireNonNull(id, "id");
        setTitle(title);
        setDate(date);
    }

    /** A deep copy with the same id, so edits can be made and then saved or discarded. */
    public CalendarEvent copy() {
        CalendarEvent copy = new CalendarEvent(id, title, date);
        copy.endDate = endDate;
        copy.startTime = startTime;
        copy.endTime = endTime;
        copy.category = category;
        copy.recurrence = recurrence;
        copy.interval = interval;
        copy.repeatDays.addAll(repeatDays);
        copy.repeatUntil = repeatUntil;
        copy.reminderMinutes = reminderMinutes;
        copy.skippedDates.addAll(skippedDates);
        copy.location = location;
        copy.notes = notes;
        return copy;
    }

    // --- when the event happens ---

    /** True if this event is happening on the given day (including later days of a multi-day event). */
    public boolean occursOn(LocalDate day) {
        return instanceStartFor(day) != null;
    }

    /**
     * The day on which the copy of this event that covers {@code day} began, or null
     * if the event isn't happening that day. For a one-day event that is {@code day}
     * itself; for day 3 of a weekend trip it is the Friday the trip started.
     */
    public LocalDate instanceStartFor(LocalDate day) {
        int span = spanDays();
        for (int back = 0; back <= span; back++) {
            LocalDate start = day.minusDays(back);
            if (startsOn(start)) {
                return start;
            }
        }
        return null;
    }

    /** True if a copy of this event begins on the given day, taking repeats and skipped days into account. */
    public boolean startsOn(LocalDate day) {
        if (day.isBefore(date) || skippedDates.contains(day)) {
            return false;
        }
        if (recurrence != Recurrence.NONE && repeatUntil != null && day.isAfter(repeatUntil)) {
            return false;
        }
        switch (recurrence) {
            case NONE:
                return day.equals(date);
            case DAILY:
                return ChronoUnit.DAYS.between(date, day) % interval == 0;
            case WEEKLY:
                return effectiveRepeatDays().contains(day.getDayOfWeek())
                    && ChronoUnit.WEEKS.between(Formats.startOfWeek(date), Formats.startOfWeek(day)) % interval == 0;
            case MONTHLY:
                // An event on the 31st only appears in months that have a 31st.
                return day.getDayOfMonth() == date.getDayOfMonth()
                    && ChronoUnit.MONTHS.between(YearMonth.from(date), YearMonth.from(day)) % interval == 0;
            case YEARLY:
                // An event on Feb 29 only appears in leap years.
                return day.getMonth() == date.getMonth() && day.getDayOfMonth() == date.getDayOfMonth()
                    && (day.getYear() - date.getYear()) % interval == 0;
            default:
                throw new IllegalStateException("Unknown recurrence " + recurrence);
        }
    }

    /**
     * True if the event still begins on {@code from} or any later day. A repeating
     * event with no end date always does; one with an end date might not, once its
     * remaining days have all been skipped.
     */
    public boolean hasOccurrenceOnOrAfter(LocalDate from) {
        LocalDate first = from.isBefore(date) ? date : from;
        if (!isRepeating()) {
            return !first.isAfter(date) && startsOn(date);
        }
        if (repeatUntil == null) {
            // Skips are finite, so an endless series always has a future day.
            return true;
        }
        for (LocalDate day = first; !day.isAfter(repeatUntil); day = day.plusDays(1)) {
            if (startsOn(day)) {
                return true;
            }
        }
        return false;
    }

    /** The first day on or after {@code from} that a copy of this event begins, or null if there is none (looks up to 5 years ahead). */
    public LocalDate nextStartOnOrAfter(LocalDate from) {
        LocalDate first = from.isBefore(date) ? date : from;
        LocalDate last = isRepeating()
            ? (repeatUntil != null ? repeatUntil : first.plusYears(5))
            : date;
        for (LocalDate day = first; !day.isAfter(last); day = day.plusDays(1)) {
            if (startsOn(day)) {
                return day;
            }
        }
        return null;
    }

    /** The weekdays a weekly event repeats on; defaults to the weekday of its first date. */
    public Set<DayOfWeek> effectiveRepeatDays() {
        return repeatDays.isEmpty() ? EnumSet.of(date.getDayOfWeek()) : EnumSet.copyOf(repeatDays);
    }

    /** How many days after its start a copy of the event ends: 0 for a one-day event. */
    public int spanDays() {
        return endDate == null ? 0 : (int) ChronoUnit.DAYS.between(date, endDate);
    }

    public boolean isMultiDay() {
        return endDate != null;
    }

    public boolean isAllDay() {
        return startTime == null;
    }

    public boolean isRepeating() {
        return recurrence != Recurrence.NONE;
    }

    public boolean hasReminder() {
        return reminderMinutes >= 0;
    }

    // --- getters / setters ---

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        if (title == null || title.trim().isEmpty()) {
            throw new IllegalArgumentException("Event titles cannot be empty.");
        }
        this.title = title.trim();
    }

    /** The day the event (or the first copy of a repeating event) starts. */
    public LocalDate getDate() {
        return date;
    }

    /**
     * Moves the start day. A multi-day event keeps its length, so its end day moves too.
     */
    public void setDate(LocalDate date) {
        Objects.requireNonNull(date, "date");
        if (this.date != null && endDate != null) {
            endDate = endDate.plusDays(ChronoUnit.DAYS.between(this.date, date));
        }
        this.date = date;
    }

    /** The day the first copy ends: the start day itself for a one-day event. */
    public LocalDate getEndDate() {
        return endDate == null ? date : endDate;
    }

    /** Sets the day the event ends; pass null (or the start day) for a one-day event. */
    public void setEndDate(LocalDate endDate) {
        if (endDate != null && endDate.isBefore(date)) {
            throw new IllegalArgumentException("An event cannot end before it starts.");
        }
        this.endDate = endDate == null || endDate.equals(date) ? null : endDate;
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public LocalTime getEndTime() {
        return endTime;
    }

    /**
     * Sets the time range. Pass a null start for an all-day event. The end time is
     * optional, but for a one-day event it must be after the start. (Set the end
     * day first; a multi-day event may end at an earlier time of day than it started.)
     */
    public void setTimes(LocalTime start, LocalTime end) {
        if (start == null && end != null) {
            throw new IllegalArgumentException("An all-day event cannot have an end time.");
        }
        if (start != null && end != null && !isMultiDay() && !end.isAfter(start)) {
            throw new IllegalArgumentException("The end time must be after the start time.");
        }
        this.startTime = start;
        this.endTime = end;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category == null ? Category.OTHER : category;
    }

    public Recurrence getRecurrence() {
        return recurrence;
    }

    public void setRecurrence(Recurrence recurrence) {
        this.recurrence = recurrence == null ? Recurrence.NONE : recurrence;
    }

    /** Repeat every this many days/weeks/months/years (1 = every time). */
    public int getInterval() {
        return interval;
    }

    public void setInterval(int interval) {
        if (interval < 1 || interval > MAX_INTERVAL) {
            throw new IllegalArgumentException("Repeat every 1 to " + MAX_INTERVAL + ".");
        }
        this.interval = interval;
    }

    public Set<DayOfWeek> getRepeatDays() {
        return Collections.unmodifiableSet(repeatDays);
    }

    public void setRepeatDays(Collection<DayOfWeek> days) {
        repeatDays.clear();
        if (days != null) {
            repeatDays.addAll(days);
        }
    }

    public LocalDate getRepeatUntil() {
        return repeatUntil;
    }

    public void setRepeatUntil(LocalDate repeatUntil) {
        if (repeatUntil != null && repeatUntil.isBefore(date)) {
            throw new IllegalArgumentException("A repeating event cannot end before it starts.");
        }
        this.repeatUntil = repeatUntil;
    }

    public int getReminderMinutes() {
        return reminderMinutes;
    }

    public void setReminderMinutes(int minutes) {
        this.reminderMinutes = minutes < 0 ? NO_REMINDER : minutes;
    }

    public SortedSet<LocalDate> getSkippedDates() {
        return Collections.unmodifiableSortedSet(skippedDates);
    }

    /** Hides one copy of a repeating event (e.g. no school pickup on a holiday). Pass the day that copy starts. */
    public void skipDate(LocalDate day) {
        skippedDates.add(day);
    }

    public void setSkippedDates(Collection<LocalDate> days) {
        skippedDates.clear();
        if (days != null) {
            skippedDates.addAll(days);
        }
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location == null ? "" : location.trim();
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes == null ? "" : notes.strip();
    }

    @Override
    public boolean equals(Object other) {
        return other instanceof CalendarEvent && ((CalendarEvent) other).id.equals(id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }

    @Override
    public String toString() {
        return title;
    }
}

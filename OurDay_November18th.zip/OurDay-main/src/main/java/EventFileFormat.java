import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.*;

/**
 * Reads and writes the events file.
 *
 * Version 3 (current) is plain UTF-8 text: a header line, then one event per
 * line with tab-separated fields. It is readable in any text editor and does
 * not break when Java classes change.
 *
 * Version 2 lines are the same minus the last four columns (end day, repeat
 * interval, location, notes), so they are still read as they are.
 *
 * Version 1 (OurDay before reminders) was a Java-serialized
 * {@code Map<LocalDate, List<String>>}. It is still read so existing events
 * carry over; each old title becomes an all-day event in "Other".
 */
public final class EventFileFormat {
    static final String HEADER = "# OurDay events v3";
    private static final String[] COLUMNS = {
        "id", "title", "date", "start", "end", "category",
        "repeat", "repeatDays", "repeatUntil", "reminderMinutes", "skippedDates",
        "endDate", "interval", "location", "notes"
    };
    /** Number of columns in version 2 files. */
    private static final int V2_COLUMNS = 11;

    private EventFileFormat() {
    }

    /** True if the file was written by the old (version 1) Java-serialization format. */
    public static boolean isLegacyFile(Path file) throws IOException {
        try (InputStream in = Files.newInputStream(file)) {
            int first = in.read();
            int second = in.read();
            return first == 0xAC && second == 0xED; // Java serialization stream magic
        }
    }

    /** Reads every event, failing on the first line that can't be read. */
    public static List<CalendarEvent> read(Path file) throws IOException {
        List<String> problems = new ArrayList<>();
        List<CalendarEvent> events = read(file, problems);
        if (!problems.isEmpty()) {
            throw new IOException(problems.get(0));
        }
        return events;
    }

    /**
     * Reads every event that can be read. Each line that can't be (e.g. after a
     * hand edit went wrong) is skipped and described in {@code problems}, so one bad
     * line doesn't cost the user every other event.
     */
    public static List<CalendarEvent> read(Path file, List<String> problems) throws IOException {
        if (isLegacyFile(file)) {
            return readLegacy(file);
        }
        List<CalendarEvent> events = new ArrayList<>();
        Set<String> ids = new HashSet<>();
        try (BufferedReader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            String line;
            int lineNumber = 0;
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                if (line.isEmpty() || line.startsWith("#")) {
                    continue;
                }
                try {
                    CalendarEvent event = parseLine(line);
                    if (!ids.add(event.getId())) {
                        throw new IllegalArgumentException("another event already uses the id " + event.getId());
                    }
                    events.add(event);
                } catch (RuntimeException ex) {
                    problems.add("Line " + lineNumber + " of the events file is invalid: " + ex.getMessage());
                }
            }
        }
        return events;
    }

    public static void write(Collection<CalendarEvent> events, Writer writer) throws IOException {
        writer.write(HEADER);
        writer.write('\n');
        writer.write("# " + String.join("\t", COLUMNS));
        writer.write('\n');
        for (CalendarEvent event : events) {
            writer.write(formatLine(event));
            writer.write('\n');
        }
    }

    static String formatLine(CalendarEvent e) {
        StringJoiner days = new StringJoiner(",");
        for (DayOfWeek day : e.getRepeatDays()) {
            days.add(day.name());
        }
        StringJoiner skipped = new StringJoiner(",");
        for (LocalDate day : e.getSkippedDates()) {
            skipped.add(day.toString());
        }
        String[] fields = {
            e.getId(),
            escape(e.getTitle()),
            e.getDate().toString(),
            e.getStartTime() == null ? "" : e.getStartTime().toString(),
            e.getEndTime() == null ? "" : e.getEndTime().toString(),
            e.getCategory().name(),
            e.getRecurrence().name(),
            days.toString(),
            e.getRepeatUntil() == null ? "" : e.getRepeatUntil().toString(),
            Integer.toString(e.getReminderMinutes()),
            skipped.toString(),
            e.isMultiDay() ? e.getEndDate().toString() : "",
            Integer.toString(e.getInterval()),
            escape(e.getLocation()),
            escape(e.getNotes())
        };
        return String.join("\t", fields);
    }

    static CalendarEvent parseLine(String line) {
        String[] f = line.split("\t", -1);
        if (f.length != COLUMNS.length && f.length != V2_COLUMNS) {
            throw new IllegalArgumentException("expected " + COLUMNS.length + " fields but found " + f.length);
        }
        boolean v3 = f.length == COLUMNS.length;
        try {
            CalendarEvent e = new CalendarEvent(f[0], unescape(f[1]), LocalDate.parse(f[2]));
            if (v3) {
                // The end day must be known before the times (a multi-day event may end earlier in the day).
                e.setEndDate(f[11].isEmpty() ? null : LocalDate.parse(f[11]));
            }
            e.setTimes(f[3].isEmpty() ? null : LocalTime.parse(f[3]), f[4].isEmpty() ? null : LocalTime.parse(f[4]));
            e.setCategory(Category.valueOf(f[5]));
            e.setRecurrence(Recurrence.valueOf(f[6]));
            List<DayOfWeek> days = new ArrayList<>();
            for (String day : splitList(f[7])) {
                days.add(DayOfWeek.valueOf(day));
            }
            e.setRepeatDays(days);
            e.setRepeatUntil(f[8].isEmpty() ? null : LocalDate.parse(f[8]));
            e.setReminderMinutes(Integer.parseInt(f[9]));
            List<LocalDate> skipped = new ArrayList<>();
            for (String day : splitList(f[10])) {
                skipped.add(LocalDate.parse(day));
            }
            e.setSkippedDates(skipped);
            if (v3) {
                e.setInterval(Integer.parseInt(f[12]));
                e.setLocation(unescape(f[13]));
                e.setNotes(unescape(f[14]));
            }
            return e;
        } catch (DateTimeParseException ex) {
            throw new IllegalArgumentException("bad date or time \"" + ex.getParsedString() + "\"", ex);
        }
    }

    private static List<String> splitList(String value) {
        return value.isEmpty() ? Collections.emptyList() : Arrays.asList(value.split(","));
    }

    /** Text can contain tabs, newlines or backslashes; escape them so each event stays on one line. */
    static String escape(String text) {
        StringBuilder out = new StringBuilder(text.length());
        for (char c : text.toCharArray()) {
            switch (c) {
                case '\\': out.append("\\\\"); break;
                case '\t': out.append("\\t"); break;
                case '\n': out.append("\\n"); break;
                case '\r': out.append("\\r"); break;
                default: out.append(c);
            }
        }
        return out.toString();
    }

    static String unescape(String text) {
        StringBuilder out = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '\\' && i + 1 < text.length()) {
                char next = text.charAt(++i);
                switch (next) {
                    case 't': out.append('\t'); break;
                    case 'n': out.append('\n'); break;
                    case 'r': out.append('\r'); break;
                    default: out.append(next);
                }
            } else {
                out.append(c);
            }
        }
        return out.toString();
    }

    private static List<CalendarEvent> readLegacy(Path file) throws IOException {
        try (ObjectInputStream input = new ObjectInputStream(new BufferedInputStream(Files.newInputStream(file)))) {
            Object loaded = input.readObject();
            if (!(loaded instanceof Map<?, ?>)) {
                throw new IOException("Saved events file has an invalid format.");
            }
            // Sort by date so migrated events keep a sensible order.
            Map<LocalDate, List<String>> byDate = new TreeMap<>();
            for (Map.Entry<?, ?> entry : ((Map<?, ?>) loaded).entrySet()) {
                if (!(entry.getKey() instanceof LocalDate) || !(entry.getValue() instanceof List<?>)) {
                    throw new IOException("Saved events file contains invalid entries.");
                }
                List<String> titles = new ArrayList<>();
                for (Object title : (List<?>) entry.getValue()) {
                    if (!(title instanceof String)) {
                        throw new IOException("Saved events file contains an invalid event.");
                    }
                    titles.add((String) title);
                }
                byDate.put((LocalDate) entry.getKey(), titles);
            }
            List<CalendarEvent> events = new ArrayList<>();
            byDate.forEach((date, titles) -> {
                for (String title : titles) {
                    if (!title.trim().isEmpty()) {
                        events.add(new CalendarEvent(title, date));
                    }
                }
            });
            return events;
        } catch (ClassNotFoundException ex) {
            throw new IOException("Saved events file has an invalid format.", ex);
        }
    }
}

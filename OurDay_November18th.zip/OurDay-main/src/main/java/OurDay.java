import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.nio.charset.MalformedInputException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

/** OurDay main window: sidebar on the left, the current view (day, week or month) on the right. */
public class OurDay {
    private static final int TICK_MS = 15_000; // how often reminders and the date are checked
    private static final int UPCOMING_COUNT = 5;
    private static final int UPCOMING_DAYS = 14;
    private static final boolean MAC = System.getProperty("os.name", "").toLowerCase().contains("mac");

    private JFrame frame;
    private CustomizableBackgroundPanel background;
    private CalendarHeader calendarHeader;
    private SidebarPanel sidebar;
    private JPanel viewContainer;
    private JComboBox<String> colorChoice;
    private JSlider opacity;
    private JTextField searchField;
    private JPanel monthGrid;
    private JMenuItem undoItem;
    private JMenuItem redoItem;
    private JMenuItem refreshImportItem;
    private JCheckBoxMenuItem darkItem;

    private final EventManager eventManager = new EventManager(EventManager.defaultEventFile());
    private final ReminderService reminders = new ReminderService(eventManager);
    private AppSettings settings;
    private ViewMode viewMode = ViewMode.MONTH;
    private LocalDate focusDate = LocalDate.now();
    /** The day of the month the user last chose; month arrows return to it after short months. */
    private int preferredDayOfMonth = focusDate.getDayOfMonth();
    private LocalDate lastKnownToday = LocalDate.now();

    private static final String[] WEEKDAYS = {
        "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
    };

    public static void main(String[] args) {
        // On a Mac, put the menus in the menu bar at the top of the screen like other Mac apps.
        System.setProperty("apple.laf.useScreenMenuBar", "true");
        System.setProperty("apple.awt.application.name", "OurDay");
        if (!InstanceLock.acquire(AppSettings.dataDirectory())) {
            // A second window would overwrite the first one's changes when either saves.
            JOptionPane.showMessageDialog(null,
                "OurDay is already open.\nSwitch to the open OurDay window to see your calendar.",
                "OurDay", JOptionPane.INFORMATION_MESSAGE);
            System.exit(0);
            return;
        }
        SwingUtilities.invokeLater(() -> new OurDay().createAndShowGUI());
    }

    private void createAndShowGUI() {
        settings = AppSettings.loadDefault();
        ThemeManager.apply(settings.isDarkTheme());
        viewMode = settings.getView();
        eventManager.load();

        frame = new JFrame("OurDay");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setMinimumSize(new Dimension(980, 680));
        frame.setSize(1180, 800);
        frame.setLocationRelativeTo(null);
        frame.setJMenuBar(createMenuBar());
        buildContent();
        installKeyboardNavigation();
        frame.setVisible(true);
        refreshCalendar();
        startTicker();
    }

    /** Builds everything inside the window (again after the theme changes, so the new colors are used). */
    private void buildContent() {
        background = new CustomizableBackgroundPanel();
        background.setGradient(ThemeManager.BACKGROUND_START, ThemeManager.BACKGROUND_END);
        background.setLayout(new BorderLayout(18, 14));
        background.setBorder(new EmptyBorder(18, 18, 18, 18));

        sidebar = new SidebarPanel(this::showToday, this::showCurrentMonth, this::showSelectedDate);
        background.add(sidebar, BorderLayout.WEST);
        background.add(createMainContent(), BorderLayout.CENTER);

        frame.setContentPane(background);
        applySavedBackground();
        frame.revalidate();
    }

    private JPanel createMainContent() {
        JPanel content = new JPanel(new BorderLayout(12, 14));
        content.setOpaque(false);

        JPanel header = new JPanel(new BorderLayout(8, 8));
        header.setOpaque(false);
        calendarHeader = new CalendarHeader(() -> step(-1), () -> step(1), this::setView);
        header.add(calendarHeader, BorderLayout.CENTER);
        JPanel toolbar = new JPanel(new BorderLayout());
        toolbar.setOpaque(false);
        toolbar.add(createCustomizationBar(), BorderLayout.CENTER);
        toolbar.add(createSearchBox(), BorderLayout.EAST);
        header.add(toolbar, BorderLayout.SOUTH);
        content.add(header, BorderLayout.NORTH);

        viewContainer = new JPanel(new BorderLayout());
        viewContainer.setOpaque(false);
        content.add(viewContainer, BorderLayout.CENTER);
        return content;
    }

    // --- menus ---

    private JMenuBar createMenuBar() {
        int menuKey = Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx();
        int shift = java.awt.event.InputEvent.SHIFT_DOWN_MASK;
        JMenuBar bar = new JMenuBar();

        JMenu file = new JMenu("File");
        file.add(item("Import Calendar File…", KeyStroke.getKeyStroke(KeyEvent.VK_I, menuKey), this::importFromFile));
        file.add(item("Import from Web Address…", null, this::importFromWebAddress));
        refreshImportItem = item("Refresh from Web Address", KeyStroke.getKeyStroke(KeyEvent.VK_R, menuKey),
            () -> downloadAndImport(settings.getCalendarUrl()));
        file.add(refreshImportItem);
        file.addSeparator();
        file.add(item("Export Calendar…", KeyStroke.getKeyStroke(KeyEvent.VK_E, menuKey), this::exportToFile));
        if (!MAC) {
            file.addSeparator();
            file.add(item("Quit", KeyStroke.getKeyStroke(KeyEvent.VK_Q, menuKey), () -> System.exit(0)));
        }
        file.addMenuListener(new javax.swing.event.MenuListener() {
            @Override
            public void menuSelected(javax.swing.event.MenuEvent e) {
                refreshImportItem.setEnabled(settings.getCalendarUrl() != null);
            }

            @Override
            public void menuDeselected(javax.swing.event.MenuEvent e) {
            }

            @Override
            public void menuCanceled(javax.swing.event.MenuEvent e) {
            }
        });
        bar.add(file);

        JMenu edit = new JMenu("Edit");
        undoItem = item("Undo", KeyStroke.getKeyStroke(KeyEvent.VK_Z, menuKey), this::undo);
        redoItem = item("Redo", KeyStroke.getKeyStroke(KeyEvent.VK_Z, menuKey | shift), this::redo);
        edit.add(undoItem);
        edit.add(redoItem);
        edit.addSeparator();
        edit.add(item("New Event…", KeyStroke.getKeyStroke(KeyEvent.VK_N, menuKey), () -> addEventAt(focusDate, null)));
        edit.add(item("Find…", KeyStroke.getKeyStroke(KeyEvent.VK_F, menuKey), () -> openSearch("")));
        bar.add(edit);

        JMenu view = new JMenu("View");
        view.add(item("Day", KeyStroke.getKeyStroke(KeyEvent.VK_1, menuKey), () -> setView(ViewMode.DAY)));
        view.add(item("Week", KeyStroke.getKeyStroke(KeyEvent.VK_2, menuKey), () -> setView(ViewMode.WEEK)));
        view.add(item("Month", KeyStroke.getKeyStroke(KeyEvent.VK_3, menuKey), () -> setView(ViewMode.MONTH)));
        view.addSeparator();
        view.add(item("Today", KeyStroke.getKeyStroke(KeyEvent.VK_T, menuKey), this::showToday));
        view.add(item("Previous", KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, menuKey), () -> step(-1)));
        view.add(item("Next", KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, menuKey), () -> step(1)));
        view.addSeparator();
        darkItem = new JCheckBoxMenuItem("Dark Theme", ThemeManager.isDark());
        darkItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_D, menuKey | shift));
        darkItem.addActionListener(e -> setDarkTheme(darkItem.isSelected()));
        view.add(darkItem);
        bar.add(view);

        JMenu help = new JMenu("Help");
        help.add(item("Keyboard Shortcuts", null, this::showShortcuts));
        help.add(item("About OurDay", null, () -> JOptionPane.showMessageDialog(frame,
            "OurDay 1.2\nA customizable calendar with day, week and month views.\n\n"
                + "Your events are saved in:\n" + eventManager.getEventFile().getAbsolutePath(),
            "About OurDay", JOptionPane.INFORMATION_MESSAGE)));
        bar.add(help);
        return bar;
    }

    private static JMenuItem item(String text, KeyStroke accelerator, Runnable action) {
        JMenuItem item = new JMenuItem(text);
        if (accelerator != null) {
            item.setAccelerator(accelerator);
        }
        item.addActionListener(e -> action.run());
        return item;
    }

    private void updateUndoMenu() {
        if (undoItem == null) {
            return;
        }
        undoItem.setEnabled(eventManager.canUndo());
        undoItem.setText(eventManager.canUndo() ? "Undo " + eventManager.undoDescription() : "Undo");
        redoItem.setEnabled(eventManager.canRedo());
        redoItem.setText(eventManager.canRedo() ? "Redo " + eventManager.redoDescription() : "Redo");
    }

    private void undo() {
        if (eventManager.undo()) {
            refreshCalendar();
        }
    }

    private void redo() {
        if (eventManager.redo()) {
            refreshCalendar();
        }
    }

    private void showShortcuts() {
        String key = MAC ? "⌘" : "Ctrl+";
        String[][] rows = {
            {key + "N", "New event"}, {key + "F", "Find events"}, {key + "Z", "Undo"},
            {key + (MAC ? "⇧Z" : "Shift+Z"), "Redo"}, {key + "T", "Today"},
            {key + "← / " + key + "→", "Previous / next day, week or month"},
            {key + "1 / 2 / 3", "Day / Week / Month view"},
            {"← → ↑ ↓", "Move between days (Month: up/down = a week)"},
            {"Enter", "Open the selected day (Month) or add an event (Day/Week)"},
            {key + "I", "Import a calendar file"}, {key + "E", "Export your calendar"},
            {key + (MAC ? "⇧D" : "Shift+D"), "Dark theme on/off"},
        };
        StringBuilder html = new StringBuilder("<html><table cellpadding='3'>");
        for (String[] row : rows) {
            html.append("<tr><td><b>").append(row[0]).append("</b></td><td>").append(row[1]).append("</td></tr>");
        }
        html.append("</table><br>In Day and Week view: drag an event to move it, or drag its<br>"
            + "bottom edge to change when it ends. In Month view: drag an event<br>to another day.</html>");
        JOptionPane.showMessageDialog(frame, html.toString(), "Keyboard Shortcuts", JOptionPane.PLAIN_MESSAGE);
    }

    // --- theme ---

    private void setDarkTheme(boolean dark) {
        ThemeManager.apply(dark);
        settings.setDarkTheme(dark);
        settings.save();
        darkItem.setSelected(dark);
        SwingUtilities.updateComponentTreeUI(frame);
        buildContent();
        refreshCalendar();
    }

    // --- personalization ---

    private JPanel createCustomizationBar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 9, 6));
        bar.setOpaque(false);

        JLabel customize = new JLabel("Personalize");
        customize.setFont(ThemeManager.SUBTITLE_FONT);
        customize.setForeground(ThemeManager.TEXT);
        bar.add(customize);

        // "Gradient" is listed first so the dropdown matches the default background,
        // and so Reset (which selects index 0) restores it.
        colorChoice = new JComboBox<>(ThemeManager.PALETTE_NAMES);
        colorChoice.setToolTipText("Choose a gradient or solid background");
        colorChoice.addActionListener(e -> {
            String name = (String) colorChoice.getSelectedItem();
            applyPalette(name);
            settings.setPalette(name);
            settings.setImagePath(null); // picking a color replaces any image
            settings.save();
        });
        bar.add(colorChoice);

        JButton chooseImage = new JButton("Choose Image");
        chooseImage.addActionListener(e -> chooseBackgroundImage());
        bar.add(chooseImage);

        JLabel opacityLabel = new JLabel("Image opacity");
        opacityLabel.setForeground(ThemeManager.MUTED_TEXT);
        bar.add(opacityLabel);
        opacity = new JSlider(0, 100, 100);
        opacity.setPreferredSize(new Dimension(110, 30));
        opacity.setOpaque(false);
        opacity.setToolTipText("Adjust image transparency");
        opacity.addChangeListener(e -> {
            background.setImageOpacity(opacity.getValue() / 100f);
            if (!opacity.getValueIsAdjusting()) {
                settings.setOpacity(opacity.getValue());
                settings.save();
            }
        });
        bar.add(opacity);

        JButton reset = new JButton("Reset");
        reset.addActionListener(e -> {
            opacity.setValue(100);
            // Always fires the dropdown's listener, which applies the gradient and clears the image.
            colorChoice.setSelectedIndex(0);
        });
        bar.add(reset);

        JToggleButton dark = new JToggleButton(ThemeManager.isDark() ? "Light" : "Dark");
        dark.setToolTipText("Switch between the light and dark theme");
        dark.addActionListener(e -> setDarkTheme(!ThemeManager.isDark()));
        bar.add(dark);
        return bar;
    }

    private void applyPalette(String name) {
        if (name == null) {
            return;
        }
        if (AppSettings.DEFAULT_PALETTE.equals(name)) {
            background.setGradient(ThemeManager.BACKGROUND_START, ThemeManager.BACKGROUND_END);
        } else {
            background.setSolidColor(ThemeManager.paletteColor(name));
        }
    }

    /** Restores last session's background. Anything that no longer works falls back to the default. */
    private void applySavedBackground() {
        String palette = settings.getPalette();
        String image = settings.getImagePath();
        int savedOpacity = settings.getOpacity();
        try {
            applyPalette(palette);
            selectWithoutSaving(palette);
        } catch (IllegalArgumentException unknownPalette) {
            applyPalette(AppSettings.DEFAULT_PALETTE);
        }
        opacity.setValue(savedOpacity);
        if (image != null) {
            try {
                background.setBackgroundImage(image);
            } catch (IOException missingImage) {
                System.err.println("OurDay: saved background image unavailable: " + missingImage.getMessage());
            }
        }
    }

    /** Sets the dropdown without triggering its listener (which would overwrite the saved image). */
    private void selectWithoutSaving(String palette) {
        java.awt.event.ActionListener[] listeners = colorChoice.getActionListeners();
        for (java.awt.event.ActionListener listener : listeners) {
            colorChoice.removeActionListener(listener);
        }
        colorChoice.setSelectedItem(palette);
        for (java.awt.event.ActionListener listener : listeners) {
            colorChoice.addActionListener(listener);
        }
    }

    private void chooseBackgroundImage() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Choose an OurDay background image");
        chooser.setFileFilter(new FileNameExtensionFilter("Image files", "png", "jpg", "jpeg", "gif", "bmp"));
        if (chooser.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION) {
            String path = chooser.getSelectedFile().getAbsolutePath();
            try {
                background.setBackgroundImage(path);
                settings.setImagePath(path);
                settings.save();
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(frame, ex.getMessage(), "Image Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // --- search ---

    private JComponent createSearchBox() {
        searchField = new JTextField(14) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (getText().isEmpty() && !isFocusOwner()) {
                    g.setColor(ThemeManager.MUTED_TEXT);
                    g.setFont(getFont().deriveFont(Font.ITALIC));
                    Insets in = getInsets();
                    g.drawString("Search events", in.left + 2, in.top + g.getFontMetrics().getAscent() + 1);
                }
            }
        };
        searchField.setToolTipText("Search titles, locations and notes, then press Enter");
        searchField.addActionListener(e -> openSearch(searchField.getText()));
        searchField.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent e) {
                searchField.repaint();
            }

            @Override
            public void focusLost(java.awt.event.FocusEvent e) {
                searchField.repaint();
            }
        });
        JPanel box = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 8));
        box.setOpaque(false);
        box.add(searchField);
        return box;
    }

    private void openSearch(String query) {
        SearchDialog.show(frame, eventManager, query, this::showSelectedDate);
        searchField.setText("");
    }

    // --- import and export ---

    private void importFromFile() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Import a calendar file");
        chooser.setFileFilter(new FileNameExtensionFilter("Calendar files (.ics)", "ics", "ical", "ifb", "icalendar"));
        if (chooser.showOpenDialog(frame) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        File file = chooser.getSelectedFile();
        String text;
        try {
            try {
                text = Files.readString(file.toPath(), StandardCharsets.UTF_8);
            } catch (MalformedInputException notUtf8) {
                text = Files.readString(file.toPath(), StandardCharsets.ISO_8859_1);
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(frame, "Couldn't read " + file.getName() + ":\n" + ex.getMessage(),
                "Import", JOptionPane.ERROR_MESSAGE);
            return;
        }
        importText(text, "Import " + file.getName());
    }

    private void importFromWebAddress() {
        String previous = settings.getCalendarUrl();
        String address = (String) JOptionPane.showInputDialog(frame,
            "<html>Paste the web address of a calendar in iCal format (.ics or webcal://).<br><br>"
                + "<b>Google Calendar:</b> open Settings, choose your calendar on the left, and copy<br>"
                + "“Secret address in iCal format”. (Keep it private: anyone with it can see the calendar.)<br><br>"
                + "Importing the same address again later updates those events instead of copying them.</html>",
            "Import from web address", JOptionPane.PLAIN_MESSAGE, null, null, previous == null ? "" : previous);
        if (address != null && !address.isBlank()) {
            downloadAndImport(address.trim());
        }
    }

    /** Downloads in the background (so the window stays responsive), then imports. */
    private void downloadAndImport(String address) {
        if (address == null) {
            return;
        }
        frame.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        new SwingWorker<String, Void>() {
            @Override
            protected String doInBackground() throws IOException {
                return ICalendar.download(address);
            }

            @Override
            protected void done() {
                frame.setCursor(Cursor.getDefaultCursor());
                try {
                    String text = get();
                    settings.setCalendarUrl(address);
                    settings.save();
                    importText(text, "Import from web");
                } catch (java.util.concurrent.ExecutionException ex) {
                    JOptionPane.showMessageDialog(frame, "Couldn't download the calendar:\n" + ex.getCause().getMessage(),
                        "Import", JOptionPane.ERROR_MESSAGE);
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                }
            }
        }.execute();
    }

    private void importText(String text, String undoDescription) {
        ICalendar.Result result = ICalendar.parse(text, ZoneId.systemDefault());
        EventManager.ImportCounts counts = eventManager.importEvents(result.events, undoDescription);
        refreshCalendar();
        StringBuilder message = new StringBuilder();
        if (result.events.isEmpty() && !result.warnings.isEmpty() && counts.added == 0) {
            message.append("Nothing was imported.");
        } else {
            message.append("Added ").append(counts.added).append(counts.added == 1 ? " event" : " events");
            if (counts.updated > 0) {
                message.append(" and updated ").append(counts.updated).append(" that were imported before");
            }
            message.append('.');
        }
        if (result.cancelled > 0) {
            message.append("\nLeft out ").append(result.cancelled).append(" cancelled event")
                .append(result.cancelled == 1 ? "" : "s").append('.');
        }
        if (!result.warnings.isEmpty()) {
            message.append("\n\nNotes:");
            result.warnings.stream().limit(8).forEach(w -> message.append("\n• ").append(w));
            if (result.warnings.size() > 8) {
                message.append("\n• …and ").append(result.warnings.size() - 8).append(" more");
            }
        }
        if (counts.added + counts.updated > 0) {
            message.append("\n\nUse Edit → Undo to take the import back.");
        }
        JOptionPane.showMessageDialog(frame, message.toString(), "Import", JOptionPane.INFORMATION_MESSAGE);
    }

    private void exportToFile() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Export your calendar");
        chooser.setSelectedFile(new File("OurDay.ics"));
        chooser.setFileFilter(new FileNameExtensionFilter("Calendar files (.ics)", "ics"));
        if (chooser.showSaveDialog(frame) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        File file = chooser.getSelectedFile();
        if (!file.getName().toLowerCase().endsWith(".ics")) {
            file = new File(file.getParentFile(), file.getName() + ".ics");
        }
        if (file.exists() && JOptionPane.showConfirmDialog(frame, file.getName() + " already exists. Replace it?",
                "Export", JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) {
            return;
        }
        try {
            Files.writeString(file.toPath(), ICalendar.export(eventManager.getEvents(), Instant.now()), StandardCharsets.UTF_8);
            int count = eventManager.getEvents().size();
            JOptionPane.showMessageDialog(frame, "Saved " + count + (count == 1 ? " event" : " events") + " to "
                    + file.getName() + ".\n\nYou can import this file into Google Calendar (Settings → Import & export),\n"
                    + "Apple Calendar or Outlook, or back into OurDay.",
                "Export", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(frame, "Couldn't save the file:\n" + ex.getMessage(), "Export",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    // --- views and navigation ---

    private final TimeGridView.Actions gridActions = new TimeGridView.Actions() {
        @Override
        public void add(LocalDate day, LocalTime time) {
            focusOn(day);
            addEventAt(day, time);
        }

        @Override
        public void edit(Occurrence occurrence) {
            editOccurrence(occurrence);
        }

        @Override
        public void openDay(LocalDate day) {
            showSelectedDate(day);
        }

        @Override
        public boolean move(Occurrence occurrence, LocalDate newStartDay, LocalTime start, LocalTime end) {
            return moveOccurrence(occurrence, newStartDay, start, end);
        }
    };

    private void refreshCalendar() {
        if (viewContainer == null) {
            return;
        }
        LocalDate today = LocalDate.now();
        lastKnownToday = today;

        JComponent view;
        monthGrid = null;
        switch (viewMode) {
            case DAY:
                calendarHeader.setTitle(Formats.fullDay(focusDate));
                view = new DayView(focusDate, eventManager, gridActions);
                break;
            case WEEK:
                calendarHeader.setTitle(Formats.weekRange(focusDate));
                view = new WeekView(focusDate, eventManager, gridActions);
                break;
            default:
                calendarHeader.setTitle(Formats.monthYear(focusDate));
                view = createMonthView(YearMonth.from(focusDate), today);
        }
        if (viewMode != ViewMode.MONTH) {
            view = card(view);
        }
        calendarHeader.setView(viewMode);
        sidebar.setMonth(YearMonth.from(focusDate), focusDate, eventManager::hasEventsOn);
        sidebar.setUpcoming(upcoming(LocalDateTime.now()), today);
        updateUndoMenu();

        viewContainer.removeAll();
        viewContainer.add(view, BorderLayout.CENTER);
        viewContainer.revalidate();
        viewContainer.repaint();
    }

    /** Puts a view on a rounded translucent card, like the month cells. */
    private static JComponent card(JComponent view) {
        JPanel card = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics graphics) {
                Graphics2D g = (Graphics2D) graphics.create();
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g.setColor(ThemeManager.CELL);
                g.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 18, 18);
                g.setColor(ThemeManager.BORDER);
                g.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 18, 18);
                g.dispose();
            }
        };
        card.setOpaque(false);
        card.setBorder(new EmptyBorder(4, 4, 4, 4));
        card.add(view, BorderLayout.CENTER);
        return card;
    }

    /** The next few events that haven't finished yet (each multi-day event once). */
    private List<Occurrence> upcoming(LocalDateTime now) {
        List<Occurrence> result = new ArrayList<>();
        LocalDate today = now.toLocalDate();
        for (Occurrence occurrence : eventManager.getOccurrences(today, today.plusDays(UPCOMING_DAYS - 1))) {
            if (!occurrence.isFirstDay() && !occurrence.date().equals(today)) {
                continue; // later days of a multi-day event already listed
            }
            CalendarEvent event = occurrence.event();
            if (!event.isAllDay()) {
                LocalTime end = event.getEndTime() != null ? event.getEndTime()
                    : event.isMultiDay() ? LocalTime.MAX : event.getStartTime();
                if (occurrence.end().atTime(end).isBefore(now)) {
                    continue; // already over
                }
            }
            result.add(occurrence);
            if (result.size() == UPCOMING_COUNT) {
                break;
            }
        }
        return result;
    }

    private JComponent createMonthView(YearMonth month, LocalDate today) {
        JPanel monthView = new JPanel(new BorderLayout(0, 10));
        monthView.setOpaque(false);

        JPanel weekdays = new JPanel(new GridLayout(1, 7, 9, 0));
        weekdays.setOpaque(false);
        for (String weekday : WEEKDAYS) {
            JLabel label = new JLabel(weekday, SwingConstants.CENTER);
            label.setFont(ThemeManager.SUBTITLE_FONT);
            label.setForeground(ThemeManager.MUTED_TEXT);
            weekdays.add(label);
        }
        monthView.add(weekdays, BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridLayout(6, 7, 9, 9));
        grid.setOpaque(false);
        int offset = month.atDay(1).getDayOfWeek().getValue() % 7;
        for (int cell = 0; cell < 42; cell++) {
            int dayNumber = cell - offset + 1;
            if (dayNumber < 1 || dayNumber > month.lengthOfMonth()) {
                JPanel blank = new JPanel();
                blank.setOpaque(false);
                grid.add(blank);
                continue;
            }
            LocalDate date = month.atDay(dayNumber);
            grid.add(new CalendarDayPanel(date, eventManager.getOccurrences(date), date.equals(today),
                date.equals(focusDate), this::manageEventsForDate, this::dropInMonth));
        }
        monthGrid = grid;
        monthView.add(grid, BorderLayout.CENTER);
        return monthView;
    }

    // --- moving events by dragging ---

    /** An event chip was dragged in Month view and let go at {@code screenPoint}. */
    private void dropInMonth(Occurrence occurrence, Point screenPoint) {
        if (monthGrid == null) {
            return;
        }
        Point p = new Point(screenPoint);
        SwingUtilities.convertPointFromScreen(p, monthGrid);
        Component under = SwingUtilities.getDeepestComponentAt(monthGrid, p.x, p.y);
        CalendarDayPanel cell = under instanceof CalendarDayPanel ? (CalendarDayPanel) under
            : (CalendarDayPanel) SwingUtilities.getAncestorOfClass(CalendarDayPanel.class, under);
        if (cell == null || cell.getDate().equals(occurrence.date())) {
            return;
        }
        long shift = ChronoUnit.DAYS.between(occurrence.date(), cell.getDate());
        CalendarEvent event = occurrence.event();
        moveOccurrence(occurrence, occurrence.start().plusDays(shift), event.getStartTime(), event.getEndTime());
    }

    /**
     * Moves one event so the dragged copy starts on {@code newStartDay} at {@code start}
     * (ending at {@code end}). Repeating events can change time (for every repeat,
     * after asking) but not day: their days are set in the event form.
     */
    private boolean moveOccurrence(Occurrence occurrence, LocalDate newStartDay, LocalTime start, LocalTime end) {
        CalendarEvent stored = eventManager.getEvent(occurrence.event().getId());
        if (stored == null) {
            return false;
        }
        CalendarEvent moved = stored.copy();
        String title = "“" + stored.getTitle() + "”";
        if (stored.isRepeating()) {
            if (!newStartDay.equals(occurrence.start())) {
                JOptionPane.showMessageDialog(frame, title + " repeats (" + Formats.repeatSummary(stored) + "), "
                        + "so it can't be dragged to another day.\nOpen it to change which days it repeats on. "
                        + "(Dragging it up or down changes its time.)",
                    "Move repeating event", JOptionPane.INFORMATION_MESSAGE);
                return false;
            }
            String when = Formats.time(start) + (end == null ? "" : " – " + Formats.time(end));
            if (JOptionPane.showConfirmDialog(frame, title + " repeats. Change every repeat to " + when + "?",
                    "Move repeating event", JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) {
                return false;
            }
        } else {
            moved.setDate(stored.getDate().plusDays(ChronoUnit.DAYS.between(occurrence.start(), newStartDay)));
        }
        try {
            moved.setTimes(start, end);
        } catch (IllegalArgumentException ex) {
            return false;
        }
        eventManager.update(moved, "Move " + title);
        if (!moved.occursOn(focusDate) && viewMode == ViewMode.DAY) {
            focusOn(newStartDay); // follow the event when it's dragged off the day being shown
        }
        refreshCalendar();
        return true;
    }

    private void step(int direction) {
        focusDate = viewMode.step(focusDate, direction, preferredDayOfMonth);
        if (viewMode != ViewMode.MONTH) {
            preferredDayOfMonth = focusDate.getDayOfMonth();
        }
        refreshCalendar();
    }

    private void setView(ViewMode mode) {
        viewMode = mode;
        settings.setView(mode);
        settings.save();
        refreshCalendar();
    }

    private void manageEventsForDate(LocalDate date) {
        // Remember the clicked day, so switching to Day or Week view afterwards shows it.
        focusOn(date);
        refreshCalendar();
        EventDialog.show(frame, date, eventManager, this::refreshCalendar);
    }

    private void addEventAt(LocalDate date, LocalTime time) {
        if (EventDialog.addEvent(frame, eventManager, date, time)) {
            refreshCalendar();
        }
    }

    private void editOccurrence(Occurrence occurrence) {
        if (EventDialog.editEvent(frame, eventManager, occurrence)) {
            refreshCalendar();
        }
    }

    /** Moves the main view to {@code date} (and remembers its day for month steps). */
    private void focusOn(LocalDate date) {
        focusDate = date;
        preferredDayOfMonth = date.getDayOfMonth();
    }

    private void showToday() {
        focusOn(LocalDate.now());
        refreshCalendar();
    }

    private void showCurrentMonth() {
        focusOn(LocalDate.now());
        setView(ViewMode.MONTH);
    }

    /** Clicking a date in the mini calendar opens that day in Day view. */
    private void showSelectedDate(LocalDate date) {
        focusOn(date);
        setView(ViewMode.DAY);
    }

    // --- moving around with the keyboard ---

    /**
     * Arrow keys move the selected day (shown with a dashed outline in Month view and
     * underlined in Week view); Enter opens it. Controls that use arrow keys
     * themselves (the search box, dropdowns, the slider) keep them while focused.
     */
    private void installKeyboardNavigation() {
        JRootPane root = frame.getRootPane();
        bindKey(root, KeyEvent.VK_LEFT, "dayBack", () -> moveSelection(-1));
        bindKey(root, KeyEvent.VK_RIGHT, "dayForward", () -> moveSelection(1));
        bindKey(root, KeyEvent.VK_UP, "weekBack", () -> {
            if (viewMode == ViewMode.MONTH) {
                moveSelection(-7);
            }
        });
        bindKey(root, KeyEvent.VK_DOWN, "weekForward", () -> {
            if (viewMode == ViewMode.MONTH) {
                moveSelection(7);
            }
        });
        bindKey(root, KeyEvent.VK_ENTER, "openSelected", () -> {
            if (viewMode == ViewMode.MONTH) {
                manageEventsForDate(focusDate);
            } else {
                addEventAt(focusDate, null);
            }
        });
    }

    private void moveSelection(int days) {
        focusOn(focusDate.plusDays(days));
        refreshCalendar();
    }

    private static void bindKey(JRootPane root, int key, String name, Runnable action) {
        root.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(key, 0), name);
        root.getActionMap().put(name, new AbstractAction() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                Component focused = KeyboardFocusManager.getCurrentKeyboardFocusManager().getFocusOwner();
                if (focused instanceof javax.swing.text.JTextComponent || focused instanceof JComboBox
                        || focused instanceof JSlider || focused instanceof JSpinner || focused instanceof JList) {
                    return; // those controls use the arrow keys themselves
                }
                action.run();
            }
        });
    }

    // --- reminders and the date changing at midnight ---

    private void startTicker() {
        Timer timer = new Timer(TICK_MS, e -> tick());
        timer.setInitialDelay(1500); // show reminders that are already due shortly after launch
        timer.start();
    }

    private void tick() {
        LocalDate now = LocalDate.now();
        if (!now.equals(lastKnownToday)) {
            // Keep the "today" highlight correct when the app stays open past midnight.
            if (focusDate.equals(lastKnownToday)) {
                focusOn(now);
            }
            refreshCalendar();
        } else {
            // Drop events from "Coming up" once they're over.
            sidebar.setUpcoming(upcoming(LocalDateTime.now()), now);
        }
        for (Occurrence due : reminders.collectDue(LocalDateTime.now())) {
            ReminderPopup.show(due,
                minutes -> reminders.snooze(due, minutes, LocalDateTime.now()),
                () -> openFromReminder(due.date()));
        }
    }

    private void openFromReminder(LocalDate date) {
        focusOn(date);
        setView(ViewMode.DAY);
        frame.setState(Frame.NORMAL);
        frame.toFront();
        frame.requestFocus();
    }
}

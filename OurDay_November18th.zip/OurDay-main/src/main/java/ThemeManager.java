import javax.swing.*;
import javax.swing.plaf.ColorUIResource;
import java.awt.Color;
import java.awt.Font;
import java.util.*;

/**
 * Colors and fonts shared by every part of OurDay, in a light and a dark version.
 * Views read these fields when they are built, so after {@link #apply(boolean)}
 * the window is rebuilt to pick up the new colors.
 */
public final class ThemeManager {
    public static Color BACKGROUND_START;
    public static Color BACKGROUND_END;
    public static Color TEXT;
    public static Color MUTED_TEXT;
    public static Color ACCENT;
    /** Card backgrounds (month cells, the time grid). */
    public static Color CELL;
    /** Thin lines around cards and between hours. */
    public static Color BORDER;
    public static Color SIDEBAR_FILL;
    /** Background of today's date in the mini calendar. */
    public static Color TODAY_FILL;
    /** The line showing the current time in Day and Week view. */
    public static Color NOW_LINE;
    /** Text of destructive buttons such as Delete. */
    public static Color DANGER;
    public static Color POPUP_BACKGROUND;

    /** Background choices in the Personalize menu. "Gradient" is the default look. */
    public static final String[] PALETTE_NAMES = {"Gradient", "White", "Rose", "Lavender", "Sky Blue", "Mint", "Peach"};
    public static final Font TITLE_FONT = new Font("SansSerif", Font.BOLD, 24);
    public static final Font SUBTITLE_FONT = new Font("SansSerif", Font.BOLD, 13);
    public static final Font BODY_FONT = new Font("SansSerif", Font.PLAIN, 13);

    private static boolean dark;
    /** The look-and-feel's own colors, saved the first time dark mode is applied so light mode can restore them. */
    private static Map<String, Object> lightDefaults;

    private static final String[] DARK_KEYS = {
        "Panel.background", "OptionPane.background", "OptionPane.messageForeground", "Label.foreground",
        "Button.background", "Button.foreground", "ToggleButton.background", "ToggleButton.foreground",
        "CheckBox.background", "CheckBox.foreground", "RadioButton.background", "RadioButton.foreground",
        "ComboBox.background", "ComboBox.foreground", "ComboBox.selectionBackground", "ComboBox.selectionForeground",
        "ComboBox.buttonBackground",
        "TextField.background", "TextField.foreground", "TextField.caretForeground", "TextField.inactiveBackground",
        "FormattedTextField.background", "FormattedTextField.foreground", "FormattedTextField.caretForeground",
        "TextArea.background", "TextArea.foreground", "TextArea.caretForeground",
        "Spinner.background", "List.background", "List.foreground", "List.selectionBackground", "List.selectionForeground",
        "ScrollPane.background", "Viewport.background", "Slider.background", "Slider.foreground",
        "MenuBar.background", "Menu.background", "Menu.foreground", "Menu.selectionBackground", "Menu.selectionForeground",
        "MenuItem.background", "MenuItem.foreground", "MenuItem.selectionBackground", "MenuItem.selectionForeground",
        "MenuItem.acceleratorForeground", "CheckBoxMenuItem.background", "CheckBoxMenuItem.foreground",
        "CheckBoxMenuItem.selectionBackground", "CheckBoxMenuItem.selectionForeground", "PopupMenu.background",
        "ToolTip.background", "ToolTip.foreground", "Separator.foreground",
        "ScrollBar.background", "ScrollBar.track", "ScrollBar.thumb", "ScrollBar.thumbShadow", "ScrollBar.thumbHighlight",
        "FileChooser.listViewBackground", "Table.background", "Table.foreground", "TableHeader.background",
        "TableHeader.foreground",
        "Button.gradient", "ToggleButton.gradient", "CheckBox.gradient", "RadioButton.gradient", "ScrollBar.gradient",
        "Slider.gradient", "MenuBar.gradient", "Button.select", "ToggleButton.select"
    };

    static {
        setColors(false);
    }

    private ThemeManager() {
    }

    public static boolean isDark() {
        return dark;
    }

    /** Switches every color (OurDay's own and the standard Swing controls') to the light or dark theme. */
    public static void apply(boolean useDark) {
        if (lightDefaults == null) {
            lightDefaults = new HashMap<>();
            for (String key : DARK_KEYS) {
                lightDefaults.put(key, UIManager.get(key));
            }
        }
        setColors(useDark);
        if (useDark) {
            Color window = new ColorUIResource(0x1E, 0x22, 0x2E);
            Color control = new ColorUIResource(0x2C, 0x32, 0x42);
            Color field = new ColorUIResource(0x25, 0x2A, 0x38);
            Color text = new ColorUIResource(TEXT);
            Color selection = new ColorUIResource(0x45, 0x50, 0x8C);
            for (String key : DARK_KEYS) {
                Object value;
                if (key.endsWith(".gradient")) {
                    value = Arrays.asList(0.3f, 0f, new ColorUIResource(0x3A, 0x41, 0x55),
                        new ColorUIResource(0x30, 0x36, 0x48), new ColorUIResource(0x2C, 0x32, 0x42));
                } else if (key.endsWith("oreground") || key.endsWith("caretForeground")) {
                    value = key.contains("selection") ? new ColorUIResource(Color.WHITE)
                        : key.equals("MenuItem.acceleratorForeground") ? new ColorUIResource(MUTED_TEXT) : text;
                } else if (key.contains("election") || key.endsWith(".select")) {
                    value = selection;
                } else if (key.startsWith("TextField") || key.startsWith("FormattedTextField")
                        || key.startsWith("TextArea") || key.startsWith("List") || key.startsWith("Spinner")
                        || key.startsWith("Table.") || key.equals("FileChooser.listViewBackground")) {
                    value = field;
                } else if (key.startsWith("Button") || key.startsWith("ToggleButton") || key.startsWith("ComboBox")
                        || key.startsWith("ScrollBar.thumb")) {
                    value = control;
                } else {
                    value = window;
                }
                UIManager.put(key, value);
            }
        } else {
            lightDefaults.forEach(UIManager::put);
        }
    }

    private static void setColors(boolean useDark) {
        dark = useDark;
        if (useDark) {
            BACKGROUND_START = new Color(28, 32, 48);
            BACKGROUND_END = new Color(44, 30, 46);
            TEXT = new Color(226, 230, 240);
            MUTED_TEXT = new Color(150, 158, 180);
            ACCENT = new Color(140, 156, 255);
            CELL = new Color(38, 43, 58, 235);
            BORDER = new Color(64, 71, 92);
            SIDEBAR_FILL = new Color(30, 34, 46, 200);
            TODAY_FILL = new Color(60, 70, 120);
            NOW_LINE = new Color(255, 110, 110);
            DANGER = new Color(255, 130, 130);
            POPUP_BACKGROUND = new Color(38, 43, 58);
        } else {
            BACKGROUND_START = new Color(225, 232, 255);
            BACKGROUND_END = new Color(255, 235, 245);
            TEXT = new Color(44, 53, 78);
            MUTED_TEXT = new Color(106, 116, 140);
            ACCENT = new Color(97, 112, 205);
            CELL = new Color(255, 255, 255, 235);
            BORDER = new Color(227, 230, 240);
            SIDEBAR_FILL = new Color(255, 255, 255, 185);
            TODAY_FILL = new Color(221, 226, 255);
            NOW_LINE = new Color(220, 70, 70);
            DANGER = new Color(180, 60, 60);
            POPUP_BACKGROUND = Color.WHITE;
        }
    }

    /** The solid background color for a palette name (a deep version of it in the dark theme). */
    public static Color paletteColor(String name) {
        Color light;
        switch (name) {
            case "White":
                light = Color.WHITE;
                break;
            case "Rose":
                light = new Color(255, 224, 235);
                break;
            case "Lavender":
                light = new Color(232, 222, 255);
                break;
            case "Sky Blue":
                light = new Color(218, 237, 255);
                break;
            case "Mint":
                light = new Color(218, 246, 231);
                break;
            case "Peach":
                light = new Color(255, 230, 210);
                break;
            default:
                throw new IllegalArgumentException("Unknown background palette: " + name);
        }
        if (!dark) {
            return light;
        }
        // Same hue, much darker: mix 18% of the color with a dark base.
        Color base = new Color(24, 27, 38);
        return new Color(mix(base.getRed(), light.getRed()), mix(base.getGreen(), light.getGreen()),
            mix(base.getBlue(), light.getBlue()));
    }

    private static int mix(int base, int color) {
        return (int) Math.round(base * 0.82 + color * 0.18);
    }
}

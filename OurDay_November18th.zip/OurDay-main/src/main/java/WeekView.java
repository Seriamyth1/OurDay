import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** Sunday to Saturday as seven hour-by-hour columns (see {@link TimeGridView}). */
public class WeekView extends TimeGridView {
    public WeekView(LocalDate anyDayInWeek, EventManager manager, Actions actions) {
        super(week(anyDayInWeek), manager, anyDayInWeek, actions);
    }

    private static List<LocalDate> week(LocalDate anyDay) {
        List<LocalDate> days = new ArrayList<>();
        LocalDate start = Formats.startOfWeek(anyDay);
        for (int i = 0; i < 7; i++) {
            days.add(start.plusDays(i));
        }
        return days;
    }
}

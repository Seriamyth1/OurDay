import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.Locale;

/** Shared date/time wording so every view phrases things the same way. */
public final class Formats {
    // Patterns are spelled out (rather than localized styles) because recent JDKs put a
    // narrow no-break space before AM/PM, which some fonts draw as an empty box.
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("h:mm a", Locale.US);
    private static final DateTimeFormatter HOUR = DateTimeFormatter.ofPattern("h a", Locale.US);
    private static final DateTimeFormatter MONTH_YEAR = DateTimeFormatter.ofPattern("MMMM yyyy", Locale.US);
    private static final DateTimeFormatter FULL_DAY = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy", Locale.US);
    private static final DateTimeFormatter MONTH_DAY = DateTimeFormatter.ofPattern("MMM d", Locale.US);
    private static final DateTimeFormatter MONTH_DAY_YEAR = DateTimeFormatter.ofPattern("MMM d, yyyy", Locale.US);
    private static final DateTimeFormatter SHORT_DAY = DateTimeFormatter.ofPattern("EEE, MMM d", Locale.US);
    private static final String DASH = " \u2013 ";

    private Formats() {
    }

    /** Weeks run Sunday to Saturday, matching the month grid. */
    public static LocalDate startOfWeek(LocalDate date) {
        return date.with(TemporalAdjusters.previousOrSame(DayOfWeek.SUNDAY));
    }

    public static String time(LocalTime time) {
        return TIME.format(time);
    }

    public static String hour(int hour) {
        return HOUR.format(LocalTime.of(hour, 0));
    }

    public static String monthYear(LocalDate date) {
        return MONTH_YEAR.format(date);
    }

    public static String fullDay(LocalDate date) {
        return FULL_DAY.format(date);
    }

    public static String shortDay(LocalDate date) {
        return SHORT_DAY.format(date);
    }

    /** e.g. "Nov 8 - 14, 2026", "Nov 29 - Dec 5, 2026", "Dec 27, 2026 - Jan 2, 2027". */
    public static String weekRange(LocalDate anyDayInWeek) {
        LocalDate start = startOfWeek(anyDayInWeek);
        LocalDate end = start.plusDays(6);
        if (start.getYear() != end.getYear()) {
            return MONTH_DAY_YEAR.format(start) + DASH + MONTH_DAY_YEAR.format(end);
        }
        if (start.getMonth() != end.getMonth()) {
            return MONTH_DAY.format(start) + DASH + MONTH_DAY.format(end) + ", " + end.getYear();
        }
        return MONTH_DAY.format(start) + DASH + end.getDayOfMonth() + ", " + end.getYear();
    }

    /**
     * "All day", "9:00 AM" or "9:00 AM - 10:30 AM"; for multi-day events (first copy)
     * "Nov 18 - Nov 20" or "Nov 18, 9:00 AM - Nov 20, 5:00 PM".
     */
    public static String timeRange(CalendarEvent event) {
        return timeRange(event, event.getDate(), event.getEndDate());
    }

    /** Like {@link #timeRange(CalendarEvent)}, but with the dates of this particular copy of the event. */
    public static String timeRange(Occurrence occurrence) {
        return timeRange(occurrence.event(), occurrence.start(), occurrence.end());
    }

    private static String timeRange(CalendarEvent event, LocalDate start, LocalDate end) {
        if (!event.isMultiDay()) {
            if (event.isAllDay()) {
                return "All day";
            }
            String from = time(event.getStartTime());
            return event.getEndTime() == null ? from : from + DASH + time(event.getEndTime());
        }
        if (event.isAllDay()) {
            return MONTH_DAY.format(start) + DASH + MONTH_DAY.format(end);
        }
        String from = MONTH_DAY.format(start) + ", " + time(event.getStartTime());
        String to = MONTH_DAY.format(end) + (event.getEndTime() == null ? "" : ", " + time(event.getEndTime()));
        return from + DASH + to;
    }

    /**
     * "Weekly on Mon, Wed, Fri until Dec 18, 2026", "Every 2 weeks on Tue", or ""
     * for one-time events.
     */
    public static String repeatSummary(CalendarEvent event) {
        String summary;
        int n = event.getInterval();
        switch (event.getRecurrence()) {
            case NONE:
                return "";
            case DAILY:
                summary = n == 1 ? "Daily" : "Every " + n + " days";
                break;
            case WEEKLY:
                StringBuilder days = new StringBuilder();
                for (DayOfWeek day : DayOfWeek.values()) {
                    if (event.effectiveRepeatDays().contains(day)) {
                        if (days.length() > 0) {
                            days.append(", ");
                        }
                        days.append(day.getDisplayName(java.time.format.TextStyle.SHORT, Locale.US));
                    }
                }
                summary = (n == 1 ? "Weekly" : "Every " + n + " weeks") + " on " + days;
                break;
            case MONTHLY:
                summary = (n == 1 ? "Monthly" : "Every " + n + " months") + " on day " + event.getDate().getDayOfMonth();
                break;
            case YEARLY:
                summary = (n == 1 ? "Yearly" : "Every " + n + " years") + " on " + MONTH_DAY.format(event.getDate());
                break;
            default:
                summary = "";
        }
        if (event.getRepeatUntil() != null) {
            summary += " until " + MONTH_DAY_YEAR.format(event.getRepeatUntil());
        }
        return summary;
    }

    /** "15 minutes before", "1 hour before", "At start time"... */
    public static String reminder(int minutes) {
        if (minutes < 0) {
            return "No reminder";
        }
        if (minutes == 0) {
            return "At start time";
        }
        if (minutes % 1440 == 0) {
            int days = minutes / 1440;
            return days + (days == 1 ? " day" : " days") + " before";
        }
        if (minutes % 60 == 0) {
            int hours = minutes / 60;
            return hours + (hours == 1 ? " hour" : " hours") + " before";
        }
        return minutes + (minutes == 1 ? " minute" : " minutes") + " before";
    }
}

# OurDay

OurDay is a free, Java-based customizable calendar application with daily, weekly, and monthly views.

## Description

OurDay is a customizable desktop calendar application designed to make schedule management easier, more flexible, and more enjoyable.
It helps users organize daily responsibilities, upcoming tasks, appointments, deadlines, and important events through a clean calendar
experience that can be personalized to match each user's preferences.

Key features:

* **Day, Week and Month views:** Day and Week show an hour-by-hour grid where each event's block matches its
  length and overlapping events sit side by side; Month shows the whole month at a glance.
* **Drag and drop:** drag an event to a new time or day, or drag its bottom edge to change when it ends.
  In Month view, drag an event onto another day.
* **Event details:** all-day or timed, a location, notes, and one of seven color-coded categories
  (Work, School, Family, Errands, Health, Hobbies, Other).
* **Multi-day events:** trips, conferences or a red-eye flight that ends the next morning.
* **Repeating events:** every N days, weeks (on chosen weekdays, e.g. Mon/Wed/Fri), months or years, with an
  optional end date. A single day can be removed without deleting the whole series.
* **Reminders:** a pop-up from 5 minutes to 1 day before an event, with Snooze and Open buttons.
  The pop-up appears even when OurDay is minimized.
* **Search, undo and redo:** find events by title, location or notes; undo any change, including deletes and imports.
* **Import and export:** exchange `.ics` files with Google Calendar, Apple Calendar and Outlook, or import a
  Google calendar straight from its private web address (and refresh it later).
* **Personalize:** light or dark theme, and a gradient, solid color or your own picture as the background.
  OurDay remembers your choices and your last view.

All calendar data is saved locally, so OurDay works without an internet connection.

## Tech Stack

* **Language:** Java 17+
* **User Interface:** Java Swing
* **Local Storage:** a plain-text events file in `~/.ourday/` (no database needed)
* **Calendar exchange:** iCalendar (`.ics`, RFC 5545), read and written by OurDay itself (no extra libraries)
* **Build Tool:** Maven
* **Testing:** JUnit 5
* **Version Control:** Git and GitHub

## Getting Started

### Running OurDay (no Maven needed)

To just use OurDay you only need:

* Windows, macOS or Linux
* Java 17 or newer ([Adoptium Temurin](https://adoptium.net) is a free option). Check with `java -version`.
* The `ourday.jar` file (download it from the project's **Releases** page on GitHub)

Then double-click `ourday.jar`, or run:

```bash
java -jar ourday.jar
```

OurDay has no other dependencies and needs no internet connection.

### Building from source (for developers)

Building also needs **Maven 3.8+** (most IDEs, such as IntelliJ IDEA, include it). Wi-Fi is only needed
the first time you build, so Maven can download JUnit for the tests.

```bash
git clone <this repository's URL>
cd OurDay
mvn package
```

This runs the tests and creates `target/ourday.jar`, which you can run with `java -jar target/ourday.jar`
or share with others. You can also run `OurDay` (in `src/main/java/OurDay.java`) from your IDE.

To run only the tests:

```bash
mvn test
```

**Automatic builds on GitHub:** `ci/github-actions-build.yml` makes GitHub build OurDay and run every test
on each push. To turn it on, move it to `.github/workflows/build.yml` (create those folders), delete the `ci`
folder, and push. After that, results appear in the **Actions** tab (so a broken change is caught even if nobody
ran the tests locally) and each run's `ourday.jar` is under **Artifacts**. To publish a version for users, push a
tag, e.g. `git tag v1.2.0 && git push --tags`; the jar then appears on the **Releases** page.

**GUI tests:** `bash gui-tests/run.sh` starts the real app and clicks through adding, editing and deleting
events, repeats, drag and drop, undo/redo, search, import/export, the dark theme, keyboard navigation,
restarting, and recovering from a damaged events file (51 checks). It uses a
temporary home folder, so your own calendar is never touched. It moves the real mouse, so leave the computer
alone while it runs (on macOS, allow your terminal under Privacy & Security > Accessibility first).

**Without Maven:** the program itself only uses the Java standard library, so the JDK alone can build the
jar (this skips the tests, which need JUnit):

```bash
javac --release 17 -d out src/main/java/*.java
jar --create --file ourday.jar --main-class OurDay -C out .
```

### Using OurDay

* Switch views with **Day / Week / Month**; the arrows move one day, week or month.
* **Day and Week view:** click empty space to add an event at that time (or the "All day" row for an all-day
  event). Click an event to edit it. Drag it to move it, or drag its bottom edge to change its end time.
  In Week view, click a day's name to open that day.
* **Month view:** click a day to see, add, edit or delete its events. Drag an event onto another day to move it.
* **Repeating events** can be dragged up or down to change the time of every repeat (OurDay asks first).
  To change which days they repeat on, open them.
* Click a date in the sidebar's mini calendar to jump to it. Bold dates have events.
* **Coming up** in the sidebar lists your next few events; click one to open its day.
* **Search:** type in the search box (top right) and press Enter, or use Edit > Find.
* **Undo:** Edit > Undo takes back the last change (moves, edits, deletes, imports). Redo puts it back.
* **Personalize:** pick a background, or click **Dark** for the dark theme. **Reset** returns to the default gradient.
* In the event form, changing the start time moves the end time along with it.

**Keyboard shortcuts** (Cmd on a Mac, Ctrl on Windows/Linux). Help > Keyboard Shortcuts shows them too.

| Shortcut | Action |
|---|---|
| Cmd/Ctrl + N | New event on the day you're viewing |
| Cmd/Ctrl + F | Search events |
| Cmd/Ctrl + Z / Cmd/Ctrl + Shift + Z | Undo / redo |
| Cmd/Ctrl + Left / Right | Previous / next day, week or month |
| Cmd/Ctrl + T | Jump to today |
| Cmd/Ctrl + 1 / 2 / 3 | Day / Week / Month view |
| Arrow keys | Move between days (in Month view, up/down moves a week) |
| Enter | Open the selected day (Month) or add an event on it (Day/Week) |
| Cmd/Ctrl + I / E | Import a calendar file / export your calendar |
| Cmd/Ctrl + R | Refresh a calendar imported from a web address |
| Cmd/Ctrl + Shift + D | Dark theme on or off |

### Using OurDay with Google Calendar, Apple Calendar or Outlook

* **Bring events in:** File > Import Calendar File and pick a `.ics` file. To export one from Google Calendar,
  go to Settings > Import & export > Export.
* **Follow a Google calendar:** in Google Calendar, open Settings, choose the calendar on the left and copy
  **Secret address in iCal format**. In OurDay choose File > Import from Web Address and paste it. Later,
  File > Refresh from Web Address picks up changes (events imported before are updated, not duplicated).
  Keep that address private: anyone who has it can see the calendar.
* **Send events out:** File > Export Calendar saves a `.ics` file you can import into Google Calendar
  (Settings > Import & export > Import), Apple Calendar or Outlook.
* An import can be taken back with Edit > Undo. Anything OurDay can't show exactly (for example "the 2nd
  Monday of every month") is listed after the import, and only that event's first date is added.

## What's new in 1.2

* Day and Week views are now an hour-by-hour grid with side-by-side overlapping events and a current-time line.
* Drag and drop to move events and change their length, in Day, Week and Month view.
* Location and notes on events, multi-day events, and "every N" repeats (e.g. every 2 weeks).
* Search, undo/redo, a dark theme, a menu bar, and keyboard navigation with the arrow keys and Enter.
* Import and export of `.ics` calendar files, and importing a Google calendar from its web address.
* Fixes: a reminder in the hour skipped when clocks spring forward is no longer missed; a multi-day event reminds
  once, at its start; one damaged line in the events file no longer hides every other event; opening OurDay twice
  can no longer lose events; busy days in Day and Month view no longer hide events; reminders work while a dialog
  is open; moving or changing an event after its reminder showed brings the reminder back.

## Known limitations

These are known and intentional for now:

* **Java 17 is required.** Users install Java once (it's free), then open `ourday.jar`. A double-click Mac app or
  Windows installer with Java built in can be made with the JDK's `jpackage` tool, but it has to be built on each
  operating system and isn't set up yet.
* **Reminders only appear while OurDay is open.** It can be minimized, but closing the window stops reminders.
  OurDay doesn't start by itself when you log in.
* **Syncing with Google Calendar is one-way.** OurDay can import a Google calendar and refresh it, and you can
  import OurDay's exported file into Google, but changes made in OurDay don't flow back to Google automatically.
  Two-way sync would need Google's API, a registered Google Cloud project and a sign-in, which a free,
  offline app like this doesn't have.
* **Some repeat patterns aren't supported:** "the 2nd Monday of every month", "the last weekday of the month", or
  several different times in one event. Weekly, every-N and fixed-date repeats are.
* **Repeating events can't be dragged to another day**, only to another time; their days are changed in the form.
  Changing one repeat on its own (rather than the whole series) isn't supported either, except deleting it.
* **One calendar, one computer.** There are no separate calendars to show or hide, no sharing or inviting people,
  and events aren't backed up anywhere except the `~/.ourday` folder.
* **Times are local.** Events are stored in your computer's local time; if you travel to another time zone, the
  times stay the same clock times. Imported events with a time zone are converted to your local time.
* **Keyboard and screen readers:** days and events can be reached with the keyboard as described above, but the
  calendar hasn't been tested with screen-reader software.
* **One window.** OurDay can only be open once at a time, so two copies can't overwrite each other's changes.

## Help

**Where are my events stored?**
In `~/.ourday/ourday-events.dat` (on Windows: `C:\Users\<you>\.ourday\`). It's a plain-text file, one event per line.
Settings are in `settings.properties` in the same folder.

**I used an older version of OurDay. Are my events still there?**
Yes. Events saved by OurDay 1.0 and 1.1 load as they are; the new details (location, notes, end day, repeat
interval) are simply empty until you add them. For the very first version, which saved events in the folder it
was started from, OurDay copies the old `ourday-events.dat` on first launch, converts it to the new format, and
keeps the original as `ourday-events.dat.v1.bak`.

**OurDay said it skipped some lines of my events file.**
Those lines couldn't be read (for example after editing the file by hand). Every other event was loaded, and the
original file was kept as `ourday-events.dat.<date-time>.bak` so nothing is lost.

**OurDay said it couldn't load my events.**
The unreadable file is never overwritten. It's renamed to `ourday-events.dat.<date-time>.bak` in the same
folder so it can be recovered.

**OurDay says it's already open.**
Only one OurDay window can run at a time, because two windows would overwrite each other's changes.
Switch to the window that's already open.

**Reminders didn't appear.**
Reminders only appear while OurDay is running (it can be minimized). For all-day events, reminder times count from 9:00 AM.
For an event set during the hour that's skipped when clocks spring forward (e.g. 2:30 AM), the reminder is based on
the time the clock actually shows then (3:30 AM).

**An event I dragged went back where it was.**
Repeating events can only be dragged to another time on the same day. Open the event to change which days it repeats on.

**Can I undo an import?**
Yes: Edit > Undo right after importing removes everything the import added or changed.

## Authors

* Ramir Moses
* Heriberto Chavez-Pullman

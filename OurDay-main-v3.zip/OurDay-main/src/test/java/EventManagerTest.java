import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.io.ObjectOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

class EventManagerTest {
    private static final LocalDate DAY = LocalDate.of(2026, 11, 13);

    @TempDir
    Path dir;

    private final List<String> errors = new ArrayList<>();

    private EventManager manager(File file) {
        EventManager manager = new EventManager(file, errors::add);
        manager.load();
        return manager;
    }

    @Test
    void eventsSurviveARestartWithAllFields() {
        File file = dir.resolve("events.dat").toFile();
        EventManager first = manager(file);
        CalendarEvent event = new CalendarEvent("Grade\tfinals \\ \"exam 3\"\nsection 2", DAY);
        event.setTimes(LocalTime.of(14, 30), LocalTime.of(16, 0));
        event.setCategory(Category.WORK);
        event.setRecurrence(Recurrence.WEEKLY);
        event.setRepeatDays(EnumSet.of(DayOfWeek.MONDAY, DayOfWeek.FRIDAY));
        event.setRepeatUntil(DAY.plusMonths(1));
        event.setReminderMinutes(15);
        event.skipDate(DAY.plusDays(3));
        first.add(event);

        CalendarEvent loaded = manager(file).getEvent(event.getId());
        assertNotNull(loaded);
        assertEquals(event.getTitle(), loaded.getTitle());
        assertEquals(LocalTime.of(14, 30), loaded.getStartTime());
        assertEquals(LocalTime.of(16, 0), loaded.getEndTime());
        assertEquals(Category.WORK, loaded.getCategory());
        assertEquals(Recurrence.WEEKLY, loaded.getRecurrence());
        assertEquals(EnumSet.of(DayOfWeek.MONDAY, DayOfWeek.FRIDAY), loaded.getRepeatDays());
        assertEquals(DAY.plusMonths(1), loaded.getRepeatUntil());
        assertEquals(15, loaded.getReminderMinutes());
        assertEquals(Set.of(DAY.plusDays(3)), new HashSet<>(loaded.getSkippedDates()));
        assertTrue(errors.isEmpty());
    }

    @Test
    void occurrencesAreSortedAllDayFirstThenByTime() {
        EventManager manager = manager(dir.resolve("events.dat").toFile());
        CalendarEvent late = new CalendarEvent("Late", DAY);
        late.setTimes(LocalTime.of(18, 0), null);
        CalendarEvent early = new CalendarEvent("Early", DAY);
        early.setTimes(LocalTime.of(8, 0), null);
        CalendarEvent allDay = new CalendarEvent("Due date", DAY);
        manager.add(late);
        manager.add(early);
        manager.add(allDay);

        List<String> titles = manager.getOccurrences(DAY).stream()
            .map(o -> o.event().getTitle()).collect(Collectors.toList());
        assertEquals(List.of("Due date", "Early", "Late"), titles);
    }

    @Test
    void deletingOneRepeatKeepsTheOthers() {
        File file = dir.resolve("events.dat").toFile();
        EventManager manager = manager(file);
        CalendarEvent daily = new CalendarEvent("Walk", DAY);
        daily.setRecurrence(Recurrence.DAILY);
        manager.add(daily);

        manager.removeOccurrence(daily.getId(), DAY.plusDays(1));
        EventManager reloaded = manager(file);
        assertTrue(reloaded.hasEventsOn(DAY));
        assertFalse(reloaded.hasEventsOn(DAY.plusDays(1)));
        assertTrue(reloaded.hasEventsOn(DAY.plusDays(2)));

        reloaded.remove(daily.getId());
        assertFalse(manager(file).hasEventsOn(DAY.plusDays(2)));
    }

    @Test
    void updateReplacesTheStoredEvent() {
        File file = dir.resolve("events.dat").toFile();
        EventManager manager = manager(file);
        CalendarEvent event = new CalendarEvent("Draft", DAY);
        manager.add(event);
        CalendarEvent edited = event.copy();
        edited.setTitle("Final");
        manager.update(edited);
        assertEquals("Final", manager(file).getEvent(event.getId()).getTitle());
        assertEquals(1, manager.getEvents().size());
    }

    @Test
    void unreadableFileIsBackedUpAndNotOverwritten() throws Exception {
        Path file = dir.resolve("events.dat");
        Files.writeString(file, "this is not an events file");

        EventManager manager = manager(file.toFile());
        assertEquals(1, errors.size());
        assertTrue(manager.getEvents().isEmpty());

        List<Path> backups = list(dir, ".bak");
        assertEquals(1, backups.size());
        assertEquals("this is not an events file", Files.readString(backups.get(0)));

        manager.add(new CalendarEvent("New", DAY));
        assertEquals("this is not an events file", Files.readString(backups.get(0)));
        assertTrue(manager(file.toFile()).hasEventsOn(DAY));
    }

    @Test
    void oldVersionOneFilesAreMigrated() throws Exception {
        Path file = dir.resolve("events.dat");
        HashMap<LocalDate, List<String>> legacy = new HashMap<>();
        legacy.put(DAY, new ArrayList<>(List.of("Soccer practice", "Pick up Jane")));
        try (ObjectOutputStream out = new ObjectOutputStream(Files.newOutputStream(file))) {
            out.writeObject(legacy);
        }

        EventManager manager = manager(file.toFile());
        assertTrue(errors.isEmpty());
        assertEquals(2, manager.getOccurrences(DAY).size());
        assertTrue(manager.getOccurrences(DAY).get(0).event().isAllDay());
        assertTrue(Files.exists(dir.resolve("events.dat.v1.bak")), "old file is kept");
        assertFalse(EventFileFormat.isLegacyFile(file), "file is rewritten in the new format");
        assertTrue(Files.readString(file, StandardCharsets.UTF_8).startsWith(EventFileFormat.HEADER));
    }

    @Test
    void savingLeavesNoTemporaryFiles() throws Exception {
        EventManager manager = manager(dir.resolve("events.dat").toFile());
        manager.add(new CalendarEvent("One", DAY));
        manager.add(new CalendarEvent("Two", DAY));
        assertTrue(list(dir, ".tmp").isEmpty());
    }

    private static List<Path> list(Path dir, String suffix) throws Exception {
        try (Stream<Path> files = Files.list(dir)) {
            return files.filter(p -> p.toString().endsWith(suffix)).collect(Collectors.toList());
        }
    }
}

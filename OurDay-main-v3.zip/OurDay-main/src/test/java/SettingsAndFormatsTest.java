import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.*;

class SettingsAndFormatsTest {
    @TempDir
    Path dir;

    @Test
    void settingsRoundTrip() {
        File file = dir.resolve("settings.properties").toFile();
        AppSettings settings = new AppSettings(file);
        settings.setPalette("Mint");
        settings.setImagePath("/pictures/beach.png");
        settings.setOpacity(40);
        settings.setView(ViewMode.WEEK);
        settings.save();

        AppSettings loaded = new AppSettings(file);
        loaded.load();
        assertEquals("Mint", loaded.getPalette());
        assertEquals("/pictures/beach.png", loaded.getImagePath());
        assertEquals(40, loaded.getOpacity());
        assertEquals(ViewMode.WEEK, loaded.getView());
    }

    @Test
    void missingOrBrokenSettingsUseDefaults() throws Exception {
        AppSettings missing = new AppSettings(dir.resolve("nope.properties").toFile());
        missing.load();
        assertEquals(AppSettings.DEFAULT_PALETTE, missing.getPalette());
        assertNull(missing.getImagePath());
        assertEquals(100, missing.getOpacity());
        assertEquals(ViewMode.MONTH, missing.getView());

        Path broken = Files.writeString(dir.resolve("broken.properties"), "background.opacity=lots\nview=SIDEWAYS\n");
        AppSettings settings = new AppSettings(broken.toFile());
        settings.load();
        assertEquals(100, settings.getOpacity());
        assertEquals(ViewMode.MONTH, settings.getView());
    }

    @Test
    void weekRangesReadNaturally() {
        assertEquals("Nov 8 \u2013 14, 2026", Formats.weekRange(LocalDate.of(2026, 11, 13)));
        assertEquals("Nov 29 \u2013 Dec 5, 2026", Formats.weekRange(LocalDate.of(2026, 12, 1)));
        assertEquals("Dec 27, 2026 \u2013 Jan 2, 2027", Formats.weekRange(LocalDate.of(2026, 12, 31)));
    }

    @Test
    void viewStepsMoveByTheRightAmount() {
        LocalDate day = LocalDate.of(2026, 1, 31);
        assertEquals(LocalDate.of(2026, 2, 1), ViewMode.DAY.step(day, 1));
        assertEquals(LocalDate.of(2026, 1, 24), ViewMode.WEEK.step(day, -1));
        assertEquals(LocalDate.of(2026, 2, 28), ViewMode.MONTH.step(day, 1));
    }

    @Test
    void eventDescriptions() {
        CalendarEvent event = new CalendarEvent("Pickup", LocalDate.of(2026, 11, 9));
        assertEquals("All day", Formats.timeRange(event));
        event.setTimes(LocalTime.of(15, 0), LocalTime.of(15, 30));
        assertEquals("3:00 PM \u2013 3:30 PM", Formats.timeRange(event));
        event.setRecurrence(Recurrence.WEEKLY);
        event.setRepeatDays(java.util.EnumSet.of(java.time.DayOfWeek.MONDAY, java.time.DayOfWeek.FRIDAY));
        assertEquals("Weekly on Mon, Fri", Formats.repeatSummary(event));
        assertEquals("15 minutes before", Formats.reminder(15));
        assertEquals("1 hour before", Formats.reminder(60));
        assertEquals("1 day before", Formats.reminder(1440));
        assertEquals("At start time", Formats.reminder(0));
    }
}

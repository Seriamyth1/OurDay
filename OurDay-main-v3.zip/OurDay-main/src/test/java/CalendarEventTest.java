import org.junit.jupiter.api.Test;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.EnumSet;

import static org.junit.jupiter.api.Assertions.*;

class CalendarEventTest {
    private static final LocalDate FRI_NOV_13 = LocalDate.of(2026, 11, 13);

    @Test
    void oneTimeEventOnlyOccursOnItsDate() {
        CalendarEvent event = new CalendarEvent("Dentist", FRI_NOV_13);
        assertTrue(event.occursOn(FRI_NOV_13));
        assertFalse(event.occursOn(FRI_NOV_13.plusDays(1)));
        assertFalse(event.occursOn(FRI_NOV_13.minusDays(1)));
    }

    @Test
    void dailyEventRepeatsUntilEndDate() {
        CalendarEvent event = new CalendarEvent("Clean the house", FRI_NOV_13);
        event.setRecurrence(Recurrence.DAILY);
        event.setRepeatUntil(FRI_NOV_13.plusDays(3));
        assertFalse(event.occursOn(FRI_NOV_13.minusDays(1)));
        assertTrue(event.occursOn(FRI_NOV_13));
        assertTrue(event.occursOn(FRI_NOV_13.plusDays(3)));
        assertFalse(event.occursOn(FRI_NOV_13.plusDays(4)));
    }

    @Test
    void weeklyEventOnChosenDays() {
        // Joe picks the kids up Monday, Wednesday and Friday.
        CalendarEvent pickup = new CalendarEvent("School pickup", LocalDate.of(2026, 11, 9)); // a Monday
        pickup.setRecurrence(Recurrence.WEEKLY);
        pickup.setRepeatDays(EnumSet.of(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY));
        assertTrue(pickup.occursOn(LocalDate.of(2026, 11, 9)));
        assertFalse(pickup.occursOn(LocalDate.of(2026, 11, 10)));
        assertTrue(pickup.occursOn(LocalDate.of(2026, 11, 11)));
        assertTrue(pickup.occursOn(LocalDate.of(2026, 11, 13)));
        assertTrue(pickup.occursOn(LocalDate.of(2026, 12, 2)));
        assertFalse(pickup.occursOn(LocalDate.of(2026, 11, 14)));
    }

    @Test
    void weeklyEventWithoutChosenDaysUsesItsStartWeekday() {
        CalendarEvent event = new CalendarEvent("Groceries", LocalDate.of(2026, 11, 10)); // Tuesday
        event.setRecurrence(Recurrence.WEEKLY);
        assertEquals(EnumSet.of(DayOfWeek.TUESDAY), event.effectiveRepeatDays());
        assertTrue(event.occursOn(LocalDate.of(2026, 11, 17)));
        assertFalse(event.occursOn(LocalDate.of(2026, 11, 18)));
    }

    @Test
    void monthlyEventOnThe31stSkipsShortMonths() {
        CalendarEvent rent = new CalendarEvent("Rent", LocalDate.of(2026, 1, 31));
        rent.setRecurrence(Recurrence.MONTHLY);
        assertTrue(rent.occursOn(LocalDate.of(2026, 3, 31)));
        assertFalse(rent.occursOn(LocalDate.of(2026, 2, 28)));
        assertFalse(rent.occursOn(LocalDate.of(2026, 4, 30)));
    }

    @Test
    void yearlyEventOnLeapDayOnlyInLeapYears() {
        CalendarEvent birthday = new CalendarEvent("Birthday", LocalDate.of(2028, 2, 29));
        birthday.setRecurrence(Recurrence.YEARLY);
        assertFalse(birthday.occursOn(LocalDate.of(2029, 2, 28)));
        assertTrue(birthday.occursOn(LocalDate.of(2032, 2, 29)));
    }

    @Test
    void skippedDateHidesOneRepeat() {
        CalendarEvent event = new CalendarEvent("Office hours", FRI_NOV_13);
        event.setRecurrence(Recurrence.WEEKLY);
        event.skipDate(FRI_NOV_13.plusWeeks(1));
        assertTrue(event.occursOn(FRI_NOV_13));
        assertFalse(event.occursOn(FRI_NOV_13.plusWeeks(1)));
        assertTrue(event.occursOn(FRI_NOV_13.plusWeeks(2)));
    }

    @Test
    void invalidValuesAreRejected() {
        assertThrows(IllegalArgumentException.class, () -> new CalendarEvent("   ", FRI_NOV_13));
        CalendarEvent event = new CalendarEvent("Meeting", FRI_NOV_13);
        assertThrows(IllegalArgumentException.class,
            () -> event.setTimes(LocalTime.of(10, 0), LocalTime.of(9, 0)));
        assertThrows(IllegalArgumentException.class, () -> event.setTimes(null, LocalTime.of(9, 0)));
        assertThrows(IllegalArgumentException.class, () -> event.setRepeatUntil(FRI_NOV_13.minusDays(1)));
    }

    @Test
    void copyIsIndependentButKeepsId() {
        CalendarEvent event = new CalendarEvent("Meeting", FRI_NOV_13);
        event.setTimes(LocalTime.of(9, 0), LocalTime.of(10, 0));
        CalendarEvent copy = event.copy();
        copy.setTitle("Renamed");
        copy.skipDate(FRI_NOV_13);
        assertEquals("Meeting", event.getTitle());
        assertTrue(event.getSkippedDates().isEmpty());
        assertEquals(event.getId(), copy.getId());
        assertEquals(event, copy);
    }
}

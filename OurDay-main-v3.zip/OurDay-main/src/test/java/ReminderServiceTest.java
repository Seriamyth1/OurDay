import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ReminderServiceTest {
    private static final LocalDate DAY = LocalDate.of(2026, 11, 13);

    @TempDir
    Path dir;

    private final List<String> errors = new ArrayList<>();

    private EventManager emptyManager() {
        EventManager manager = new EventManager(dir.resolve("events.dat").toFile(), errors::add);
        manager.load();
        return manager;
    }

    private static CalendarEvent meetingAt9(int reminderMinutes) {
        CalendarEvent event = new CalendarEvent("Office hours", DAY);
        event.setTimes(LocalTime.of(9, 0), LocalTime.of(10, 0));
        event.setReminderMinutes(reminderMinutes);
        return event;
    }

    @Test
    void reminderFiresOnceAtTheRightTime() {
        EventManager manager = emptyManager();
        manager.add(meetingAt9(15));
        ReminderService reminders = new ReminderService(manager);

        assertTrue(reminders.collectDue(DAY.atTime(8, 44)).isEmpty(), "too early");
        assertEquals(1, reminders.collectDue(DAY.atTime(8, 45)).size());
        assertTrue(reminders.collectDue(DAY.atTime(8, 46)).isEmpty(), "only shown once");
    }

    @Test
    void eventsWithoutRemindersNeverFire() {
        EventManager manager = emptyManager();
        manager.add(meetingAt9(CalendarEvent.NO_REMINDER));
        assertTrue(new ReminderService(manager).collectDue(DAY.atTime(9, 0)).isEmpty());
    }

    @Test
    void lateReminderStillShowsBrieflyAfterStartButNotLongAfter() {
        Occurrence occurrence = new Occurrence(meetingAt9(15), DAY);
        assertTrue(ReminderService.isDue(occurrence, DAY.atTime(9, 5), null));
        assertFalse(ReminderService.isDue(occurrence,
            DAY.atTime(9, 0).plusMinutes(ReminderService.LATE_GRACE_MINUTES), null));
    }

    @Test
    void allDayRemindersCountFromNineAndLastAllDay() {
        CalendarEvent grading = new CalendarEvent("Grades due", DAY);
        grading.setReminderMinutes(0);
        Occurrence occurrence = new Occurrence(grading, DAY);
        assertEquals(DAY.atTime(9, 0), ReminderService.reminderTime(occurrence));
        assertFalse(ReminderService.isDue(occurrence, DAY.atTime(8, 59), null));
        assertTrue(ReminderService.isDue(occurrence, DAY.atTime(15, 0), null));
        assertFalse(ReminderService.isDue(occurrence, DAY.plusDays(1).atStartOfDay(), null));
    }

    @Test
    void oneDayBeforeReminderFiresTheDayBefore() {
        EventManager manager = emptyManager();
        manager.add(meetingAt9(1440));
        ReminderService reminders = new ReminderService(manager);
        List<Occurrence> due = reminders.collectDue(DAY.minusDays(1).atTime(9, 0));
        assertEquals(1, due.size());
        assertEquals(DAY, due.get(0).date());
    }

    @Test
    void snoozeShowsTheReminderAgainLater() {
        EventManager manager = emptyManager();
        manager.add(meetingAt9(10));
        ReminderService reminders = new ReminderService(manager);
        LocalDateTime shownAt = DAY.atTime(8, 50);
        Occurrence shown = reminders.collectDue(shownAt).get(0);

        reminders.snooze(shown, 5, shownAt);
        assertTrue(reminders.collectDue(DAY.atTime(8, 54)).isEmpty());
        assertEquals(1, reminders.collectDue(DAY.atTime(8, 55)).size());
        assertTrue(reminders.collectDue(DAY.atTime(8, 56)).isEmpty());
    }

    @Test
    void repeatingEventsRemindEveryTime() {
        EventManager manager = emptyManager();
        CalendarEvent daily = meetingAt9(5);
        daily.setRecurrence(Recurrence.DAILY);
        manager.add(daily);
        ReminderService reminders = new ReminderService(manager);
        assertEquals(1, reminders.collectDue(DAY.atTime(8, 55)).size());
        assertEquals(1, reminders.collectDue(DAY.plusDays(1).atTime(8, 55)).size());
    }

    @Test
    void timingDescriptionIsFriendly() {
        Occurrence occurrence = new Occurrence(meetingAt9(15), DAY);
        assertEquals("Starts in 15 min (Today at 9:00 AM)",
            ReminderService.describeTiming(occurrence, DAY.atTime(8, 45)));
        assertEquals("Tomorrow at 9:00 AM",
            ReminderService.describeTiming(occurrence, DAY.minusDays(1).atTime(9, 0)));
    }
}

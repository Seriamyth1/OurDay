/** How often an event repeats. */
public enum Recurrence {
    NONE("Does not repeat"),
    DAILY("Every day"),
    WEEKLY("Every week"),
    MONTHLY("Every month"),
    YEARLY("Every year");

    private final String label;

    Recurrence(String label) {
        this.label = label;
    }

    @Override
    public String toString() {
        return label;
    }
}

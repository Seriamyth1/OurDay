import javax.swing.*;
import java.awt.*;
import java.util.EnumMap;
import java.util.Map;
import java.util.function.Consumer;

/** Title with previous/next arrows, plus the Day / Week / Month switcher. */
public class CalendarHeader extends JPanel {
    private final JLabel titleLabel = new JLabel("", SwingConstants.CENTER);
    private final Map<ViewMode, JToggleButton> viewButtons = new EnumMap<>(ViewMode.class);

    public CalendarHeader(Runnable onPrevious, Runnable onNext, Consumer<ViewMode> onViewChanged) {
        super(new BorderLayout(12, 10));
        setOpaque(false);

        // Unicode escapes keep the source ASCII-only, so it compiles the same on any platform encoding.
        JButton previous = navigationButton("\u2039", "Previous");
        previous.addActionListener(e -> onPrevious.run());
        JButton next = navigationButton("\u203A", "Next");
        next.addActionListener(e -> onNext.run());

        titleLabel.setFont(ThemeManager.TITLE_FONT);
        titleLabel.setForeground(ThemeManager.TEXT);
        JPanel titleRow = new JPanel(new BorderLayout(12, 0));
        titleRow.setOpaque(false);
        titleRow.add(previous, BorderLayout.WEST);
        titleRow.add(titleLabel, BorderLayout.CENTER);
        titleRow.add(next, BorderLayout.EAST);
        add(titleRow, BorderLayout.CENTER);

        JPanel switcher = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        switcher.setOpaque(false);
        ButtonGroup group = new ButtonGroup();
        for (ViewMode mode : ViewMode.values()) {
            JToggleButton button = new JToggleButton(mode.label());
            button.setFocusPainted(false);
            button.setToolTipText(mode.label() + " view");
            button.addActionListener(e -> onViewChanged.accept(mode));
            group.add(button);
            switcher.add(button);
            viewButtons.put(mode, button);
        }
        add(switcher, BorderLayout.SOUTH);
    }

    public void setTitle(String title) {
        titleLabel.setText(title);
    }

    public void setView(ViewMode mode) {
        viewButtons.get(mode).setSelected(true);
    }

    private JButton navigationButton(String text, String tooltip) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.PLAIN, 28));
        button.setForeground(ThemeManager.ACCENT);
        button.setToolTipText(tooltip);
        button.setFocusPainted(false);
        return button;
    }
}

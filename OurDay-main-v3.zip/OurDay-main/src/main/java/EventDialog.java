import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

/** Lists one day's events and lets the user add, edit or delete them. */
public final class EventDialog {
    private EventDialog() {
    }

    public static void show(Component owner, LocalDate date, EventManager manager, Runnable onUpdated) {
        // getWindowAncestor() returns null when owner is itself the window (e.g. the
        // main JFrame), which would leave the dialog parentless.
        Window parent = owner instanceof Window ? (Window) owner : SwingUtilities.getWindowAncestor(owner);
        JDialog dialog = new JDialog(
            parent,
            "Events for " + Formats.fullDay(date),
            Dialog.ModalityType.APPLICATION_MODAL
        );
        dialog.setLayout(new BorderLayout(12, 12));
        dialog.getRootPane().setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        DefaultListModel<Occurrence> model = new DefaultListModel<>();
        reload(model, manager.getOccurrences(date));
        JList<Occurrence> eventList = new JList<>(model);
        eventList.setCellRenderer(new OccurrenceRenderer());
        eventList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        eventList.setVisibleRowCount(6);
        JScrollPane scroll = new JScrollPane(eventList);
        scroll.setPreferredSize(new Dimension(460, 280));
        dialog.add(scroll, BorderLayout.CENTER);

        JLabel empty = new JLabel("No events yet. Click Add to create one.");
        empty.setForeground(ThemeManager.MUTED_TEXT);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton add = new JButton("Add");
        JButton edit = new JButton("Edit");
        JButton remove = new JButton("Delete");
        JButton close = new JButton("Done");
        buttons.add(add);
        buttons.add(edit);
        buttons.add(remove);
        buttons.add(close);
        JPanel south = new JPanel(new BorderLayout());
        south.add(empty, BorderLayout.WEST);
        south.add(buttons, BorderLayout.EAST);
        dialog.add(south, BorderLayout.SOUTH);

        Runnable refresh = () -> {
            reload(model, manager.getOccurrences(date));
            empty.setVisible(model.isEmpty());
            onUpdated.run();
        };
        empty.setVisible(model.isEmpty());

        add.addActionListener(event -> {
            if (addEvent(dialog, manager, date, null)) {
                refresh.run();
            }
        });
        Runnable editSelected = () -> {
            Occurrence selected = eventList.getSelectedValue();
            if (selected == null) {
                showSelectionRequired(dialog);
            } else if (editEvent(dialog, manager, selected)) {
                refresh.run();
            }
        };
        edit.addActionListener(event -> editSelected.run());
        eventList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent event) {
                if (event.getClickCount() == 2 && eventList.getSelectedValue() != null) {
                    editSelected.run();
                }
            }
        });
        remove.addActionListener(event -> {
            Occurrence selected = eventList.getSelectedValue();
            if (selected == null) {
                showSelectionRequired(dialog);
            } else if (deleteOccurrence(dialog, manager, selected)) {
                refresh.run();
            }
        });
        close.addActionListener(event -> dialog.dispose());

        dialog.pack();
        dialog.setLocationRelativeTo(parent);
        dialog.setVisible(true);
    }

    // --- actions shared with the Day and Week views ---

    /** Opens the editor for a new event on {@code date}, optionally at {@code time}. Returns true if one was added. */
    public static boolean addEvent(Component owner, EventManager manager, LocalDate date, LocalTime time) {
        CalendarEvent draft = new CalendarEvent("New event", date);
        if (time != null) {
            draft.setTimes(time, time.plusHours(1).isAfter(time) ? time.plusHours(1) : null);
        }
        CalendarEvent created = EventEditorDialog.show(owner, draft, true, null, null);
        if (created == null) {
            return false;
        }
        manager.add(created);
        return true;
    }

    /** Opens the editor for an existing event (which can also delete it). Returns true if anything changed. */
    public static boolean editEvent(Component owner, EventManager manager, Occurrence occurrence) {
        CalendarEvent stored = manager.getEvent(occurrence.event().getId());
        if (stored == null) {
            return false;
        }
        boolean[] deleted = {false};
        CalendarEvent edited = EventEditorDialog.show(owner, stored.copy(), false,
            () -> deleted[0] = deleteOccurrence(owner, manager, new Occurrence(stored, occurrence.date())),
            occurrence.date());
        if (edited == null) {
            return deleted[0];
        }
        manager.update(edited);
        return true;
    }

    /**
     * Deletes an event after confirming. For repeating events the user chooses
     * between this day only and every repeat. Returns true if anything was deleted.
     */
    public static boolean deleteOccurrence(Component owner, EventManager manager, Occurrence occurrence) {
        CalendarEvent event = occurrence.event();
        if (event.isRepeating()) {
            Object[] options = {"Only this day", "All repeats", "Cancel"};
            int choice = JOptionPane.showOptionDialog(owner,
                "\"" + event.getTitle() + "\" repeats (" + Formats.repeatSummary(event) + ").\n"
                    + "Delete it only on " + Formats.shortDay(occurrence.date()) + ", or every time?",
                "Delete repeating event",
                JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
            if (choice == 0) {
                manager.removeOccurrence(event.getId(), occurrence.date());
                return true;
            }
            if (choice == 1) {
                manager.remove(event.getId());
                return true;
            }
            return false;
        }
        int choice = JOptionPane.showConfirmDialog(owner,
            "Delete \"" + event.getTitle() + "\"?", "Delete event",
            JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (choice == JOptionPane.OK_OPTION) {
            manager.remove(event.getId());
            return true;
        }
        return false;
    }

    private static void reload(DefaultListModel<Occurrence> model, List<Occurrence> occurrences) {
        model.clear();
        for (Occurrence occurrence : occurrences) {
            model.addElement(occurrence);
        }
    }

    private static void showSelectionRequired(Component parent) {
        JOptionPane.showMessageDialog(parent, "Select an event first.", "No Event Selected", JOptionPane.INFORMATION_MESSAGE);
    }

    /** Two-line list entry: time + title, then category, repeat and reminder details. */
    private static final class OccurrenceRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                      boolean isSelected, boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            CalendarEvent event = ((Occurrence) value).event();
            StringBuilder details = new StringBuilder(event.getCategory().label());
            if (event.isRepeating()) {
                details.append(" \u00B7 ").append(Formats.repeatSummary(event));
            }
            if (event.hasReminder()) {
                details.append(" \u00B7 Reminder ").append(Formats.reminder(event.getReminderMinutes()).toLowerCase());
            }
            setText("<html><b>" + html(Formats.timeRange(event)) + "</b>&nbsp;&nbsp;" + html(event.getTitle())
                + "<br><font color='#6a748c'>" + html(details.toString()) + "</font></html>");
            setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 4, 1, 0, event.getCategory().color()),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)));
            return this;
        }

        private static String html(String text) {
            return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
        }
    }
}

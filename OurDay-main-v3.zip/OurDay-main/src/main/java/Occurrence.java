import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Comparator;

/**
 * A single appearance of an event on a specific day. A one-time event has one
 * occurrence; a weekly event has one per matching week.
 */
public final class Occurrence {
    /** All-day events first, then by start time, then by title. */
    public static final Comparator<Occurrence> CHRONOLOGICAL = Comparator
        .comparing(Occurrence::date)
        .thenComparing(o -> !o.event().isAllDay())
        .thenComparing(o -> o.event().isAllDay() ? LocalTime.MIDNIGHT : o.event().getStartTime())
        .thenComparing(o -> o.event().getTitle(), String.CASE_INSENSITIVE_ORDER);

    private final CalendarEvent event;
    private final LocalDate date;

    public Occurrence(CalendarEvent event, LocalDate date) {
        this.event = event;
        this.date = date;
    }

    public CalendarEvent event() {
        return event;
    }

    public LocalDate date() {
        return date;
    }

    /** The moment reminders count back from: the start time, or 9:00 AM for all-day events. */
    public LocalDateTime referenceTime() {
        LocalTime time = event.isAllDay() ? CalendarEvent.ALL_DAY_REMINDER_TIME : event.getStartTime();
        return date.atTime(time);
    }

    /** Uniquely identifies this occurrence, e.g. for tracking which reminders were shown. */
    public String key() {
        return event.getId() + "@" + date;
    }

    @Override
    public boolean equals(Object other) {
        return other instanceof Occurrence
            && ((Occurrence) other).event.equals(event)
            && ((Occurrence) other).date.equals(date);
    }

    @Override
    public int hashCode() {
        return key().hashCode();
    }

    @Override
    public String toString() {
        return event.getTitle() + " on " + date;
    }
}

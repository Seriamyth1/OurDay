import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class CustomizableBackgroundPanel extends JPanel {

    public enum BackgroundMode { SOLID, GRADIENT, IMAGE }

    private BackgroundMode mode = BackgroundMode.SOLID;
    // The solid color or gradient drawn underneath an image, so lowering the
    // image opacity fades into the user's chosen background instead of gray.
    private BackgroundMode baseMode = BackgroundMode.SOLID;
    private Color solidColor = Color.WHITE;
    private Color gradientStart = Color.WHITE;
    private Color gradientEnd = Color.LIGHT_GRAY;
    private BufferedImage backgroundImage;
    private float imageOpacity = 1.0f; // 0.0 (invisible) - 1.0 (fully opaque)

    public CustomizableBackgroundPanel() {
        setOpaque(true); // every mode paints the full panel
    }

    // --- Setters used to customize the background at runtime ---

    public void setSolidColor(Color color) {
        this.solidColor = color;
        this.mode = BackgroundMode.SOLID;
        this.baseMode = BackgroundMode.SOLID;
        repaint();
    }

    public void setGradient(Color start, Color end) {
        this.gradientStart = start;
        this.gradientEnd = end;
        this.mode = BackgroundMode.GRADIENT;
        this.baseMode = BackgroundMode.GRADIENT;
        repaint();
    }

    /**
     * Loads an image to use as the background.
     *
     * @throws IOException if the file is missing, unreadable, or not a supported image.
     *                     The current background is left unchanged in that case.
     */
    public void setBackgroundImage(String imagePath) throws IOException {
        File file = new File(imagePath);
        if (!file.isFile()) {
            throw new IOException("Image file not found: " + file.getAbsolutePath());
        }
        BufferedImage image = ImageIO.read(file);
        if (image == null) {
            throw new IOException("Unsupported or unreadable image: " + file.getName());
        }
        this.backgroundImage = image;
        this.mode = BackgroundMode.IMAGE;
        repaint();
    }

    public void setImageOpacity(float opacity) {
        this.imageOpacity = Math.max(0f, Math.min(1f, opacity));
        repaint();
    }

    public BackgroundMode getMode() {
        return mode;
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g.create();
        int width = getWidth();
        int height = getHeight();

        BackgroundMode fill = mode == BackgroundMode.IMAGE ? baseMode : mode;
        if (fill == BackgroundMode.GRADIENT) {
            g2d.setPaint(new GradientPaint(0, 0, gradientStart, 0, height, gradientEnd));
        } else {
            g2d.setColor(solidColor);
        }
        g2d.fillRect(0, 0, width, height);

        if (mode == BackgroundMode.IMAGE && backgroundImage != null) {
            g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, imageOpacity));
            g2d.drawImage(backgroundImage, 0, 0, width, height, this);
        }

        g2d.dispose();
    }
}

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

/**
 * One calendar entry. An event can be all-day or have a start (and optional end)
 * time, belongs to a {@link Category}, can repeat, and can have a reminder.
 *
 * Named CalendarEvent (not Event) to avoid clashing with java.awt.Event.
 */
public final class CalendarEvent {
    /** Value of {@link #getReminderMinutes()} when no reminder is set. */
    public static final int NO_REMINDER = -1;
    /** All-day events have no start time, so their reminders are measured from this time of day. */
    public static final LocalTime ALL_DAY_REMINDER_TIME = LocalTime.of(9, 0);

    private final String id;
    private String title;
    private LocalDate date;
    private LocalTime startTime;
    private LocalTime endTime;
    private Category category = Category.OTHER;
    private Recurrence recurrence = Recurrence.NONE;
    private final EnumSet<DayOfWeek> repeatDays = EnumSet.noneOf(DayOfWeek.class);
    private LocalDate repeatUntil;
    private int reminderMinutes = NO_REMINDER;
    private final TreeSet<LocalDate> skippedDates = new TreeSet<>();

    public CalendarEvent(String title, LocalDate date) {
        this(UUID.randomUUID().toString(), title, date);
    }

    public CalendarEvent(String id, String title, LocalDate date) {
        this.id = Objects.requireNonNull(id, "id");
        setTitle(title);
        setDate(date);
    }

    /** A deep copy with the same id, so edits can be made and then saved or discarded. */
    public CalendarEvent copy() {
        CalendarEvent copy = new CalendarEvent(id, title, date);
        copy.startTime = startTime;
        copy.endTime = endTime;
        copy.category = category;
        copy.recurrence = recurrence;
        copy.repeatDays.addAll(repeatDays);
        copy.repeatUntil = repeatUntil;
        copy.reminderMinutes = reminderMinutes;
        copy.skippedDates.addAll(skippedDates);
        return copy;
    }

    /** True if this event happens on the given day, taking repeats and skipped days into account. */
    public boolean occursOn(LocalDate day) {
        if (day.isBefore(date) || skippedDates.contains(day)) {
            return false;
        }
        if (recurrence != Recurrence.NONE && repeatUntil != null && day.isAfter(repeatUntil)) {
            return false;
        }
        switch (recurrence) {
            case NONE:
                return day.equals(date);
            case DAILY:
                return true;
            case WEEKLY:
                return effectiveRepeatDays().contains(day.getDayOfWeek());
            case MONTHLY:
                // An event on the 31st only appears in months that have a 31st.
                return day.getDayOfMonth() == date.getDayOfMonth();
            case YEARLY:
                // An event on Feb 29 only appears in leap years.
                return day.getMonth() == date.getMonth() && day.getDayOfMonth() == date.getDayOfMonth();
            default:
                throw new IllegalStateException("Unknown recurrence " + recurrence);
        }
    }

    /** The weekdays a weekly event repeats on; defaults to the weekday of its first date. */
    public Set<DayOfWeek> effectiveRepeatDays() {
        return repeatDays.isEmpty() ? EnumSet.of(date.getDayOfWeek()) : EnumSet.copyOf(repeatDays);
    }

    public boolean isAllDay() {
        return startTime == null;
    }

    public boolean isRepeating() {
        return recurrence != Recurrence.NONE;
    }

    public boolean hasReminder() {
        return reminderMinutes >= 0;
    }

    // --- getters / setters ---

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        if (title == null || title.trim().isEmpty()) {
            throw new IllegalArgumentException("Event titles cannot be empty.");
        }
        this.title = title.trim();
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = Objects.requireNonNull(date, "date");
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public LocalTime getEndTime() {
        return endTime;
    }

    /**
     * Sets the time range. Pass a null start for an all-day event. The end time is
     * optional, but when given it must be after the start.
     */
    public void setTimes(LocalTime start, LocalTime end) {
        if (start == null && end != null) {
            throw new IllegalArgumentException("An all-day event cannot have an end time.");
        }
        if (start != null && end != null && !end.isAfter(start)) {
            throw new IllegalArgumentException("The end time must be after the start time.");
        }
        this.startTime = start;
        this.endTime = end;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category == null ? Category.OTHER : category;
    }

    public Recurrence getRecurrence() {
        return recurrence;
    }

    public void setRecurrence(Recurrence recurrence) {
        this.recurrence = recurrence == null ? Recurrence.NONE : recurrence;
    }

    public Set<DayOfWeek> getRepeatDays() {
        return Collections.unmodifiableSet(repeatDays);
    }

    public void setRepeatDays(Collection<DayOfWeek> days) {
        repeatDays.clear();
        if (days != null) {
            repeatDays.addAll(days);
        }
    }

    public LocalDate getRepeatUntil() {
        return repeatUntil;
    }

    public void setRepeatUntil(LocalDate repeatUntil) {
        if (repeatUntil != null && repeatUntil.isBefore(date)) {
            throw new IllegalArgumentException("A repeating event cannot end before it starts.");
        }
        this.repeatUntil = repeatUntil;
    }

    public int getReminderMinutes() {
        return reminderMinutes;
    }

    public void setReminderMinutes(int minutes) {
        this.reminderMinutes = minutes < 0 ? NO_REMINDER : minutes;
    }

    public SortedSet<LocalDate> getSkippedDates() {
        return Collections.unmodifiableSortedSet(skippedDates);
    }

    /** Hides a single day of a repeating event (e.g. no school pickup on a holiday). */
    public void skipDate(LocalDate day) {
        skippedDates.add(day);
    }

    public void setSkippedDates(Collection<LocalDate> days) {
        skippedDates.clear();
        if (days != null) {
            skippedDates.addAll(days);
        }
    }

    @Override
    public boolean equals(Object other) {
        return other instanceof CalendarEvent && ((CalendarEvent) other).id.equals(id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }

    @Override
    public String toString() {
        return title;
    }
}

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.function.Consumer;

/** A small colored label for one event, used by the month, week and day views. */
public class EventChip extends JLabel {
    /** COMPACT: one line (month). MEDIUM: start time + title (week). NORMAL: full time range + title (day). */
    public enum Size { COMPACT, MEDIUM, NORMAL }

    public EventChip(Occurrence occurrence, Size size, Consumer<Occurrence> onClick) {
        CalendarEvent event = occurrence.event();
        Color color = event.getCategory().color();
        boolean compact = size == Size.COMPACT;

        String time = event.isAllDay() ? "" : Formats.time(event.getStartTime());
        if (compact) {
            putClientProperty("html.disable", Boolean.TRUE);
            setText(time.isEmpty() ? event.getTitle() : time.replace(":00", "") + " " + event.getTitle());
        } else if (size == Size.MEDIUM) {
            String when = event.isAllDay() ? "All day" : time;
            setText("<html><b>" + escape(when) + "</b><br>" + escape(event.getTitle()) + "</html>");
        } else {
            setText("<html><b>" + escape(Formats.timeRange(event)) + "</b><br>" + escape(event.getTitle()) + "</html>");
        }
        setFont(new Font("SansSerif", Font.PLAIN, compact ? 11 : 12));
        setForeground(ThemeManager.TEXT);
        setBackground(new Color(color.getRed(), color.getGreen(), color.getBlue(), 42));
        setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 3, 0, 0, color),
            BorderFactory.createEmptyBorder(compact ? 3 : 5, 5, compact ? 3 : 5, 4)));
        setAlignmentX(LEFT_ALIGNMENT);
        setMaximumSize(new Dimension(Integer.MAX_VALUE, compact ? 24 : 60));

        StringBuilder tip = new StringBuilder("<html><b>" + escape(event.getTitle()) + "</b><br>"
            + escape(Formats.timeRange(event)) + " \u00B7 " + event.getCategory().label());
        if (event.isRepeating()) {
            tip.append("<br>").append(escape(Formats.repeatSummary(event)));
        }
        if (event.hasReminder()) {
            tip.append("<br>Reminder: ").append(Formats.reminder(event.getReminderMinutes()).toLowerCase());
        }
        setToolTipText(tip.append("</html>").toString());

        if (onClick != null) {
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    e.consume();
                    onClick.accept(occurrence);
                }
            });
        }
    }

    // A translucent background on an opaque label needs the parent painted first.
    @Override
    protected void paintComponent(Graphics g) {
        g.setColor(getBackground());
        g.fillRect(0, 0, getWidth(), getHeight());
        super.paintComponent(g);
    }

    @Override
    public boolean isOpaque() {
        return false;
    }

    private static String escape(String text) {
        return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}

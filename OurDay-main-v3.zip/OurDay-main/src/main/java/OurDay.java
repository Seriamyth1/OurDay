import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.IOException;
import java.time.*;

/** OurDay main window: sidebar on the left, the current view (day, week or month) on the right. */
public class OurDay {
    private static final int TICK_MS = 15_000; // how often reminders and the date are checked

    private JFrame frame;
    private CustomizableBackgroundPanel background;
    private CalendarHeader calendarHeader;
    private SidebarPanel sidebar;
    private JPanel viewContainer;
    private JComboBox<String> colorChoice;
    private JSlider opacity;

    private final EventManager eventManager = new EventManager(EventManager.defaultEventFile());
    private final ReminderService reminders = new ReminderService(eventManager);
    private AppSettings settings;
    private ViewMode viewMode = ViewMode.MONTH;
    private LocalDate focusDate = LocalDate.now();
    private LocalDate lastKnownToday = LocalDate.now();

    private static final String[] WEEKDAYS = {
        "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
    };

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new OurDay().createAndShowGUI());
    }

    private void createAndShowGUI() {
        settings = AppSettings.loadDefault();
        viewMode = settings.getView();
        eventManager.load();

        frame = new JFrame("OurDay");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setMinimumSize(new Dimension(980, 680));
        frame.setSize(1180, 800);
        frame.setLocationRelativeTo(null);

        background = new CustomizableBackgroundPanel();
        background.setGradient(ThemeManager.BACKGROUND_START, ThemeManager.BACKGROUND_END);
        background.setLayout(new BorderLayout(18, 14));
        background.setBorder(new EmptyBorder(18, 18, 18, 18));

        sidebar = new SidebarPanel(this::showToday, this::showCurrentMonth, this::showSelectedDate);
        background.add(sidebar, BorderLayout.WEST);
        background.add(createMainContent(), BorderLayout.CENTER);

        frame.setContentPane(background);
        applySavedBackground();
        frame.setVisible(true);
        refreshCalendar();
        startTicker();
    }

    private JPanel createMainContent() {
        JPanel content = new JPanel(new BorderLayout(12, 14));
        content.setOpaque(false);

        JPanel header = new JPanel(new BorderLayout(8, 8));
        header.setOpaque(false);
        calendarHeader = new CalendarHeader(() -> step(-1), () -> step(1), this::setView);
        header.add(calendarHeader, BorderLayout.CENTER);
        header.add(createCustomizationBar(), BorderLayout.SOUTH);
        content.add(header, BorderLayout.NORTH);

        viewContainer = new JPanel(new BorderLayout());
        viewContainer.setOpaque(false);
        content.add(viewContainer, BorderLayout.CENTER);
        return content;
    }

    // --- personalization ---

    private JPanel createCustomizationBar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 9, 6));
        bar.setOpaque(false);

        JLabel customize = new JLabel("Personalize");
        customize.setFont(ThemeManager.SUBTITLE_FONT);
        customize.setForeground(ThemeManager.TEXT);
        bar.add(customize);

        // "Gradient" is listed first so the dropdown matches the default background,
        // and so Reset (which selects index 0) restores it.
        colorChoice = new JComboBox<>(ThemeManager.PALETTE_NAMES);
        colorChoice.setToolTipText("Choose a gradient or solid background");
        colorChoice.addActionListener(e -> {
            String name = (String) colorChoice.getSelectedItem();
            applyPalette(name);
            settings.setPalette(name);
            settings.setImagePath(null); // picking a color replaces any image
            settings.save();
        });
        bar.add(colorChoice);

        JButton chooseImage = new JButton("Choose Image");
        chooseImage.addActionListener(e -> chooseBackgroundImage());
        bar.add(chooseImage);

        JLabel opacityLabel = new JLabel("Image opacity");
        opacityLabel.setForeground(ThemeManager.MUTED_TEXT);
        bar.add(opacityLabel);
        opacity = new JSlider(0, 100, 100);
        opacity.setPreferredSize(new Dimension(110, 30));
        opacity.setOpaque(false);
        opacity.setToolTipText("Adjust image transparency");
        opacity.addChangeListener(e -> {
            background.setImageOpacity(opacity.getValue() / 100f);
            if (!opacity.getValueIsAdjusting()) {
                settings.setOpacity(opacity.getValue());
                settings.save();
            }
        });
        bar.add(opacity);

        JButton reset = new JButton("Reset");
        reset.addActionListener(e -> {
            opacity.setValue(100);
            // Always fires the dropdown's listener, which applies the gradient and clears the image.
            colorChoice.setSelectedIndex(0);
        });
        bar.add(reset);
        return bar;
    }

    private void applyPalette(String name) {
        if (name == null) {
            return;
        }
        if (AppSettings.DEFAULT_PALETTE.equals(name)) {
            background.setGradient(ThemeManager.BACKGROUND_START, ThemeManager.BACKGROUND_END);
        } else {
            background.setSolidColor(ThemeManager.paletteColor(name));
        }
    }

    /** Restores last session's background. Anything that no longer works falls back to the default. */
    private void applySavedBackground() {
        String palette = settings.getPalette();
        String image = settings.getImagePath();
        int savedOpacity = settings.getOpacity();
        try {
            applyPalette(palette);
            selectWithoutSaving(palette);
        } catch (IllegalArgumentException unknownPalette) {
            applyPalette(AppSettings.DEFAULT_PALETTE);
        }
        opacity.setValue(savedOpacity);
        if (image != null) {
            try {
                background.setBackgroundImage(image);
            } catch (IOException missingImage) {
                System.err.println("OurDay: saved background image unavailable: " + missingImage.getMessage());
            }
        }
    }

    /** Sets the dropdown without triggering its listener (which would overwrite the saved image). */
    private void selectWithoutSaving(String palette) {
        java.awt.event.ActionListener[] listeners = colorChoice.getActionListeners();
        for (java.awt.event.ActionListener listener : listeners) {
            colorChoice.removeActionListener(listener);
        }
        colorChoice.setSelectedItem(palette);
        for (java.awt.event.ActionListener listener : listeners) {
            colorChoice.addActionListener(listener);
        }
    }

    private void chooseBackgroundImage() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Choose an OurDay background image");
        chooser.setFileFilter(new FileNameExtensionFilter("Image files", "png", "jpg", "jpeg", "gif", "bmp"));
        if (chooser.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION) {
            String path = chooser.getSelectedFile().getAbsolutePath();
            try {
                background.setBackgroundImage(path);
                settings.setImagePath(path);
                settings.save();
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(frame, ex.getMessage(), "Image Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // --- views and navigation ---

    private void refreshCalendar() {
        if (viewContainer == null) {
            return;
        }
        LocalDate today = LocalDate.now();
        lastKnownToday = today;

        JComponent view;
        switch (viewMode) {
            case DAY:
                calendarHeader.setTitle(Formats.fullDay(focusDate));
                view = new DayView(focusDate, eventManager, this::addEventAt, this::editOccurrence);
                break;
            case WEEK:
                calendarHeader.setTitle(Formats.weekRange(focusDate));
                view = new WeekView(focusDate, eventManager, date -> addEventAt(date, null), this::editOccurrence);
                break;
            default:
                calendarHeader.setTitle(Formats.monthYear(focusDate));
                view = createMonthView(YearMonth.from(focusDate), today);
        }
        calendarHeader.setView(viewMode);
        sidebar.setMonth(YearMonth.from(focusDate), focusDate, eventManager::hasEventsOn);

        viewContainer.removeAll();
        viewContainer.add(view, BorderLayout.CENTER);
        viewContainer.revalidate();
        viewContainer.repaint();
    }

    private JComponent createMonthView(YearMonth month, LocalDate today) {
        JPanel monthView = new JPanel(new BorderLayout(0, 10));
        monthView.setOpaque(false);

        JPanel weekdays = new JPanel(new GridLayout(1, 7, 9, 0));
        weekdays.setOpaque(false);
        for (String weekday : WEEKDAYS) {
            JLabel label = new JLabel(weekday, SwingConstants.CENTER);
            label.setFont(ThemeManager.SUBTITLE_FONT);
            label.setForeground(ThemeManager.MUTED_TEXT);
            weekdays.add(label);
        }
        monthView.add(weekdays, BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridLayout(6, 7, 9, 9));
        grid.setOpaque(false);
        int offset = month.atDay(1).getDayOfWeek().getValue() % 7;
        for (int cell = 0; cell < 42; cell++) {
            int dayNumber = cell - offset + 1;
            if (dayNumber < 1 || dayNumber > month.lengthOfMonth()) {
                JPanel blank = new JPanel();
                blank.setOpaque(false);
                grid.add(blank);
                continue;
            }
            LocalDate date = month.atDay(dayNumber);
            grid.add(new CalendarDayPanel(date, eventManager.getOccurrences(date), date.equals(today),
                this::manageEventsForDate));
        }
        monthView.add(grid, BorderLayout.CENTER);
        return monthView;
    }

    private void step(int direction) {
        focusDate = viewMode.step(focusDate, direction);
        refreshCalendar();
    }

    private void setView(ViewMode mode) {
        viewMode = mode;
        settings.setView(mode);
        settings.save();
        refreshCalendar();
    }

    private void manageEventsForDate(LocalDate date) {
        EventDialog.show(frame, date, eventManager, this::refreshCalendar);
    }

    private void addEventAt(LocalDate date, LocalTime time) {
        if (EventDialog.addEvent(frame, eventManager, date, time)) {
            refreshCalendar();
        }
    }

    private void editOccurrence(Occurrence occurrence) {
        if (EventDialog.editEvent(frame, eventManager, occurrence)) {
            refreshCalendar();
        }
    }

    private void showToday() {
        focusDate = LocalDate.now();
        refreshCalendar();
    }

    private void showCurrentMonth() {
        focusDate = LocalDate.now();
        setView(ViewMode.MONTH);
    }

    /** Clicking a date in the mini calendar opens that day in Day view. */
    private void showSelectedDate(LocalDate date) {
        focusDate = date;
        setView(ViewMode.DAY);
    }

    // --- reminders and the date changing at midnight ---

    private void startTicker() {
        Timer timer = new Timer(TICK_MS, e -> tick());
        timer.setInitialDelay(1500); // show reminders that are already due shortly after launch
        timer.start();
    }

    private void tick() {
        LocalDate now = LocalDate.now();
        if (!now.equals(lastKnownToday)) {
            // Keep the "today" highlight correct when the app stays open past midnight.
            if (focusDate.equals(lastKnownToday)) {
                focusDate = now;
            }
            refreshCalendar();
        }
        for (Occurrence due : reminders.collectDue(LocalDateTime.now())) {
            ReminderPopup.show(due,
                minutes -> reminders.snooze(due, minutes, LocalDateTime.now()),
                () -> openFromReminder(due.date()));
        }
    }

    private void openFromReminder(LocalDate date) {
        focusDate = date;
        setView(ViewMode.DAY);
        frame.setState(Frame.NORMAL);
        frame.toFront();
        frame.requestFocus();
    }
}

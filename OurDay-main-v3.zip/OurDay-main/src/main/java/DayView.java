import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

/**
 * A single day as an hour-by-hour timeline. All-day events sit at the top.
 * Click an hour to add an event at that time, or click an event to edit it.
 */
public class DayView extends JPanel {
    private static final int ROW_HEIGHT = 52;
    private final JScrollPane scroll;

    public DayView(LocalDate date, EventManager manager,
                   BiConsumer<LocalDate, LocalTime> onAddAt, Consumer<Occurrence> onEdit) {
        super(new BorderLayout(0, 10));
        setOpaque(false);

        List<Occurrence> occurrences = manager.getOccurrences(date);
        List<Occurrence> allDay = new ArrayList<>();
        List<List<Occurrence>> byHour = new ArrayList<>();
        for (int hour = 0; hour < 24; hour++) {
            byHour.add(new ArrayList<>());
        }
        for (Occurrence occurrence : occurrences) {
            if (occurrence.event().isAllDay()) {
                allDay.add(occurrence);
            } else {
                byHour.get(occurrence.event().getStartTime().getHour()).add(occurrence);
            }
        }

        // All-day strip
        JPanel allDayRow = new RoundedPanel(new BorderLayout(10, 0));
        allDayRow.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        JLabel allDayLabel = new JLabel("All day");
        allDayLabel.setFont(ThemeManager.SUBTITLE_FONT);
        allDayLabel.setForeground(ThemeManager.MUTED_TEXT);
        allDayLabel.setPreferredSize(new Dimension(64, 20));
        allDayRow.add(allDayLabel, BorderLayout.WEST);
        JPanel allDayChips = chipRow(allDay, onEdit);
        if (allDay.isEmpty()) {
            JLabel none = new JLabel(occurrences.isEmpty()
                ? "Nothing planned. Click an hour below to add an event."
                : "No all-day events");
            none.setFont(new Font("SansSerif", Font.ITALIC, 12));
            none.setForeground(ThemeManager.MUTED_TEXT);
            allDayChips.add(none);
        }
        allDayRow.add(allDayChips, BorderLayout.CENTER);
        allDayRow.setToolTipText("Click to add an all-day event");
        allDayRow.addMouseListener(clickToAdd(() -> onAddAt.accept(date, null)));
        add(allDayRow, BorderLayout.NORTH);

        // Hour rows
        JPanel hours = new JPanel(new GridLayout(24, 1, 0, 0));
        hours.setOpaque(false);
        boolean isToday = date.equals(LocalDate.now());
        int currentHour = LocalTime.now().getHour();
        for (int hour = 0; hour < 24; hour++) {
            hours.add(hourRow(date, hour, byHour.get(hour), isToday && hour == currentHour, onAddAt, onEdit));
        }
        RoundedPanel timeline = new RoundedPanel(new BorderLayout());
        timeline.add(hours, BorderLayout.CENTER);

        scroll = new JScrollPane(timeline);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(ROW_HEIGHT / 2);
        add(scroll, BorderLayout.CENTER);

        // Start scrolled to the current hour today, or to the first event (or 7 AM) on other days.
        int firstHour = 7;
        for (int hour = 0; hour < 24; hour++) {
            if (!byHour.get(hour).isEmpty()) {
                firstHour = Math.min(hour, firstHour);
                break;
            }
        }
        int target = isToday ? Math.max(0, currentHour - 1) : firstHour;
        // Scrolling must wait until the viewport has been laid out; doing it earlier
        // gets clamped to whatever (smaller) size the viewport had at that moment.
        scroll.getViewport().addComponentListener(new java.awt.event.ComponentAdapter() {
            private boolean done;

            @Override
            public void componentResized(java.awt.event.ComponentEvent e) {
                JViewport viewport = scroll.getViewport();
                if (done || viewport.getHeight() == 0) {
                    return;
                }
                done = true;
                int max = Math.max(0, timeline.getPreferredSize().height - viewport.getHeight());
                viewport.setViewPosition(new Point(0, Math.min(target * ROW_HEIGHT, max)));
            }
        });
    }

    private JPanel hourRow(LocalDate date, int hour, List<Occurrence> events, boolean now,
                           BiConsumer<LocalDate, LocalTime> onAddAt, Consumer<Occurrence> onEdit) {
        JPanel row = new JPanel(new BorderLayout(10, 0)) {
            @Override
            protected void paintComponent(Graphics g) {
                if (now) {
                    g.setColor(new Color(ThemeManager.ACCENT.getRed(), ThemeManager.ACCENT.getGreen(),
                        ThemeManager.ACCENT.getBlue(), 28));
                    g.fillRect(0, 0, getWidth(), getHeight());
                }
                g.setColor(new Color(227, 230, 240));
                g.drawLine(76, 0, getWidth() - 12, 0);
            }
        };
        row.setOpaque(false);
        row.setPreferredSize(new Dimension(10, ROW_HEIGHT));
        row.setBorder(BorderFactory.createEmptyBorder(4, 12, 4, 12));

        JLabel label = new JLabel(Formats.hour(hour));
        label.setFont(ThemeManager.BODY_FONT);
        label.setForeground(now ? ThemeManager.ACCENT : ThemeManager.MUTED_TEXT);
        label.setPreferredSize(new Dimension(64, 20));
        label.setVerticalAlignment(SwingConstants.TOP);
        row.add(label, BorderLayout.WEST);
        row.add(chipRow(events, onEdit), BorderLayout.CENTER);

        row.setToolTipText("Click to add an event at " + Formats.hour(hour));
        row.addMouseListener(clickToAdd(() -> onAddAt.accept(date, LocalTime.of(hour, 0))));
        return row;
    }

    private static JPanel chipRow(List<Occurrence> events, Consumer<Occurrence> onEdit) {
        JPanel chips = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        chips.setOpaque(false);
        for (Occurrence occurrence : events) {
            EventChip chip = new EventChip(occurrence, EventChip.Size.NORMAL, onEdit);
            chip.setPreferredSize(new Dimension(Math.max(170, chip.getPreferredSize().width), chip.getPreferredSize().height));
            chips.add(chip);
        }
        return chips;
    }

    private static MouseAdapter clickToAdd(Runnable action) {
        return new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                action.run();
            }
        };
    }

    /** Translucent white card matching the month cells. */
    private static class RoundedPanel extends JPanel {
        RoundedPanel(LayoutManager layout) {
            super(layout);
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics graphics) {
            Graphics2D g2 = (Graphics2D) graphics.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(ThemeManager.CELL);
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 18, 18);
            g2.setColor(new Color(227, 230, 240));
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 18, 18);
            g2.dispose();
        }
    }
}

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Properties;

/**
 * Remembers the user's choices between launches (background, opacity, last view)
 * in ~/.ourday/settings.properties.
 */
public class AppSettings {
    public static final String DEFAULT_PALETTE = "Gradient";

    private static final String PALETTE = "background.palette";
    private static final String IMAGE = "background.image";
    private static final String OPACITY = "background.opacity";
    private static final String VIEW = "view";

    private final File file;
    private final Properties values = new Properties();

    public AppSettings(File file) {
        this.file = file;
    }

    /** The folder OurDay keeps its files in: ~/.ourday */
    public static File dataDirectory() {
        return new File(System.getProperty("user.home"), ".ourday");
    }

    public static AppSettings loadDefault() {
        AppSettings settings = new AppSettings(new File(dataDirectory(), "settings.properties"));
        settings.load();
        return settings;
    }

    /** Missing or unreadable settings just fall back to the defaults. */
    public void load() {
        values.clear();
        if (!file.isFile()) {
            return;
        }
        try (Reader reader = Files.newBufferedReader(file.toPath(), StandardCharsets.UTF_8)) {
            values.load(reader);
        } catch (IOException | IllegalArgumentException ex) {
            values.clear();
            System.err.println("OurDay: ignoring unreadable settings file: " + ex.getMessage());
        }
    }

    public void save() {
        try {
            Files.createDirectories(file.getAbsoluteFile().getParentFile().toPath());
            try (Writer writer = Files.newBufferedWriter(file.toPath(), StandardCharsets.UTF_8)) {
                values.store(writer, "OurDay settings");
            }
        } catch (IOException ex) {
            // Settings are a convenience; failing to save them should never interrupt the user.
            System.err.println("OurDay: could not save settings: " + ex.getMessage());
        }
    }

    /** "Gradient" or one of the solid colors offered in the Personalize menu. */
    public String getPalette() {
        return values.getProperty(PALETTE, DEFAULT_PALETTE);
    }

    public void setPalette(String palette) {
        values.setProperty(PALETTE, palette);
    }

    /** Path of the background image, or null when no image is used. */
    public String getImagePath() {
        String path = values.getProperty(IMAGE, "");
        return path.isEmpty() ? null : path;
    }

    public void setImagePath(String path) {
        values.setProperty(IMAGE, path == null ? "" : path);
    }

    /** Image opacity from 0 to 100. */
    public int getOpacity() {
        try {
            return Math.max(0, Math.min(100, Integer.parseInt(values.getProperty(OPACITY, "100"))));
        } catch (NumberFormatException ex) {
            return 100;
        }
    }

    public void setOpacity(int opacity) {
        values.setProperty(OPACITY, Integer.toString(Math.max(0, Math.min(100, opacity))));
    }

    public ViewMode getView() {
        try {
            return ViewMode.valueOf(values.getProperty(VIEW, ViewMode.MONTH.name()));
        } catch (IllegalArgumentException ex) {
            return ViewMode.MONTH;
        }
    }

    public void setView(ViewMode view) {
        values.setProperty(VIEW, view.name());
    }
}

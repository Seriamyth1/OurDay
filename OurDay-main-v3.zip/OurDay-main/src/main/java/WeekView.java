import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

/**
 * Seven columns (Sunday to Saturday), each listing that day's events in time order.
 * Click an event to edit it, or click empty space in a column to add one.
 */
public class WeekView extends JPanel {

    public WeekView(LocalDate anyDayInWeek, EventManager manager,
                    Consumer<LocalDate> onAddForDay, Consumer<Occurrence> onEdit) {
        super(new GridLayout(1, 7, 9, 0));
        setOpaque(false);
        LocalDate start = Formats.startOfWeek(anyDayInWeek);
        LocalDate today = LocalDate.now();
        for (int i = 0; i < 7; i++) {
            LocalDate day = start.plusDays(i);
            add(new DayColumn(day, day.equals(today), manager.getOccurrences(day), onAddForDay, onEdit));
        }
    }

    private static final class DayColumn extends JPanel {
        private final boolean today;

        DayColumn(LocalDate day, boolean today, List<Occurrence> occurrences,
                  Consumer<LocalDate> onAdd, Consumer<Occurrence> onEdit) {
            super(new BorderLayout(0, 8));
            this.today = today;
            setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(10, 8, 10, 8));

            JLabel heading = new JLabel(
                "<html><center>" + day.getDayOfWeek().getDisplayName(TextStyle.SHORT, Locale.US)
                    + "<br><font size='+2'>" + day.getDayOfMonth() + "</font></center></html>",
                SwingConstants.CENTER);
            heading.setFont(ThemeManager.SUBTITLE_FONT);
            heading.setForeground(today ? ThemeManager.ACCENT : ThemeManager.TEXT);
            add(heading, BorderLayout.NORTH);

            JPanel list = new JPanel();
            list.setOpaque(false);
            list.setLayout(new BoxLayout(list, BoxLayout.Y_AXIS));
            for (Occurrence occurrence : occurrences) {
                list.add(new EventChip(occurrence, EventChip.Size.MEDIUM, onEdit));
                list.add(Box.createVerticalStrut(6));
            }
            JLabel addHint = new JLabel("+ Add");
            addHint.setFont(new Font("SansSerif", Font.PLAIN, 11));
            addHint.setForeground(ThemeManager.MUTED_TEXT);
            addHint.setAlignmentX(LEFT_ALIGNMENT);
            list.add(addHint);

            // Keeps chips at the top instead of stretching to fill the column.
            JPanel holder = new JPanel(new BorderLayout());
            holder.setOpaque(false);
            holder.add(list, BorderLayout.NORTH);
            JScrollPane scroll = new JScrollPane(holder,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
            scroll.setOpaque(false);
            scroll.getViewport().setOpaque(false);
            scroll.setBorder(null);
            scroll.getVerticalScrollBar().setUnitIncrement(16);
            add(scroll, BorderLayout.CENTER);

            MouseAdapter addOnClick = new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (!e.isConsumed()) {
                        onAdd.accept(day);
                    }
                }
            };
            for (Component c : new Component[]{this, heading, holder, list, addHint, scroll.getViewport()}) {
                c.addMouseListener(addOnClick);
            }
            setToolTipText("Click empty space to add an event on " + Formats.shortDay(day));
        }

        @Override
        protected void paintComponent(Graphics graphics) {
            Graphics2D g2 = (Graphics2D) graphics.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(ThemeManager.CELL);
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 18, 18);
            g2.setColor(today ? ThemeManager.ACCENT : new Color(227, 230, 240));
            g2.setStroke(new BasicStroke(today ? 2f : 1f));
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 18, 18);
            g2.dispose();
        }
    }
}

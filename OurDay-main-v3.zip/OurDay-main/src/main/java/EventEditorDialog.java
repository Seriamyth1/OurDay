import javax.swing.*;
import java.awt.*;
import java.time.*;
import java.time.format.TextStyle;
import java.util.*;
import java.util.List;

/**
 * The form for creating or editing an event: title, date, time, category,
 * repeat settings and reminder.
 */
public final class EventEditorDialog {
    /** Reminder choices offered in the form, in minutes before the event. */
    static final int[] REMINDER_CHOICES = {CalendarEvent.NO_REMINDER, 0, 5, 10, 15, 30, 60, 120, 1440};

    private final JDialog dialog;
    private final CalendarEvent original;
    private CalendarEvent result;

    private final JTextField title = new JTextField(24);
    private final JSpinner date = dateSpinner();
    private final JCheckBox allDay = new JCheckBox("All day");
    private final JSpinner start = timeSpinner();
    private final JSpinner end = timeSpinner();
    private final JCheckBox hasEnd = new JCheckBox("Ends at");
    private final JComboBox<Category> category = new JComboBox<>(Category.values());
    private final JComboBox<Recurrence> repeat = new JComboBox<>(Recurrence.values());
    private final Map<DayOfWeek, JCheckBox> dayBoxes = new EnumMap<>(DayOfWeek.class);
    private final JCheckBox hasUntil = new JCheckBox("Ends on");
    private final JSpinner until = dateSpinner();
    private final JComboBox<String> reminder = new JComboBox<>();
    private final JLabel reminderHint = hint("");
    private JPanel daysRow;
    private JLabel daysLabel;
    private JLabel dateLabel;
    private JPanel untilRow;

    /**
     * Opens the form and waits for the user.
     *
     * @param event the event to edit, or a new event with defaults filled in
     * @param isNew whether this is a brand-new event (changes the title and button text)
     * @param onDelete if not null, a Delete button is shown; it closes the form and runs this
     * @param openedOn for a repeating event, the day the user clicked (shown so the series
     *                 start date isn't confusing); may be null
     * @return the edited copy, or null if the user cancelled or chose Delete
     */
    public static CalendarEvent show(Component owner, CalendarEvent event, boolean isNew,
                                     Runnable onDelete, LocalDate openedOn) {
        EventEditorDialog editor = new EventEditorDialog(owner, event, isNew, onDelete, openedOn);
        editor.dialog.setVisible(true);
        return editor.result;
    }

    private EventEditorDialog(Component owner, CalendarEvent event, boolean isNew,
                              Runnable onDelete, LocalDate openedOn) {
        this.original = event;
        Window parent = owner instanceof Window ? (Window) owner : SwingUtilities.getWindowAncestor(owner);
        dialog = new JDialog(parent, isNew ? "New event" : "Edit event", Dialog.ModalityType.APPLICATION_MODAL);
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createEmptyBorder(16, 16, 8, 16));
        int row = 0;
        addRow(form, row++, "Title", title);
        dateLabel = addRow(form, row++, "Date", date);
        addRow(form, row++, "Time", flow(allDay, label("Starts"), start, hasEnd, end));
        addRow(form, row++, "Category", category);
        addRow(form, row++, "Repeat", repeat);

        daysRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 0));
        for (DayOfWeek day : weekOrder()) {
            JCheckBox box = new JCheckBox(day.getDisplayName(TextStyle.SHORT, Locale.US));
            dayBoxes.put(day, box);
            daysRow.add(box);
        }
        daysLabel = addRow(form, row++, "On", daysRow);
        untilRow = flow(hasUntil, until);
        addRow(form, row++, "", untilRow);

        for (int minutes : REMINDER_CHOICES) {
            reminder.addItem(Formats.reminder(minutes));
        }
        addRow(form, row++, "Reminder", flow(reminder, reminderHint));

        if (event.isRepeating() && !isNew) {
            String opened = openedOn != null && !openedOn.equals(event.getDate())
                ? "You opened the " + Formats.shortDay(openedOn) + " repeat. " : "";
            JLabel note = hint(opened + "Changes apply to every repeat of this event.");
            addRow(form, row, "", note);
        }

        JButton save = new JButton(isNew ? "Add event" : "Save");
        JButton cancel = new JButton("Cancel");
        save.addActionListener(e -> trySave());
        cancel.addActionListener(e -> dialog.dispose());
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttons.add(cancel);
        buttons.add(save);
        JPanel buttonRow = new JPanel(new BorderLayout());
        buttonRow.setBorder(BorderFactory.createEmptyBorder(0, 12, 8, 12));
        buttonRow.add(buttons, BorderLayout.EAST);
        if (onDelete != null) {
            JButton delete = new JButton("Delete\u2026");
            delete.setForeground(new Color(180, 60, 60));
            delete.addActionListener(e -> {
                dialog.dispose();
                onDelete.run();
            });
            JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT));
            left.add(delete);
            buttonRow.add(left, BorderLayout.WEST);
        }
        dialog.getRootPane().setDefaultButton(save);
        dialog.getRootPane().registerKeyboardAction(e -> dialog.dispose(),
            KeyStroke.getKeyStroke("ESCAPE"), JComponent.WHEN_IN_FOCUSED_WINDOW);

        dialog.setLayout(new BorderLayout());
        dialog.add(form, BorderLayout.CENTER);
        dialog.add(buttonRow, BorderLayout.SOUTH);

        fillFrom(event);
        allDay.addActionListener(e -> updateEnabledState());
        hasEnd.addActionListener(e -> updateEnabledState());
        hasUntil.addActionListener(e -> updateEnabledState());
        repeat.addActionListener(e -> updateEnabledState());
        date.addChangeListener(e -> {
            // Keep the default weekly day in step with the chosen date until the user picks days.
            if (selectedDays().size() <= 1) {
                dayBoxes.values().forEach(box -> box.setSelected(false));
                dayBoxes.get(toLocalDate(date).getDayOfWeek()).setSelected(true);
            }
        });
        updateEnabledState();

        dialog.pack();
        dialog.setResizable(false);
        dialog.setLocationRelativeTo(parent);
        SwingUtilities.invokeLater(title::requestFocusInWindow);
    }

    private void fillFrom(CalendarEvent event) {
        title.setText(event.getTitle());
        setLocalDate(date, event.getDate());
        allDay.setSelected(event.isAllDay());
        LocalTime startTime = event.isAllDay() ? LocalTime.of(9, 0) : event.getStartTime();
        setLocalTime(start, startTime);
        hasEnd.setSelected(event.getEndTime() != null || event.isAllDay());
        setLocalTime(end, event.getEndTime() != null ? event.getEndTime() : startTime.plusHours(1));
        category.setSelectedItem(event.getCategory());
        repeat.setSelectedItem(event.getRecurrence());
        Set<DayOfWeek> days = event.effectiveRepeatDays();
        dayBoxes.forEach((day, box) -> box.setSelected(days.contains(day)));
        hasUntil.setSelected(event.getRepeatUntil() != null);
        setLocalDate(until, event.getRepeatUntil() != null ? event.getRepeatUntil() : event.getDate().plusMonths(3));
        int index = 0;
        for (int i = 0; i < REMINDER_CHOICES.length; i++) {
            if (REMINDER_CHOICES[i] == event.getReminderMinutes()) {
                index = i;
            }
        }
        reminder.setSelectedIndex(index);
    }

    private void updateEnabledState() {
        boolean timed = !allDay.isSelected();
        start.setEnabled(timed);
        hasEnd.setEnabled(timed);
        end.setEnabled(timed && hasEnd.isSelected());
        Recurrence recurrence = (Recurrence) repeat.getSelectedItem();
        daysRow.setVisible(recurrence == Recurrence.WEEKLY);
        daysLabel.setVisible(recurrence == Recurrence.WEEKLY);
        // For a repeating event the date is when the series begins, so say so.
        dateLabel.setText(recurrence == Recurrence.NONE ? "Date" : "Starts on");
        untilRow.setVisible(recurrence != Recurrence.NONE);
        until.setEnabled(hasUntil.isSelected());
        reminderHint.setText(timed ? "" : "(all-day reminders count from 9:00 AM)");
        dialog.pack();
    }

    private void trySave() {
        CalendarEvent edited = original.copy();
        try {
            edited.setTitle(title.getText());
            edited.setDate(toLocalDate(date));
            if (allDay.isSelected()) {
                edited.setTimes(null, null);
            } else {
                edited.setTimes(toLocalTime(start), hasEnd.isSelected() ? toLocalTime(end) : null);
            }
            edited.setCategory((Category) category.getSelectedItem());
            Recurrence recurrence = (Recurrence) repeat.getSelectedItem();
            edited.setRecurrence(recurrence);
            if (recurrence == Recurrence.WEEKLY) {
                Set<DayOfWeek> days = selectedDays();
                if (days.isEmpty()) {
                    throw new IllegalArgumentException("Pick at least one day for a weekly event.");
                }
                edited.setRepeatDays(days);
            } else {
                edited.setRepeatDays(null);
            }
            edited.setRepeatUntil(recurrence != Recurrence.NONE && hasUntil.isSelected() ? toLocalDate(until) : null);
            if (recurrence == Recurrence.NONE) {
                edited.setSkippedDates(null);
            }
            edited.setReminderMinutes(REMINDER_CHOICES[reminder.getSelectedIndex()]);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(dialog, ex.getMessage(), "Check the event", JOptionPane.WARNING_MESSAGE);
            return;
        }
        result = edited;
        dialog.dispose();
    }

    private Set<DayOfWeek> selectedDays() {
        Set<DayOfWeek> days = EnumSet.noneOf(DayOfWeek.class);
        dayBoxes.forEach((day, box) -> {
            if (box.isSelected()) {
                days.add(day);
            }
        });
        return days;
    }

    // --- layout helpers ---

    private static List<DayOfWeek> weekOrder() {
        List<DayOfWeek> days = new ArrayList<>();
        days.add(DayOfWeek.SUNDAY);
        for (int i = 1; i <= 6; i++) {
            days.add(DayOfWeek.of(i));
        }
        return days;
    }

    private static JLabel addRow(JPanel form, int row, String labelText, JComponent field) {
        GridBagConstraints c = new GridBagConstraints();
        c.gridy = row;
        c.insets = new Insets(4, 4, 4, 4);
        c.anchor = GridBagConstraints.WEST;
        JLabel rowLabel = label(labelText);
        form.add(rowLabel, c);
        c.gridx = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;
        form.add(field, c);
        return rowLabel;
    }

    private static JLabel label(String text) {
        JLabel label = new JLabel(text);
        label.setFont(ThemeManager.SUBTITLE_FONT);
        label.setForeground(ThemeManager.TEXT);
        return label;
    }

    private static JLabel hint(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("SansSerif", Font.ITALIC, 11));
        label.setForeground(ThemeManager.MUTED_TEXT);
        return label;
    }

    private static JPanel flow(JComponent... components) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        for (JComponent component : components) {
            panel.add(component);
        }
        return panel;
    }

    // --- spinner <-> java.time conversion (Swing spinners still use java.util.Date) ---

    private static JSpinner dateSpinner() {
        JSpinner spinner = new JSpinner(new SpinnerDateModel());
        spinner.setEditor(new JSpinner.DateEditor(spinner, "EEE, MMM d, yyyy"));
        return spinner;
    }

    private static JSpinner timeSpinner() {
        SpinnerDateModel model = new SpinnerDateModel();
        model.setCalendarField(Calendar.MINUTE);
        JSpinner spinner = new JSpinner(model);
        spinner.setEditor(new JSpinner.DateEditor(spinner, "h:mm a"));
        return spinner;
    }

    private static LocalDate toLocalDate(JSpinner spinner) {
        return ((Date) spinner.getValue()).toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }

    private static void setLocalDate(JSpinner spinner, LocalDate value) {
        spinner.setValue(Date.from(value.atTime(12, 0).atZone(ZoneId.systemDefault()).toInstant()));
    }

    private static LocalTime toLocalTime(JSpinner spinner) {
        return ((Date) spinner.getValue()).toInstant().atZone(ZoneId.systemDefault())
            .toLocalTime().withSecond(0).withNano(0);
    }

    private static void setLocalTime(JSpinner spinner, LocalTime value) {
        spinner.setValue(Date.from(LocalDate.of(2000, 1, 1).atTime(value).atZone(ZoneId.systemDefault()).toInstant()));
    }
}

import javax.swing.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Consumer;

/** Holds all events in memory and keeps them saved to disk. */
public class EventManager {
    private static final String FILE_NAME = "ourday-events.dat";

    private final File eventFile;
    private final Consumer<String> errorReporter;
    private final Map<String, CalendarEvent> events = new LinkedHashMap<>();

    /** Uses pop-up dialogs to report load/save problems. */
    public EventManager(File eventFile) {
        this(eventFile, EventManager::showErrorDialog);
    }

    /** @param errorReporter receives a user-readable message whenever loading or saving fails. */
    public EventManager(File eventFile, Consumer<String> errorReporter) {
        this.eventFile = eventFile;
        this.errorReporter = errorReporter;
    }

    /**
     * The standard place to keep events: ~/.ourday/ourday-events.dat. Using the
     * home folder means events are found no matter which folder the app is
     * launched from. If an older copy exists in the launch folder (where earlier
     * versions saved it) and there is no file in the new location yet, it is
     * copied over so nobody loses their events.
     */
    public static File defaultEventFile() {
        File dir = AppSettings.dataDirectory();
        File file = new File(dir, FILE_NAME);
        File legacy = new File(FILE_NAME);
        try {
            Files.createDirectories(dir.toPath());
            if (!file.exists() && legacy.isFile()) {
                Files.copy(legacy.toPath(), file.toPath());
            }
        } catch (IOException ex) {
            System.err.println("OurDay: could not prepare " + dir + ": " + ex.getMessage());
        }
        return file;
    }

    public File getEventFile() {
        return eventFile;
    }

    // --- queries ---

    public List<CalendarEvent> getEvents() {
        return Collections.unmodifiableList(new ArrayList<>(events.values()));
    }

    public CalendarEvent getEvent(String id) {
        return events.get(id);
    }

    /** Everything happening on one day, in display order. */
    public List<Occurrence> getOccurrences(LocalDate date) {
        return getOccurrences(date, date);
    }

    /** Everything happening from {@code first} to {@code last} (inclusive), in display order. */
    public List<Occurrence> getOccurrences(LocalDate first, LocalDate last) {
        List<Occurrence> result = new ArrayList<>();
        for (LocalDate day = first; !day.isAfter(last); day = day.plusDays(1)) {
            for (CalendarEvent event : events.values()) {
                if (event.occursOn(day)) {
                    result.add(new Occurrence(event, day));
                }
            }
        }
        result.sort(Occurrence.CHRONOLOGICAL);
        return result;
    }

    public boolean hasEventsOn(LocalDate date) {
        for (CalendarEvent event : events.values()) {
            if (event.occursOn(date)) {
                return true;
            }
        }
        return false;
    }

    // --- changes (each one is saved immediately) ---

    public void add(CalendarEvent event) {
        if (events.containsKey(event.getId())) {
            throw new IllegalArgumentException("An event with this id already exists.");
        }
        events.put(event.getId(), event);
        save();
    }

    /** Replaces the stored event that has the same id (e.g. an edited copy). */
    public void update(CalendarEvent event) {
        requireEvent(event.getId());
        events.put(event.getId(), event);
        save();
    }

    /** Deletes an event, including every repeat of it. */
    public void remove(String id) {
        requireEvent(id);
        events.remove(id);
        save();
    }

    /** Removes one day from a repeating event, leaving the other repeats alone. */
    public void removeOccurrence(String id, LocalDate date) {
        CalendarEvent event = requireEvent(id);
        if (!event.isRepeating()) {
            remove(id);
            return;
        }
        event.skipDate(date);
        save();
    }

    private CalendarEvent requireEvent(String id) {
        CalendarEvent event = events.get(id);
        if (event == null) {
            throw new IllegalArgumentException("No event with id " + id);
        }
        return event;
    }

    // --- loading and saving ---

    public void load() {
        events.clear();
        if (!eventFile.exists()) {
            return;
        }
        Path path = eventFile.toPath();
        try {
            boolean legacy = EventFileFormat.isLegacyFile(path);
            List<CalendarEvent> loaded = EventFileFormat.read(path);
            for (CalendarEvent event : loaded) {
                events.put(event.getId(), event);
            }
            if (legacy) {
                // Keep the old file around, then rewrite it in the new format.
                Files.copy(path, siblingFile(".v1.bak").toPath(), StandardCopyOption.REPLACE_EXISTING);
                save();
            }
        } catch (IOException | RuntimeException ex) {
            events.clear(); // never keep half-loaded data
            // Move the unreadable file aside so the next save can't destroy it.
            String backupNote;
            try {
                String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
                File backup = siblingFile("." + stamp + ".bak");
                Files.move(path, backup.toPath(), StandardCopyOption.REPLACE_EXISTING);
                backupNote = "\n\nThe unreadable file was kept as:\n" + backup.getAbsolutePath();
            } catch (IOException backupError) {
                backupNote = "\n\nThe file could not be backed up (" + backupError.getMessage()
                    + "). Copy it somewhere safe before adding events:\n" + eventFile.getAbsolutePath();
            }
            errorReporter.accept("Could not load saved OurDay events: " + ex.getMessage() + backupNote);
        }
    }

    private File siblingFile(String suffix) {
        return new File(eventFile.getAbsoluteFile().getParentFile(), eventFile.getName() + suffix);
    }

    /**
     * Writes to a temporary file first, then swaps it into place, so a crash
     * mid-save leaves the previous file intact instead of a half-written one.
     */
    private void save() {
        Path target = eventFile.getAbsoluteFile().toPath();
        Path temp = null;
        try {
            Files.createDirectories(target.getParent());
            temp = Files.createTempFile(target.getParent(), FILE_NAME, ".tmp");
            try (Writer writer = Files.newBufferedWriter(temp, StandardCharsets.UTF_8)) {
                EventFileFormat.write(events.values(), writer);
            }
            try {
                Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            if (temp != null) {
                try {
                    Files.deleteIfExists(temp);
                } catch (IOException ignored) {
                    // best-effort cleanup
                }
            }
            errorReporter.accept("Could not save events: " + ex.getMessage());
        }
    }

    private static void showErrorDialog(String message) {
        JOptionPane.showMessageDialog(null, message, "OurDay", JOptionPane.ERROR_MESSAGE);
    }
}

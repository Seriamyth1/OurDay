import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * A small always-on-top card in the bottom-right corner of the screen.
 * It deliberately has no owner window so it still appears when the main
 * OurDay window is minimized. Several reminders stack upward.
 */
public final class ReminderPopup {
    private static final int SNOOZE_MINUTES = 5;
    private static final int AUTO_CLOSE_MS = 5 * 60 * 1000;
    private static final List<JDialog> OPEN = new ArrayList<>();

    private ReminderPopup() {
    }

    /**
     * @param onSnooze called with the number of minutes if the user picks Snooze
     * @param onOpen   called if the user clicks "Open" to jump to that day
     */
    public static void show(Occurrence occurrence, Consumer<Integer> onSnooze, Runnable onOpen) {
        CalendarEvent event = occurrence.event();
        JDialog popup = new JDialog((Frame) null, "OurDay reminder", false);
        popup.setAlwaysOnTop(true);
        popup.setFocusableWindowState(false); // don't steal focus from what the user is typing
        popup.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

        JPanel content = new JPanel(new BorderLayout(10, 8));
        content.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 5, 0, 0, event.getCategory().color()),
            new EmptyBorder(12, 14, 12, 14)));
        content.setBackground(Color.WHITE);

        JLabel heading = new JLabel("Reminder \u00B7 " + event.getCategory().label());
        heading.setFont(new Font("SansSerif", Font.BOLD, 11));
        heading.setForeground(ThemeManager.MUTED_TEXT);

        String shortTitle = event.getTitle().length() > 60 ? event.getTitle().substring(0, 57) + "..." : event.getTitle();
        JLabel title = new JLabel(shortTitle);
        title.putClientProperty("html.disable", Boolean.TRUE);
        title.setToolTipText(null);
        title.setFont(new Font("SansSerif", Font.BOLD, 15));
        title.setForeground(ThemeManager.TEXT);

        JLabel when = new JLabel(ReminderService.describeTiming(occurrence, LocalDateTime.now()));
        when.setFont(ThemeManager.BODY_FONT);
        when.setForeground(ThemeManager.TEXT);

        JPanel text = new JPanel(new GridLayout(0, 1, 0, 3));
        text.setOpaque(false);
        text.add(heading);
        text.add(title);
        text.add(when);
        content.add(text, BorderLayout.CENTER);

        JButton open = new JButton("Open");
        JButton snooze = new JButton("Snooze " + SNOOZE_MINUTES + " min");
        JButton dismiss = new JButton("Dismiss");
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        buttons.setOpaque(false);
        buttons.add(open);
        buttons.add(snooze);
        buttons.add(dismiss);
        content.add(buttons, BorderLayout.SOUTH);

        open.addActionListener(e -> {
            close(popup);
            onOpen.run();
        });
        snooze.addActionListener(e -> {
            close(popup);
            onSnooze.accept(SNOOZE_MINUTES);
        });
        dismiss.addActionListener(e -> close(popup));

        Timer autoClose = new Timer(AUTO_CLOSE_MS, e -> close(popup));
        autoClose.setRepeats(false);
        autoClose.start();

        popup.setContentPane(content);
        popup.pack();
        popup.setSize(Math.max(popup.getWidth(), 340), popup.getHeight());
        OPEN.add(popup);
        layoutPopups();
        popup.setVisible(true);
        Toolkit.getDefaultToolkit().beep();
    }

    private static void close(JDialog popup) {
        if (OPEN.remove(popup)) {
            popup.dispose();
            layoutPopups();
        }
    }

    /** Stacks open reminders from the bottom-right corner of the usable screen area. */
    private static void layoutPopups() {
        GraphicsConfiguration config = GraphicsEnvironment.getLocalGraphicsEnvironment()
            .getDefaultScreenDevice().getDefaultConfiguration();
        Rectangle screen = config.getBounds();
        Insets insets = Toolkit.getDefaultToolkit().getScreenInsets(config);
        int right = screen.x + screen.width - insets.right - 16;
        int bottom = screen.y + screen.height - insets.bottom - 16;
        for (JDialog popup : OPEN) {
            bottom -= popup.getHeight();
            popup.setLocation(right - popup.getWidth(), bottom);
            bottom -= 10;
        }
    }
}

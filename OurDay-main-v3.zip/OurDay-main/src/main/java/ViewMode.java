import java.time.LocalDate;

/** The three ways to look at the calendar, and how far the arrows move in each. */
public enum ViewMode {
    DAY("Day"),
    WEEK("Week"),
    MONTH("Month");

    private final String label;

    ViewMode(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }

    /** The date one step forward (+1) or back (-1) from {@code date} in this view. */
    public LocalDate step(LocalDate date, int direction) {
        switch (this) {
            case DAY:
                return date.plusDays(direction);
            case WEEK:
                return date.plusWeeks(direction);
            default:
                return date.plusMonths(direction);
        }
    }
}

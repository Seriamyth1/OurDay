import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

/**
 * Decides which reminders are due. It has no UI of its own: OurDay calls
 * {@link #collectDue(LocalDateTime)} on a timer and shows a popup for each result,
 * which keeps this logic easy to test.
 */
public class ReminderService {
    /** A reminder for a timed event can still show up to this long after the event starts. */
    static final int LATE_GRACE_MINUTES = 10;

    private final EventManager manager;
    private final Set<String> shown = new HashSet<>();
    private final Map<String, LocalDateTime> snoozedUntil = new HashMap<>();

    public ReminderService(EventManager manager) {
        this.manager = manager;
    }

    /** When the reminder for this occurrence should appear, or null if it has none. */
    public static LocalDateTime reminderTime(Occurrence occurrence) {
        if (!occurrence.event().hasReminder()) {
            return null;
        }
        return occurrence.referenceTime().minusMinutes(occurrence.event().getReminderMinutes());
    }

    /**
     * The last moment a reminder is still useful: shortly after a timed event starts,
     * or the end of the day for an all-day event (so opening the app late in the
     * morning still shows today's all-day reminders).
     */
    static LocalDateTime expiryTime(Occurrence occurrence) {
        if (occurrence.event().isAllDay()) {
            return occurrence.date().plusDays(1).atStartOfDay();
        }
        return occurrence.referenceTime().plusMinutes(LATE_GRACE_MINUTES);
    }

    /** True if a reminder should be on screen at {@code now}, ignoring whether it was already shown. */
    static boolean isDue(Occurrence occurrence, LocalDateTime now, LocalDateTime snoozeEnd) {
        if (snoozeEnd != null) {
            return !now.isBefore(snoozeEnd);
        }
        LocalDateTime trigger = reminderTime(occurrence);
        return trigger != null && !now.isBefore(trigger) && now.isBefore(expiryTime(occurrence));
    }

    /**
     * Returns every reminder that should appear now and marks them as shown, so
     * each one appears only once (unless snoozed).
     */
    public List<Occurrence> collectDue(LocalDateTime now) {
        LocalDate today = now.toLocalDate();
        // Yesterday covers late reminders just after midnight; tomorrow covers "1 day before".
        List<Occurrence> candidates = manager.getOccurrences(today.minusDays(1), today.plusDays(1));
        List<Occurrence> due = new ArrayList<>();
        for (Occurrence occurrence : candidates) {
            String key = occurrence.key();
            if (shown.contains(key)) {
                continue;
            }
            if (isDue(occurrence, now, snoozedUntil.get(key))) {
                shown.add(key);
                snoozedUntil.remove(key);
                due.add(occurrence);
            }
        }
        return due;
    }

    /** Shows the reminder again after {@code minutes}. */
    public void snooze(Occurrence occurrence, int minutes, LocalDateTime now) {
        String key = occurrence.key();
        shown.remove(key);
        snoozedUntil.put(key, now.plusMinutes(minutes));
    }

    /** Friendly description of when the event is, relative to {@code now}. */
    public static String describeTiming(Occurrence occurrence, LocalDateTime now) {
        CalendarEvent event = occurrence.event();
        LocalDate today = now.toLocalDate();
        String day;
        if (occurrence.date().equals(today)) {
            day = "Today";
        } else if (occurrence.date().equals(today.plusDays(1))) {
            day = "Tomorrow";
        } else {
            day = Formats.shortDay(occurrence.date());
        }
        if (event.isAllDay()) {
            return day + " (all day)";
        }
        LocalDateTime start = occurrence.referenceTime();
        long minutes = java.time.Duration.between(now, start).toMinutes();
        String when = day + " at " + Formats.time(event.getStartTime());
        if (minutes <= 0 && !now.isBefore(start)) {
            return "Started " + (minutes == 0 ? "just now" : (-minutes) + " min ago") + " (" + when + ")";
        }
        if (minutes < 60) {
            return "Starts in " + Math.max(1, minutes) + " min (" + when + ")";
        }
        return when;
    }
}

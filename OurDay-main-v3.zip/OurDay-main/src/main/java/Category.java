import java.awt.Color;

/** What an event is for. Each category has its own color in every view. */
public enum Category {
    WORK("Work", new Color(103, 119, 219)),
    SCHOOL("School", new Color(79, 159, 143)),
    FAMILY("Family", new Color(226, 130, 159)),
    ERRANDS("Errands", new Color(224, 163, 83)),
    HEALTH("Health", new Color(208, 96, 96)),
    HOBBIES("Hobbies", new Color(147, 112, 190)),
    OTHER("Other", new Color(128, 138, 160));

    private final String label;
    private final Color color;

    Category(String label, Color color) {
        this.label = label;
        this.color = color;
    }

    public String label() {
        return label;
    }

    public Color color() {
        return color;
    }

    @Override
    public String toString() {
        return label;
    }
}

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.time.*;
import java.time.format.TextStyle;
import java.util.Locale;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class SidebarPanel extends JPanel {
    private static final Color SIDEBAR_FILL = new Color(255, 255, 255, 185);
    private final JLabel miniMonthLabel = new JLabel("", SwingConstants.CENTER);
    private final JPanel miniGrid = new JPanel(new GridLayout(0, 7, 2, 4));
    private final Consumer<LocalDate> onDateSelected;

    public SidebarPanel(Runnable onToday, Runnable onThisMonth, Consumer<LocalDate> onDateSelected) {
        super(new BorderLayout(0, 14));
        this.onDateSelected = onDateSelected;
        // A translucent background on an opaque component causes ghosting when
        // Swing repaints, so the panel is non-opaque and paints its own fill.
        setOpaque(false);
        setBorder(new EmptyBorder(16, 12, 16, 12));
        setPreferredSize(new Dimension(215, 0));

        JLabel brand = new JLabel("OurDay");
        brand.setFont(new Font("SansSerif", Font.BOLD, 21));
        brand.setForeground(ThemeManager.TEXT);

        JPanel navigation = new JPanel(new GridLayout(2, 1, 0, 6));
        navigation.setOpaque(false);
        JButton today = new JButton("Today");
        today.addActionListener(event -> onToday.run());
        JButton thisMonth = new JButton("This month");
        thisMonth.addActionListener(event -> onThisMonth.run());
        navigation.add(today);
        navigation.add(thisMonth);

        JPanel top = new JPanel(new BorderLayout(0, 14));
        top.setOpaque(false);
        top.add(brand, BorderLayout.NORTH);
        top.add(navigation, BorderLayout.CENTER);
        add(top, BorderLayout.NORTH);

        JPanel miniCalendar = new JPanel(new BorderLayout(0, 8));
        miniCalendar.setOpaque(false);
        miniMonthLabel.setFont(ThemeManager.SUBTITLE_FONT);
        miniMonthLabel.setForeground(ThemeManager.TEXT);
        miniCalendar.add(miniMonthLabel, BorderLayout.NORTH);
        miniGrid.setOpaque(false);
        miniCalendar.add(miniGrid, BorderLayout.CENTER);
        // NORTH keeps the mini calendar compact instead of stretching its rows to fill the sidebar.
        JPanel miniHolder = new JPanel(new BorderLayout());
        miniHolder.setOpaque(false);
        miniHolder.add(miniCalendar, BorderLayout.NORTH);
        add(miniHolder, BorderLayout.CENTER);

        JPanel footer = new JPanel();
        footer.setOpaque(false);
        footer.setLayout(new BoxLayout(footer, BoxLayout.Y_AXIS));
        JLabel markers = new JLabel("CATEGORIES");
        markers.setFont(new Font("SansSerif", Font.BOLD, 10));
        markers.setForeground(ThemeManager.MUTED_TEXT);
        footer.add(markers);
        footer.add(Box.createVerticalStrut(8));
        for (Category category : Category.values()) {
            JLabel marker = new JLabel(category.label());
            marker.setFont(new Font("SansSerif", Font.PLAIN, 11));
            marker.setForeground(ThemeManager.TEXT);
            marker.setIcon(new ColorDotIcon(category.color()));
            marker.setIconTextGap(8);
            footer.add(marker);
            footer.add(Box.createVerticalStrut(5));
        }
        add(footer, BorderLayout.SOUTH);
        setMonth(YearMonth.now(), LocalDate.now(), date -> false);
    }

    /**
     * Redraws the mini calendar.
     *
     * @param selected  the day currently shown in the main view (outlined)
     * @param hasEvents days with events are shown in bold
     */
    public void setMonth(YearMonth month, LocalDate selected, Predicate<LocalDate> hasEvents) {
        miniMonthLabel.setText(month.getMonth().getDisplayName(TextStyle.SHORT, Locale.getDefault())
            + " " + month.getYear());
        miniGrid.removeAll();

        String[] weekdays = {"S", "M", "T", "W", "T", "F", "S"};
        for (String weekday : weekdays) {
            JLabel label = new JLabel(weekday, SwingConstants.CENTER);
            label.setFont(new Font("SansSerif", Font.BOLD, 10));
            label.setForeground(ThemeManager.MUTED_TEXT);
            miniGrid.add(label);
        }

        int offset = month.atDay(1).getDayOfWeek().getValue() % 7;
        for (int i = 0; i < offset; i++) {
            miniGrid.add(new JLabel(""));
        }
        for (int day = 1; day <= month.lengthOfMonth(); day++) {
            LocalDate date = month.atDay(day);
            JButton dayButton = new JButton(Integer.toString(day));
            boolean busy = hasEvents.test(date);
            dayButton.setFont(new Font("SansSerif", busy ? Font.BOLD : Font.PLAIN, 10));
            dayButton.setMargin(new Insets(2, 0, 2, 0));
            dayButton.setFocusPainted(false);
            dayButton.setBorderPainted(date.equals(selected));
            dayButton.setBorder(BorderFactory.createLineBorder(ThemeManager.ACCENT));
            dayButton.setContentAreaFilled(date.equals(LocalDate.now()));
            dayButton.setForeground(busy ? ThemeManager.TEXT : ThemeManager.MUTED_TEXT);
            if (date.equals(LocalDate.now())) {
                dayButton.setBackground(new Color(221, 226, 255));
                dayButton.setForeground(ThemeManager.ACCENT);
            }
            dayButton.setToolTipText(Formats.fullDay(date) + (busy ? " (has events)" : ""));
            dayButton.addActionListener(event -> onDateSelected.accept(date));
            miniGrid.add(dayButton);
        }
        miniGrid.revalidate();
        miniGrid.repaint();
    }

    @Override
    protected void paintComponent(Graphics graphics) {
        Graphics2D g2 = (Graphics2D) graphics.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(SIDEBAR_FILL);
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), 18, 18);
        g2.dispose();
        super.paintComponent(graphics);
    }

    private static class ColorDotIcon implements Icon {
        private final Color color;

        private ColorDotIcon(Color color) {
            this.color = color;
        }

        @Override
        public void paintIcon(Component component, Graphics graphics, int x, int y) {
            graphics.setColor(color);
            graphics.fillOval(x, y + 2, 9, 9);
        }

        @Override
        public int getIconWidth() {
            return 12;
        }

        @Override
        public int getIconHeight() {
            return 13;
        }
    }
}

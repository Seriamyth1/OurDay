# OurDay

OurDay is a free, Java-based customizable calendar application with daily, weekly, and monthly views.

## Description

OurDay is a customizable desktop calendar application designed to make schedule management easier, more flexible, and more enjoyable.
It helps users organize daily responsibilities, upcoming tasks, appointments, deadlines, and important events through a clean calendar
experience that can be personalized to match each user's preferences.

Key features:

* **Day, Week and Month views:** see your schedule hour by hour, a week at a time, or the whole month.
* **Event times and categories:** events can be all-day or timed, and each one belongs to a category
  (Work, School, Family, Errands, Health, Hobbies, Other) with its own color.
* **Repeating events:** repeat daily, weekly on chosen days (e.g. Mon/Wed/Fri), monthly or yearly, with an
  optional end date. A single day can be removed without deleting the whole series.
* **Reminders:** get a pop-up from 5 minutes to 1 day before an event, with Snooze and Open buttons.
  The pop-up appears even when OurDay is minimized.
* **Customizable backgrounds:** gradient, solid colors or your own image with adjustable opacity.
  OurDay remembers your choice and your last view.

All calendar data is saved locally, so OurDay works without an internet connection.

## Tech Stack

* **Language:** Java 17+
* **User Interface:** Java Swing
* **Local Storage:** a plain-text events file in `~/.ourday/` (no database needed)
* **Build Tool:** Maven
* **Testing:** JUnit 5
* **Version Control:** Git and GitHub

## Getting Started

### Dependencies

* Windows, macOS or Linux
* Java 17 or newer ([Adoptium Temurin](https://adoptium.net) is a free option). Check with `java -version`.
* Maven 3.8+ to build from source (most IDEs, such as IntelliJ IDEA, include it)
* Wi-Fi is only needed the first time you build, so Maven can download JUnit

### Installing

```bash
git clone <this repository's URL>
cd OurDay
mvn package
```

This runs the tests and creates `target/ourday.jar`.

### Executing Program

```bash
java -jar target/ourday.jar
```

Or run `OurDay` (in `src/main/java/OurDay.java`) from your IDE.

To run only the tests:

```bash
mvn test
```

### Using OurDay

* Switch views with **Day / Week / Month**; the arrows move one day, week or month.
* **Month view:** click a day to see, add, edit or delete its events.
* **Week view:** click an event to edit it, or click empty space in a column to add one.
* **Day view:** click an hour to add an event at that time, or the "All day" bar for an all-day event.
* Click a date in the sidebar's mini calendar to jump to it. Bold dates have events.
* Use **Personalize** to change the background; **Reset** returns to the default gradient.

## Help

**Where are my events stored?**
In `~/.ourday/ourday-events.dat` (on Windows: `C:\Users\<you>\.ourday\`). It's a plain-text file, one event per line.
Settings are in `settings.properties` in the same folder.

**I used an older version of OurDay. Are my events still there?**
Yes. On first launch, OurDay copies the old `ourday-events.dat` from the folder it was started in, converts it to
the new format, and keeps the original as `ourday-events.dat.v1.bak`.

**OurDay said it couldn't load my events.**
The unreadable file is never overwritten. It's renamed to `ourday-events.dat.<date-time>.bak` in the same
folder so it can be recovered.

**Reminders didn't appear.**
Reminders only appear while OurDay is running (it can be minimized). For all-day events, reminder times count from 9:00 AM.

## Authors

* Ramir Moses
* Heriberto Chavez-Pullman
